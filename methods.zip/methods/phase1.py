import os
import json
import time
from pathlib import Path
import httpx

from dotenv import load_dotenv
from pydantic import SecretStr
from langchain_openai import AzureChatOpenAI


# ============================================
# 🔹 LOAD ENV
# ============================================
load_dotenv()


# ============================================
# 🔹 LLM SETUP
# ============================================
def get_llm():
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    deployment = os.getenv("AZURE_OPENAI_CHAT_DEPLOYMENT_NAME")
    api_key = os.getenv("AZURE_OPENAI_API_KEY")

    if not all([endpoint, deployment, api_key]):
        raise ValueError("❌ Missing Azure OpenAI environment variables")

    timeout = httpx.Timeout(300.0, read=600.0)

    return AzureChatOpenAI(
        azure_endpoint=endpoint,
        azure_deployment=deployment,
        api_key=SecretStr(api_key),
        api_version="2024-02-01",
        temperature=0.0,
        streaming=False,
        http_client=httpx.Client(timeout=timeout)
    )


# ============================================
# 🔹 CLEAN LLM OUTPUT
# ============================================
def clean_llm_json(response: str) -> str:
    response = response.strip()

    if response.startswith("```"):
        response = response.replace("```json", "")
        response = response.replace("```", "")

    return response.strip()


def safe_json_parse(response: str):
    cleaned = clean_llm_json(response)

    try:
        return json.loads(cleaned)
    except Exception as e:
        return {
            "error": "Invalid JSON from LLM",
            "exception": str(e),
            "raw_output": response
        }

EXTRACTION_PROMPT = """
You are a DataStage Lineage Extractor.
Return ONLY a valid JSON object. Nothing else.

---

### STEP 1: IDENTIFY THE STAGE

Find the value after "STAGE:" — this is your node id.
Create exactly one node with this id.

While reading the chunk, also collect every OTHER stage name you encounter
(in patterns like "from <name>", "to <name>", "Target Stage:", "Partner:").
Call this your KNOWN STAGE NAMES list.
These are stages, not links — they must never appear in input_links or output_links.

---

### STEP 2: EXTRACT LINKS

Look ONLY at lines with these explicit labels:
  INPUT_LINK: X
  OUTPUT_LINK: X
  Input Link: X
  Output Link: X
  FLOW: A -> StageName -> B   → extract A and B only

These are your raw link candidates.

If any value contains "|" → split on "|" and treat each part as a separate candidate.

---

### STEP 3: VALIDATE EACH CANDIDATE

For each raw candidate, ask these questions in order.
If ANY answer is YES → discard it immediately, move to next candidate.

1. Is it a pure number or single character?         → discard
2. Is it shorter than 3 characters?                 → discard  
3. Does it contain spaces?                          → discard
4. Does it equal this node's own id?                → discard
5. Does it exist in KNOWN STAGE NAMES?              → discard
6. Does it look auto-generated from this node's id?
   (this node's id + any suffix like _Out _In _output _result _Output)
   AND it was NOT found as an explicit INPUT_LINK/OUTPUT_LINK label?  → discard

What survives goes into input_links or output_links based on its origin label.

---

### STEP 4: ASSIGN NODE TYPE

Read the full chunk context and assign ONE type:

source    → reads from external system, input_links will be empty after validation
target    → writes to external system, output_links will be empty after validation
lookup    → provides reference data as a side input to other stages
            (hashed files, reference datasets — they feed lookups not main flow)
transform → everything else that processes or routes data

Use ALL available signals: stage type name, context field, processing steps, link direction.
Do not rely on a single field alone.

---

### STEP 5: MAP REMAINING CONTENT

processing_logic  → ordered execution steps
business_rules    → conditions, constraints, validation logic
transformations   → column mappings and derivations
lookups           → lookup definitions
joins             → join conditions
filters           → filter expressions
sql               → copy the SQL query EXACTLY, every character, no changes
raw_metadata      → everything else (connection config, properties, file config)

---

### OUTPUT FORMAT

{
  "nodes": [
    {
      "id": "",
      "type": "",
      "stage_type": "",
      "input_links": [],
      "output_links": [],
      "processing_logic": [],
      "business_rules": [],
      "transformations": [],
      "lookups": [],
      "joins": [],
      "filters": [],
      "sql": null,
      "raw_metadata": {}
    }
  ],
  "edges": []
}

INPUT:
{stage_chunk_content}
"""
# ============================================
# 🔹 CORE FUNCTION (FIXED)
# ============================================
def generate_graph_json_one_by_one_chunk(chunks_dict, llm):
    final_results = {}

    # ── Only stage keys ──
    stage_keys = [k for k in chunks_dict if not k.startswith("__")]

    print(f"📦 Total stage chunks: {len(stage_keys)}")

    for i, chunk_id in enumerate(stage_keys):
        start_time = time.time()

        chunk_list = chunks_dict.get(chunk_id, [])

        # 🔥 Safe join
        stage_chunk_content = "\n\n".join(
            c.get("content", "") for c in chunk_list if c.get("content")
        )

        if not stage_chunk_content.strip():
            final_results[chunk_id] = {"error": "Empty stage content"}
            continue

        # ── Inject ONLY stage content ──
        prompt = EXTRACTION_PROMPT.replace(
            "{stage_chunk_content}", stage_chunk_content
        )

        # 🔁 Retry mechanism
        parsed = {"error": "No response"}

        for attempt in range(3):
            try:
                response = llm.invoke(prompt).content.strip()
                parsed = safe_json_parse(response)

                if "error" not in parsed:
                    break

            except Exception as e:
                if attempt == 2:
                    parsed = {
                        "error": "LLM call failed",
                        "exception": str(e)
                    }
                else:
                    time.sleep(2)

        final_results[chunk_id] = parsed

        elapsed = time.time() - start_time
        print(f"✅ {chunk_id} | {elapsed:.2f}s")

    return final_results

# ============================================
# 🔹 PIPELINE RUNNER
# ============================================
def run_phase1_pipeline(input_dir="data/output", output_dir="data/output"):
    input_path = Path(input_dir)
    output_path = Path(output_dir)

    output_path.mkdir(parents=True, exist_ok=True)

    llm = get_llm()

    input_files = list(input_path.glob("*chunks.json"))

    if not input_files:
        print("❌ No chunk files found")
        return

    print(f"📂 Found {len(input_files)} chunk files")

    for file in input_files:
        print(f"\n🚀 Processing: {file.name}")

        with open(file, "r", encoding="utf-8") as f:
            chunks_dict = json.load(f)

        result = generate_graph_json_one_by_one_chunk(chunks_dict, llm)

        output_file = output_path / file.name.replace("chunks.json", "phase1.json")

        with open(output_file, "w", encoding="utf-8") as f:
            json.dump(result, f, indent=2, ensure_ascii=False)

        print(f"💾 Saved: {output_file}")


# ============================================
# 🔹 ENTRY POINT
# ============================================
if __name__ == "__main__":
    run_phase1_pipeline()