import os
import re
import json
import time
from pathlib import Path
import httpx

from dotenv import load_dotenv
from pydantic import SecretStr
from langchain_openai import AzureChatOpenAI

load_dotenv()

# ============================================
# 🔹 CONFIG
# ============================================
MAX_RETRIES = 3
INPUT_DIR = "data/output"
OUTPUT_DIR = "data/output"

SYSTEM_PROMPT = """You are a JSON-only data lineage processing engine.
Your entire response must be a single valid JSON object.
First character must be { and last character must be }.
No explanation. No markdown. No ```json fences. No text outside the JSON."""


# ============================================
# 🔹 LLM SETUP
# ============================================
def get_llm():
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    deployment = os.getenv("AZURE_OPENAI_CHAT_DEPLOYMENT_NAME")
    api_key = os.getenv("AZURE_OPENAI_API_KEY")

    if not all([endpoint, deployment, api_key]):
        raise ValueError("Missing Azure OpenAI environment variables")

    return AzureChatOpenAI(
        azure_endpoint=endpoint,
        azure_deployment=deployment,
        api_key=SecretStr(api_key),
        api_version="2024-02-01",
        temperature=0.0,
        streaming=False,
        http_client=httpx.Client(
            timeout=httpx.Timeout(300.0, read=600.0)
        )
    )


# ============================================
# 🔹 JSON PARSE
# ============================================
def safe_json_parse(response: str) -> dict:
    response = response.strip()
    response = re.sub(r"```json|```", "", response).strip()
    start = response.find("{")
    end = response.rfind("}") + 1
    if start == -1 or end == 0:
        return {"error": "No JSON found", "raw_output": response}
    try:
        return json.loads(response[start:end])
    except Exception as e:
        return {"error": "Invalid JSON", "exception": str(e), "raw_output": response}


def recover_chunk(v: dict) -> dict | None:
    raw = v.get("raw_output", "")
    if not raw:
        return None
    result = safe_json_parse(raw)
    return result if "error" not in result else None


# ============================================
# 🔹 FLATTEN PHASE 1 OUTPUT
# ============================================
def flatten_phase1(phase1_data: dict) -> tuple[list, list]:
    all_nodes = []
    master_stage_ids = list(phase1_data.keys())

    for stage_id, v in phase1_data.items():
        if not isinstance(v, dict):
            continue

        if "error" in v:
            v = recover_chunk(v)
            if not v:
                print(f"  [Skipped] {stage_id} — unrecoverable")
                continue
            print(f"  [Recovered] {stage_id}")

        for node in v.get("nodes", []):
            if not node.get("id"):
                node["id"] = stage_id
            all_nodes.append(node)

    print(f"  [Flattened] {len(all_nodes)} nodes | {len(master_stage_ids)} known stages")
    return all_nodes, master_stage_ids


# ============================================
# 🔹 PHASE 1.5 PROMPT
# ============================================
def build_phase15_prompt(node: dict, all_stage_ids: list) -> str:
    return f"""
You are a LINK VALIDATOR for a data lineage graph.

You receive ONE extracted stage node and your job is to produce
correct input_links and output_links for lineage graph construction.

---

### WHAT YOU ARE BUILDING

A lineage graph where:
- Nodes are stages
- Edges are data flow connections between stages
- Links are the named wires that carry data between stages

For an edge to exist between two stages, one stage must have a link name
in its output_links that matches the same link name in another stage's input_links.
This is why link accuracy is critical.

---

### ALL KNOWN STAGE IDs

{json.dumps(all_stage_ids, indent=2)}

---

### HOW TO FIND REAL LINKS — USE THIS PRIORITY ORDER

Read the node carefully. Find links using this priority:

PRIORITY 1 — Explicit flow labels (most reliable):
  Look for these exact patterns:
  - INPUT_LINK: <value>
  - OUTPUT_LINK: <value>
  - Input Link: <value>
  - Output Link: <value>
  - INPUT_PIN: <value>
  - OUTPUT_PIN: <value>
  - FLOW: <LinkA> -> <Stage> -> <LinkB>  → extract LinkA and LinkB only

  These are always real links. Always keep them.

PRIORITY 2 — Processing logic context (use carefully):
  Look inside processing_logic for phrases like:
  - "output data to link <name>"
  - "receive data from link <name>"
  - "route to <name>"
  - "via <name> link"

  Only use these if no Priority 1 source exists for that direction
  (input or output) AND the value clearly refers to a data flow connector.

PRIORITY 3 — When both above are missing:
  Leave that direction empty. Do not guess.

---

### WHAT TO ALWAYS EXCLUDE

These are never links regardless of where they appear:

1. Values from metadata-only fields:
   Partner, Partner_Link, FileName, File_Name, Target File,
   Target Stage, Target Table, ConnectorName, TableDef
   → These describe configuration, not data flow

2. Pure numbers or single characters ("3", "0", "-1", "x")

3. Values containing spaces that read as descriptions

4. This node's own id (self-reference)

5. Auto-generated aliases:
   - Looks like this node's own id with a suffix (_Out, _In, _Output, _output, _result)
   - AND does not exist in the known stage IDs list

---

### ABOUT STAGE IDs AS LINK NAMES

A value that matches a known stage ID can be a valid link name.
In DataStage, links are often named after the stage they connect to.
Do not remove a value just because it matches a stage ID.
Judge by where it came from (Priority 1 or 2), not what it looks like.

---

### DEFAULT

When genuinely uncertain → KEEP.
A missing real link permanently breaks the lineage graph.
A kept noisy value can be cleaned later.

---

### OUTPUT

Return ONLY this JSON. Copy every field exactly.
Only input_links and output_links should change:

{{
  "id": "",
  "type": "",
  "stage_type": "",
  "input_links": [],
  "output_links": [],
  "processing_logic": [],
  "business_rules": [],
  "transformations": [],
  "lookups": [],
  "joins": [],
  "filters": [],
  "sql": null,
  "raw_metadata": {{}}
}}

NODE TO CLEAN:
{json.dumps(node, indent=2)}
"""


# ============================================
# 🔹 LLM CALL
# ============================================
def call_llm(prompt: str, llm) -> dict:
    for attempt in range(MAX_RETRIES):
        try:
            response = llm.invoke([
                ("system", SYSTEM_PROMPT),
                ("human", prompt),
            ]).content.strip()

            parsed = safe_json_parse(response)
            if "error" not in parsed:
                return parsed

            print(f"    [Parse failed] {parsed.get('error')}")

        except Exception as e:
            print(f"    [Exception] {e}")

        time.sleep(2)

    return {"error": "LLM failed after all retries"}


# ============================================
# 🔹 RUN PHASE 1.5
# ============================================
def run_phase15(all_nodes: list, master_stage_ids: list, llm) -> list:
    cleaned_nodes = []

    for i, node in enumerate(all_nodes):
        node_id = node.get("id", f"node_{i}")
        print(f"  [{i+1}/{len(all_nodes)}] {node_id}")

        prompt = build_phase15_prompt(node, master_stage_ids)
        result = call_llm(prompt, llm)

        if "error" in result:
            print(f"    [Failed] keeping original")
            cleaned_nodes.append(node)
        else:
            cleaned_nodes.append(result)

    return cleaned_nodes


# ============================================
# 🔹 PIPELINE RUNNER
# ============================================
def run_phase15_pipeline():
    input_path = Path(INPUT_DIR)
    output_path = Path(OUTPUT_DIR)
    output_path.mkdir(parents=True, exist_ok=True)

    llm = get_llm()
    files = list(input_path.glob("*phase1.json"))

    if not files:
        print("[ERROR] No phase1 files found")
        return

    print(f"[Found] {len(files)} phase1 file(s)")

    for file in files:
        print(f"\n{'='*50}")
        print(f"[Processing] {file.name}")
        print(f"{'='*50}")

        with open(file, "r", encoding="utf-8") as f:
            phase1_data = json.load(f)

        print("\n[Step 1] Flattening...")
        all_nodes, master_stage_ids = flatten_phase1(phase1_data)

        if not all_nodes:
            print(f"[Skipped] {file.name} — no nodes")
            continue

        print(f"\n[Step 2] Cleaning links...")
        cleaned_nodes = run_phase15(all_nodes, master_stage_ids, llm)

        stem = file.stem.replace("_phase1", "")
        out_file = output_path / f"{stem}_phase15.json"

        with open(out_file, "w", encoding="utf-8") as f:
            json.dump(
                {
                    "master_stage_ids": master_stage_ids,
                    "nodes": cleaned_nodes
                },
                f,
                indent=2
            )

        print(f"\n[Saved] {out_file.name} — {len(cleaned_nodes)} nodes")


# ============================================
# 🔹 ENTRY
# ============================================
if __name__ == "__main__":
    run_phase15_pipeline()

