import asyncio
import httpx

API_URL = "http://localhost:3655/v3/chat"
API_KEY = "test-api-key-123"

async def stream_chat(payload):
    headers = {
        "X-API-Key": API_KEY
    }

    async with httpx.AsyncClient(timeout=None) as client:
        async with client.stream(
            "POST",
            API_URL,
            json=payload,
            headers=headers
        ) as response:

            if response.status_code != 200:
                error_text = await response.aread()
                print("Error:", error_text.decode())
                return

            async for chunk in response.aiter_text():
                if chunk:
                    print(chunk, end="", flush=True)


if __name__ == "__main__":
    payload = {
        "query": "list me the json files available in the path /app/data ?",
        # "query": "list me the tools available ?",
        "thread_id": "1004",
        "agent_name": "test3",
        "temperature":0.00,
        "model_source":'azure'
    }

    asyncio.run(stream_chat(payload))

    # payload = {
    #     "query": "when did he die ?",
    #     "thread_id": "1004",
    #     "agent_name": "test",
    #     "temperature":0.34,
    #     "model_source":'aws'
    # }

    # asyncio.run(stream_chat(payload))
    # payload = {
    #     "query": "can you calculate the sum of 39 and 47 and then deduct 15.",
    #     "thread_id": "1004",
    #     "agent_name": "test",
    #     "temperature":0.34,
    #     "model_source":'azure'
    # }

    # asyncio.run(stream_chat(payload))

    # payload = {
    #     "query": "list me the tables in the database",
    #     "thread_id": "1005",
    #     "agent_name": "test3",
    #     "temperature":0.34,
    #     "model_source":'azure'
    # }

    # asyncio.run(stream_chat(payload))
    # payload = {
    #     "query": "list me the files in the path /app/data/database",
    #     "thread_id": "1004",
    #     "agent_name": "file_details",
    #     "temperature":0.50,
    #     "model_source":'aws'
    # }

    # asyncio.run(stream_chat(payload))

    # payload = {
    #     "query": "can you find me the number of records in the artists table",
    #     "thread_id": "1004",
    #     "agent_name": "test",
    #     "temperature":0.34,
    #     "model_source":'azure'
    # }

    # asyncio.run(stream_chat(payload))