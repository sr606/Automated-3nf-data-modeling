# agent_checkpointer.py
from langgraph.checkpoint.postgres.aio import AsyncPostgresSaver

DB_URI = "postgresql://omnicore:omnicore@localhost:5432/omnicore?sslmode=disable"

checkpointer: AsyncPostgresSaver | None = None