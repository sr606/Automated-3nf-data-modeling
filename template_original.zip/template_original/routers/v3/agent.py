import os
import asyncio
from typing import Annotated
from typing_extensions import TypedDict

from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.prebuilt import ToolNode, tools_condition

from langchain_core.tools import tool
from langchain_core.messages import SystemMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_azure_ai.chat_models import AzureAIChatCompletionsModel
from langchain_core.messages import (
    SystemMessage,
    BaseMessage,
    HumanMessage,
    AIMessage,
    ToolMessage,
    AIMessageChunk
)

from langgraph.types import interrupt
from phoenix.client import Client
from langchain_core.runnables import RunnableConfig, ConfigurableField
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_openai import AzureChatOpenAI
import sqlite3
import json
from datetime import datetime
import requests
from llm_mgmt import session_llm as sl
import aiosqlite
import httpx
from extractCodeBlock import extractCodeBlock
import routers.v3.agent_checkpointer as agent_checkpointer

from langchain_core.tools import StructuredTool
from typing import Any, Dict


# --------------------------------------------------------------------------
# PHOENIX TRACING SETUP
# --------------------------------------------------------------------------
trace_url = "https://o-phoenix.maitra.cloud/v1/traces"
phoenix_api_key = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiJBcGlLZXk6MSJ9.hQWH74arTLBrW0cBWoTRwCXDlutrZaeuCWwwlg3YWjo'
AGENT_API_BASE = "http://localhost:3655/v3/chat"
AGENT_API_KEY = "test-api-key-123"

# --------------------------------------------------------------------------
# AGENT CONFIG SETUP
# --------------------------------------------------------------------------
agent_mcp_url = 'https://o-agent-cofig.maitra.cloud/omnicoredb/config/api/v1/agentMCP/'

# --------------------------------------------------------------------------
# STATE
# --------------------------------------------------------------------------
class State(TypedDict):
    messages: Annotated[list, add_messages]

def wrap_mcp_tool_with_agent_session(tool, agent_session_id: str):
    async def _arun(**kwargs: Dict[str, Any]):
        tool_input = dict(kwargs)
        tool_input["agent_session_id"] = agent_session_id
        return await tool.arun(tool_input)   # ✅ FIX

    def _run(**kwargs: Dict[str, Any]):
        tool_input = dict(kwargs)
        tool_input["agent_session_id"] = agent_session_id
        return tool.run(tool_input)           # ✅ FIX

    return StructuredTool.from_function(
        func=_run,
        coroutine=_arun,
        name=tool.name,
        description=tool.description,
        args_schema=tool.args_schema,  # MUST keep this
    )

# --------------------------------------------------------------------------
# TOOLS
# --------------------------------------------------------------------------

@tool
def calculator(a: int, b: int, operator: str):
    """Basic calculator tool.
    Args :
        a = the first number
        b = the second number
        operator = the name of the operation, e.g. : add, multiply etc.
    """
    if operator == 'add':
        return a + b
    if operator == 'multiply':
        return a * b
    if operator == 'subtract':
        return a - b
    if operator == 'divide':
        return a / b
    raise ValueError("Unsupported operator")

TOOLS = [calculator]

# --------------------------------------------------------------------------
# MCP CONFIG HELPER
# --------------------------------------------------------------------------
async def get_mcp_config(agent_name: str, 
                         config_url: str,
                         agent_session_id: str) -> dict:
    """
    Get MCP server configuration for the given agent.
    """
    payload = {"agent_name": agent_name}
    result = {}

    try:
        async with httpx.AsyncClient(timeout=10) as client:
            response = await client.post(
                f"{config_url.rstrip('/')}/findmap/",
                json=payload
            )
            response.raise_for_status()
            data = response.json()

        for item in data:
            server_name = item.get("MCPserver")
            server_url = item.get("url")

            if not server_name or not server_url:
                print(f"Invalid MCP config item: {item}")
                continue

            result[server_name] = {
                "url": server_url,
                "transport": "streamable_http",
                "headers": {
                    "X-API-Key": "super_secret_value",
                    "X-Agent-Session-Id": agent_session_id
                }
            }

    except Exception as e:
        print("Failed to fetch MCP config")

    return result

async def get_tool_list(agent_name: str, agent_session_id: str):
    config_mcp_server = await get_mcp_config(agent_name, agent_mcp_url, agent_session_id)

    if not config_mcp_server:
        raise RuntimeError("No MCP servers configured")

    client = MultiServerMCPClient(config_mcp_server)
    tools_list = await client.get_tools()
    return tools_list

# --------------------------------------------------------------------------
# STARTING POINT
# --------------------------------------------------------------------------
async def create_agent(agent_name: str, model_source: str, thread_id: str):
    if agent_checkpointer.checkpointer is None:
        raise RuntimeError("Postgres checkpointer not initialized")

    mcp_tools = await get_tool_list(agent_name, thread_id)
    tool_map = {
        "db_details": ['list_tables','get_schema','run_query'],
        "file_details": ['list_files']
    }

    agent_tools = tool_map.get(agent_name)
    sel_tool_list = []

    if agent_tools:
        for i in mcp_tools:
            if i.name.split('_v1_')[0] in agent_tools:
                sel_tool_list.append(i)

    wrapped_tools = []

    for tool in sel_tool_list:
        wrapped_tools.append(
            wrap_mcp_tool_with_agent_session(
                tool,
                agent_session_id=thread_id
            )
        )

    tools = TOOLS + wrapped_tools   

    agent = PhoenixGraphAgent(agent_name, tools, model_source)

    agent.graph = agent.graph.compile(
        checkpointer=agent_checkpointer.checkpointer
    ).with_config({
        "run_name": agent_name,
        "parallel_tool_calls": False,
        "recursion_limit": 250
    })

    return agent

# --------------------------------------------------------------------------
# AGENT CLASS WITH USER_ID + PHOENIX TRACE
# --------------------------------------------------------------------------
class PhoenixGraphAgent:
    def __init__(self, agent_name: str,tools, model_source):
        self.agent_name = agent_name
        print("agent in action =====",agent_name)
        self.system_msg = self._get_system_prompt()
        self.model_source = model_source
        self.llm = sl.session_llm(model_source)
        self.tools = tools
        self.llm_with_tools = self.llm.bind_tools(self.tools)
        self.graph = self._build_graph()

    def is_text_a_dict(self, text: str) -> bool:
        """
        Check if a string is a JSON dict.
        Returns True if `text` can be parsed as a JSON dict, False otherwise.
        """
        if not isinstance(text, str):
            return False
        try:
            data = json.loads(text)
            if data["type"]=="Agent_Call":
                return True
            else:
                return False 
        except (json.JSONDecodeError, TypeError):
            try:
                code_blocks = extractCodeBlock(text)
                data = json.loads(code_blocks[0]['json'])
                if data["type"] == "Agent_Call":
                    return True
                else:
                    return False
            except:
                return False 

    # ----------------------------------------------------------------------
    # LOAD SYSTEM PROMPT
    # ----------------------------------------------------------------------
    def _get_system_prompt(self) -> str:
        try:
            client = Client(
                base_url="https://o-phoenix.maitra.cloud/",
                api_key="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiJBcGlLZXk6MSJ9.hQWH74arTLBrW0cBWoTRwCXDlutrZaeuCWwwlg3YWjo"
            )
            prompt_name = self.agent_name.lower().strip()
            prompt = client.prompts.get(prompt_identifier=prompt_name)
            prompt_set = prompt._template["messages"]
            prompt_msg = next(
                (item["content"][0]["text"]
                for item in prompt_set if item.get("role") == "system"),
                None
            )
            if not prompt_msg:
                raise ValueError(f"Invalid system prompt for {self.agent_name}")
        except Exception as e:
            print(e)
            prompt_msg = "You are an intelligent agent."
        return prompt_msg

    # ----------------------------------------------------------------------
    # NODE: CHATBOT WITH TRACE ANNOTATION
    # ----------------------------------------------------------------------
    async def chatbot(self, state: State, config: RunnableConfig):
        sanitized_messages = []
        for msg in state["messages"]:
            if isinstance(msg, ToolMessage):
                content = msg.content
                if not isinstance(content, str):
                    content = json.dumps(content)
                sanitized_messages.append(ToolMessage(
                    tool_call_id=msg.tool_call_id,
                    content=content
                ))
            else:
                sanitized_messages.append(msg)

        prompt = ChatPromptTemplate.from_messages([
            SystemMessage(content=self.system_msg),
            MessagesPlaceholder(variable_name="context", optional=True),
        ])

        messages = prompt.format_messages(context=sanitized_messages)
        
        final_msg = None
        async for chunk in self.llm_with_tools.astream(messages):
            yield {"messages": []}
            final_msg = chunk if final_msg is None else final_msg + chunk
            
        if final_msg:
            yield {"messages": [final_msg]}

    async def agent_call_node(self, state: State, config: RunnableConfig):
        last_msg = state["messages"][-1]
        # print(last_msg)
        try:
            payload = json.loads(last_msg.content)
        except Exception as e:
            print(e)
            return

        if payload.get("type") != "Agent_Call":
            return

        target_agent_name = payload.get("Agent_name")
        agent_message = payload.get("message", "")
        print('calling agent ===',target_agent_name)
        if not target_agent_name:
            state["messages"].append(
                AIMessage(content="Agent_Call missing Agent_name")
            )
            return

        thread_id = config["configurable"]["thread_id"]
        user_id = config["configurable"]["user_id"]

        request_payload = {
            "query": agent_message,
            "thread_id": thread_id,
            "agent_name": target_agent_name.lower(),
            "temperature":self.temperature,
            "model_source":self.model_source
        }

        headers = {
            "X-API-Key": AGENT_API_KEY,
            "Content-Type": "application/json"
        }

        final_content = ""

        async with httpx.AsyncClient(timeout=None) as client:
            async with client.stream(
                "POST",
                AGENT_API_BASE,
                json=request_payload,
                headers=headers,
            ) as response:

                async for chunk in response.aiter_text():
                    if not chunk:
                        continue

                    final_content += chunk

                    # stream token back into graph
                    yield {
                        "messages": [
                            AIMessageChunk(
                                content=chunk,
                                additional_kwargs={
                                    "delegated_agent": target_agent_name
                                }
                            )
                        ]
                    }

        # Append final AI message to state
        if final_content.strip():
            state["messages"].append(
                AIMessage(
                    content=final_content,
                    additional_kwargs={
                        "delegated_agent": target_agent_name
                    }
                )
            )

        return

    async def tools_condition(self, state:State, config: RunnableConfig):
        thread_id = config["configurable"].get("thread_id", "unknown_thread")
        user_id = config["configurable"].get("user_id", self.agent_name)
        if state["messages"][-1].tool_calls:
            return "tool_calls"
        elif self.is_text_a_dict(state["messages"][-1].content):
            return "Agent_Call"
        else:
            return "next"

    # ----------------------------------------------------------------------
    # BUILD GRAPH
    # ----------------------------------------------------------------------
    def _build_graph(self):
        tool_node = ToolNode(tools=self.tools)
        graph_builder = StateGraph(State)

        graph_builder.add_node("chatbot", self.chatbot)
        graph_builder.add_node("tools", tool_node)
        graph_builder.add_node("agent_call", self.agent_call_node)

        graph_builder.add_edge(START, "chatbot")

        graph_builder.add_conditional_edges(
            "chatbot",
            self.tools_condition,
            {
                "tool_calls": "tools",
                "Agent_Call": "agent_call",
                "next": END
            }
        )

        graph_builder.add_edge("tools", "chatbot")
        graph_builder.add_edge("agent_call", "chatbot")

        return graph_builder

    # ----------------------------------------------------------------------
    # RUN
    # ----------------------------------------------------------------------
    async def run(self, message: str, thread_id: str, user_id: str, temperature: float = 0.0):
        config = {
            "configurable": {
                "thread_id": thread_id,
                "user_id": user_id,
                "llm_temperature": temperature,
            }
        }
        self.temperature = temperature

        async for event in self.graph.astream_events(
            {"messages": [HumanMessage(content=message)]},
            config,
            version="v2",
            stream_mode=["messages"]
        ):
            yield event

# --------------------------------------------------------------------------
# MAIN EXAMPLE
# --------------------------------------------------------------------------
if __name__ == "__main__":
    async def main():
        agent = await create_agent("test2",'azure')

        # msgs = [
        #     "who is charlie chaplin in 1 line?",
        #     "when did he die?",
        #     "can you calculate the sum of 2 and 6 and then deduct 4 from it?",
        #     "what is the highest score of sachin tendulkar?",
        # ]

        # msgs = ["what are the tools available ?",
        #         "list me all the tables and their schemas."]

        # msgs = [
        #     "when did he retire from ODI?",
        #     "can you write me a code to identify palindrome strings."
        # ]

        # msgs = ["list me all the tables and their schemas."]

        msgs = ["who is charlie chaplin in 1 line?",
                "can you calculate the sum of 2 and 6 and then deduct 4 from it?",
                ]

        # msgs = ["can you calculate the sum of 25 and 62 and then deduct 41 from it?"]
        
        for m in msgs:
            print("\nUSER:", m)
            async for event in agent.run(
                message=m,
                thread_id="1004",
                user_id="user_abc_004",
                temperature=0.0
            ):
                if event["event"] == "on_chat_model_stream":
                    content = event["data"]["chunk"].content

                    # Case 1: content is a string
                    if isinstance(content, str):
                        print(content, end="", flush=True)

                    # Case 2: content is a list (e.g. [{"text": "..."}])
                    elif isinstance(content, list) and content:
                        value = content[0].get("text")
                        if value:
                            print(value, end="", flush=True)

                    # Case 3: content is None → do nothing safely
                    elif content is None:
                        pass


                if event["event"] == "on_tool_end":
                    metadata = event["data"].get("metadata", {}) or {}

                    mcp_session_id = (
                        metadata.get("mcp_session_id")
                        or metadata.get("session_id")
                        or metadata.get("mcp", {}).get("session_id")
                    )

                    if mcp_session_id:
                        print(f"[MCP SESSION ENDED] session_id={mcp_session_id}")

                    print(f'\ninput : {event["data"]["input"]}')
                    print(f'output : {event["data"]["output"].content}')

    asyncio.run(main())
