import asyncio
import json
import aiosqlite
import httpx
from typing import Annotated, TypedDict, List

from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode

from langchain_core.messages import (
    BaseMessage,
    HumanMessage,
    AIMessage,
    ToolMessage,
    SystemMessage,
    AIMessageChunk,
)
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.tools import tool
from langchain_core.runnables import RunnableConfig

from langchain_mcp_adapters.client import MultiServerMCPClient
from phoenix.client import Client

# from llm_mgmt import session_llm as sl
import session_llm as sl

# ==========================================================
# STATE
# ==========================================================

class State(TypedDict):
    messages: Annotated[List[BaseMessage], add_messages]


# ==========================================================
# MODEL-AWARE SANITIZER (KEY FIX)
# ==========================================================

def sanitize_messages(messages: List[BaseMessage], model_source: str):
    """
    Makes messages safe for AWS Claude while keeping Azure compatibility.
    """
    if model_source != "bedrock":
        return messages

    sanitized = []

    for msg in messages:
        if isinstance(msg, ToolMessage):
            content = msg.content
            if isinstance(content, (dict, list)):
                content = json.dumps(content)

            sanitized.append(
                ToolMessage(
                    content=str(content),
                    tool_call_id=msg.tool_call_id,
                    name=msg.name,
                )
            )

        elif isinstance(msg, AIMessage):
            sanitized.append(
                AIMessage(
                    content=msg.content,
                    tool_calls=msg.tool_calls,
                )
            )

        else:
            sanitized.append(msg)

    return sanitized


# ==========================================================
# TOOLS
# ==========================================================

from langchain.tools import tool
from pydantic import BaseModel

# Structured input model
class CalculatorInput(BaseModel):
    x: float
    y: float
    operation: str = "add"  # default to addition

# Tool definition
@tool
def calculator(input: CalculatorInput) -> str:
    """
    Performs a basic arithmetic operation on two numbers.
    Supported operations: add, subtract, multiply, divide.
    """
    x = input.x
    y = input.y
    op = input.operation.lower()

    if op == "add":
        return str(x + y)
    elif op == "subtract":
        return str(x - y)
    elif op == "multiply":
        return str(x * y)
    elif op == "divide":
        if y == 0:
            return "Error: Division by zero"
        return str(x / y)
    else:
        return f"Error: Unsupported operation '{op}'"


STATIC_TOOLS = [calculator]


# ==========================================================
# MCP TOOLS
# ==========================================================

async def get_mcp_tools(agent_name: str, config_url: str):
    async with httpx.AsyncClient(timeout=10) as client:
        resp = await client.post(
            f"{config_url.rstrip('/')}/findmap/",
            json={"agent_name": agent_name},
        )
        resp.raise_for_status()

    servers = {}
    for item in resp.json():
        servers[item["MCPserver"]] = {
            "url": item["url"],
            "transport": "streamable_http",
            "headers": {"X-API-Key": "super_secret_value"},
        }

    client = MultiServerMCPClient(servers)
    return await client.get_tools()


# ==========================================================
# AGENT
# ==========================================================

class PhoenixGraphAgent:
    def __init__(self, agent_name: str, tools, model_source: str):
        self.agent_name = agent_name
        self.model_source = model_source

        self.llm = sl.session_llm(model_source)
        self.llm_with_tools = self.llm.bind_tools(tools)
        self.tools = tools

        self.system_prompt = self._load_system_prompt()
        self.graph = self._build_graph()

    # ------------------------------------------------------
    # SYSTEM PROMPT
    # ------------------------------------------------------

    def _load_system_prompt(self) -> str:
        try:
            client = Client(
                base_url="https://o-phoenix.maitra.cloud/",
                api_key="YOUR_API_KEY",
            )
            prompt = client.prompts.get(self.agent_name.lower())
            return next(
                m["content"][0]["text"]
                for m in prompt._template["messages"]
                if m["role"] == "system"
            )
        except Exception:
            return "You are a helpful AI assistant."

    # ------------------------------------------------------
    # CHATBOT NODE
    # ------------------------------------------------------

    async def chatbot(self, state: State, config: RunnableConfig):
        prompt = ChatPromptTemplate.from_messages([
            SystemMessage(content=self.system_prompt),
            MessagesPlaceholder("context"),
        ])

        messages = prompt.format_messages(context=state["messages"])
        messages = sanitize_messages(messages, self.model_source)

        final = None
        async for chunk in self.llm_with_tools.astream(messages):
            yield {"messages": [chunk]}
            final = chunk if final is None else final + chunk

        if final:
            yield {"messages": [final]}

    # ------------------------------------------------------
    # ROUTING
    # ------------------------------------------------------

    def route(self, state: State):
        last = state["messages"][-1]
        if getattr(last, "tool_calls", None):
            return "tools"
        return "save"

    # ------------------------------------------------------
    # MEMORY (OPTIONAL)
    # ------------------------------------------------------

    async def save(self, state: State, config: RunnableConfig):
        return state

    # ------------------------------------------------------
    # GRAPH
    # ------------------------------------------------------

    def _build_graph(self):
        graph = StateGraph(State)

        graph.add_node("chatbot", self.chatbot)
        graph.add_node("tools", ToolNode(self.tools))
        graph.add_node("save", self.save)

        graph.add_edge(START, "chatbot")
        graph.add_conditional_edges("chatbot", self.route, {
            "tools": "tools",
            "save": "save",
        })
        graph.add_edge("tools", "chatbot")
        graph.add_edge("save", END)

        return graph.compile().with_config({
            "parallel_tool_calls": False,
            "recursion_limit": 200,
            "run_name": self.agent_name,
        })

    # ------------------------------------------------------
    # RUN
    # ------------------------------------------------------

    async def run(self, message: str, thread_id: str, user_id: str):
        config = {"configurable": {"thread_id": thread_id, "user_id": user_id}}

        state = {"messages": [HumanMessage(content=message)]}

        async for event in self.graph.astream_events(
            state,
            config,
            version="v2",
            stream_mode=["messages"],
        ):
            yield event


# ==========================================================
# FACTORY
# ==========================================================

async def create_agent(agent_name: str, model_source: str):
    MCP_URL = "https://o-agent-cofig.maitra.cloud/omnicoredb/config/api/v1/agentMCP/"
    mcp_tools = await get_mcp_tools(agent_name, MCP_URL)
    tools = STATIC_TOOLS + mcp_tools
    return PhoenixGraphAgent(agent_name, tools, model_source)


# ==========================================================
# MAIN
# ==========================================================

if __name__ == "__main__":
    def extract_text_from_chunk(chunk) -> str:
        """
        Safely extract displayable text from streaming chunks
        for both Azure ChatGPT and AWS Claude.
        """
        content = chunk.content

        # Case 1: simple string
        if isinstance(content, str):
            return content

        # Case 2: list (Claude/OpenAI structured stream)
        if isinstance(content, list):
            if not content:
                return ""  # ← THIS FIXES YOUR ERROR

            block = content[0]

            if isinstance(block, dict):
                return block.get("text", "") or ""

        return ""

    async def main():
        agent = await create_agent("test3", model_source="aws")  # or "azure"

        async for event in agent.run(
            # "can you calculate the sum of 2 and 6 and then deduct 4?",
            "list me the tables in the database",
            thread_id="1004",
            user_id="user_abc",
        ):
            if event["event"] == "on_chat_model_stream":
                chunk = event["data"]["chunk"]
                text = extract_text_from_chunk(chunk)
                if text:
                    print(text, end="", flush=True)
                else:
                    print(chunk.content or "", end="")

    asyncio.run(main())
