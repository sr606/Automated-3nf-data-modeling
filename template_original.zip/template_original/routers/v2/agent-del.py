import os
import asyncio
import json
import httpx
import aiosqlite
from typing import Annotated
from typing_extensions import TypedDict
from datetime import datetime

from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langgraph.prebuilt import ToolNode

from langchain_core.tools import tool
from langchain_core.messages import (
    BaseMessage,
    HumanMessage,
    AIMessage,
    ToolMessage,
    SystemMessage,
    AIMessageChunk,
)
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.runnables import RunnableConfig

from phoenix.client import Client
from langchain_mcp_adapters.client import MultiServerMCPClient

from extractCodeBlock import extractCodeBlock
from llm_mgmt import session_llm as sl

# --------------------------------------------------------------------------
# CONFIG
# --------------------------------------------------------------------------

AGENT_API_BASE = "http://localhost:3654/v2/chat"
AGENT_API_KEY = "test-api-key-123"
agent_mcp_url = "https://o-agent-cofig.maitra.cloud/omnicoredb/config/api/v1/agentMCP/"

# --------------------------------------------------------------------------
# STATE
# --------------------------------------------------------------------------

class State(TypedDict):
    messages: Annotated[list, add_messages]

# --------------------------------------------------------------------------
# TOOLS
# --------------------------------------------------------------------------

@tool
def calculator(a: int, b: int, operator: str):
    """Basic calculator tool.
    Args :
        a = the first number
        b = the second number
        operator = the name of the operation, e.g. : add, multiply etc.
    """
    if operator == "add":
        return a + b
    if operator == "subtract":
        return a - b
    if operator == "multiply":
        return a * b
    if operator == "divide":
        return a / b
    raise ValueError("Unsupported operator")

STATIC_TOOLS = [calculator]

# --------------------------------------------------------------------------
# MEMORY HELPERS
# --------------------------------------------------------------------------

def get_db_path(user_id: str):
    return f"./data/memory/memory_{user_id}.db"

async def ensure_session_table(db, session_id: str):
    await db.execute("PRAGMA journal_mode=WAL;")
    await db.execute(f"""
        CREATE TABLE IF NOT EXISTS session_{session_id} (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            type TEXT,
            role TEXT,
            content TEXT,
            additional_kwargs TEXT,
            response_metadata TEXT,
            usage_metadata TEXT,
            llm_id TEXT UNIQUE,
            tool_call_id TEXT,
            name TEXT,
            tool_calls TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        )
    """)

async def load_messages(session_id: str, user_id: str):
    async with aiosqlite.connect(get_db_path(user_id)) as db:
        await ensure_session_table(db, session_id)
        db.row_factory = aiosqlite.Row
        rows = await db.execute_fetchall(
            f"SELECT * FROM session_{session_id} ORDER BY id ASC"
        )

    messages = []
    for r in rows:
        messages.append(deserialize_message(dict(r)))
    return messages

def deserialize_message(data):
    msg_type = data["type"]
    content = data["content"]

    if msg_type == "HumanMessage":
        return HumanMessage(content=content)

    if msg_type == "AIMessage":
        return AIMessage(
            content=content,
            tool_calls=json.loads(data["tool_calls"]) if data["tool_calls"] else None,
        )

    if msg_type == "ToolMessage":
        return ToolMessage(
            content=content,
            tool_call_id=data["tool_call_id"],
            name=data["name"],
        )

    if msg_type == "SystemMessage":
        return SystemMessage(content=content)

    raise ValueError(f"Unknown message type: {msg_type}")

def serialize_message(msg, agent_name):
    return {
        "type": msg.__class__.__name__,
        "role": agent_name,
        "content": extract_text(msg.content),
        "additional_kwargs": json.dumps(getattr(msg, "additional_kwargs", {})),
        "response_metadata": json.dumps(getattr(msg, "response_metadata", {})),
        "usage_metadata": json.dumps(getattr(msg, "usage_metadata", {})),
        "llm_id": getattr(msg, "id", None),
        "tool_call_id": getattr(msg, "tool_call_id", None),
        "name": getattr(msg, "name", None),
        "tool_calls": json.dumps(getattr(msg, "tool_calls", None)),
    }

async def persist_messages(user_id, session_id, agent_name, messages):
    rows = [serialize_message(m, agent_name) for m in messages]
    async with aiosqlite.connect(get_db_path(user_id)) as db:
        await ensure_session_table(db, session_id)
        await db.executemany(
            f"""
            INSERT INTO session_{session_id}
            (type, role, content, additional_kwargs, response_metadata,
             usage_metadata, llm_id, tool_call_id, name, tool_calls)
            VALUES
            (:type, :role, :content, :additional_kwargs, :response_metadata,
             :usage_metadata, :llm_id, :tool_call_id, :name, :tool_calls)
            ON CONFLICT(llm_id) DO NOTHING
            """,
            rows,
        )
        await db.commit()

# --------------------------------------------------------------------------
# MCP
# --------------------------------------------------------------------------

async def get_mcp_config(agent_name):
    async with httpx.AsyncClient(timeout=10) as client:
        r = await client.post(
            f"{agent_mcp_url.rstrip('/')}/findmap/",
            json={"agent_name": agent_name},
        )
        r.raise_for_status()

    config = {}
    for item in r.json():
        config[item["MCPserver"]] = {
            "url": item["url"],
            "transport": "streamable_http",
            "headers": {"X-API-Key": "super_secret_value"},
        }
    return config

async def get_tools(agent_name):
    config = await get_mcp_config(agent_name)
    client = MultiServerMCPClient(config)
    return await client.get_tools()

# --------------------------------------------------------------------------
# CONTENT NORMALIZATION (KEY FIX)
# --------------------------------------------------------------------------

def extract_text(content):
    if content is None:
        return ""
    if isinstance(content, str):
        return content
    if isinstance(content, list):
        out = []
        for b in content:
            if isinstance(b, dict):
                out.append(b.get("text") or b.get("partial_json", ""))
        return "".join(out)
    return str(content)

def is_agent_call(content):
    text = extract_text(content)
    try:
        return json.loads(text).get("type") == "Agent_Call"
    except Exception:
        try:
            blocks = extractCodeBlock(text)
            return json.loads(blocks[0]["json"]).get("type") == "Agent_Call"
        except Exception:
            return False

# --------------------------------------------------------------------------
# AGENT
# --------------------------------------------------------------------------

class PhoenixGraphAgent:
    def __init__(self, agent_name, tools, model_source):
        self.agent_name = agent_name
        self.llm = sl.session_llm(model_source)
        self.llm_with_tools = self.llm.bind_tools(tools)
        self.system_msg = self._load_system_prompt()
        self.tools = tools
        self.graph = self._build_graph()

    def _load_system_prompt(self):
        try:
            client = Client(base_url="https://o-phoenix.maitra.cloud/")
            p = client.prompts.get(prompt_identifier=self.agent_name.lower())
            return next(
                m["content"][0]["text"]
                for m in p._template["messages"]
                if m["role"] == "system"
            )
        except Exception:
            return "You are an intelligent assistant."

    async def chatbot(self, state: State, config: RunnableConfig):
        prompt = ChatPromptTemplate.from_messages([
            SystemMessage(content=self.system_msg),
            MessagesPlaceholder("context"),
        ])

        messages = prompt.format_messages(context=state["messages"])

        final_chunks = []

        async for chunk in self.llm_with_tools.astream(messages):
            final_chunks.append(chunk)

            # 🔑 This is what FastAPI + LangGraph listens to
            yield {
                "event": "on_chat_model_stream",
                "data": {"chunk": chunk},
            }

        if final_chunks:
            final_text = "".join(extract_text(c.content) for c in final_chunks)

            yield {
                "messages": [
                    AIMessage(content=final_text)
                ]
            }


    async def route(self, state: State, config):
        last = state["messages"][-1]

        if last.additional_kwargs.get("tool_calls") or getattr(last, "tool_calls", None):
            return "tools"

        if is_agent_call(last.content):
            return "agent_call"

        return "save_memory"

    async def agent_call(self, state: State, config: RunnableConfig):
        payload = json.loads(extract_text(state["messages"][-1].content))
        target = payload["Agent_name"]
        msg = payload["message"]

        async with httpx.AsyncClient(timeout=None) as client:
            async with client.stream(
                "POST",
                AGENT_API_BASE,
                json={
                    "query": msg,
                    "agent_name": target,
                    "thread_id": config["configurable"]["thread_id"],
                    "model_source": "azure",
                },
                headers={"X-API-Key": AGENT_API_KEY},
            ) as r:
                async for t in r.aiter_text():
                    yield {"messages": [AIMessageChunk(content=t)]}

    async def save_memory(self, state: State, config):
        await persist_messages(
            config["configurable"]["user_id"],
            config["configurable"]["thread_id"],
            self.agent_name,
            state["messages"],
        )

    def _build_graph(self):
        g = StateGraph(State)
        g.add_node("chatbot", self.chatbot)
        g.add_node("tools", ToolNode(self.tools))
        g.add_node("agent_call", self.agent_call)
        g.add_node("save_memory", self.save_memory)

        g.add_edge(START, "chatbot")
        g.add_conditional_edges(
            "chatbot",
            self.route,
            {
                "tools": "tools",
                "agent_call": "agent_call",
                "save_memory": "save_memory",
            }
        )

        g.add_edge("tools", "chatbot")
        g.add_edge("agent_call", "chatbot")
        g.add_edge("save_memory", END)

        return g.compile()

    async def run(
        self,
        message: str,
        thread_id: str,
        user_id: str,
        temperature: float = 0.0,
    ):
        # Load history
        msgs = await load_messages(thread_id, user_id)
        msgs.append(HumanMessage(content=message))

        # Store temperature so model adapters can use it
        config = {
            "configurable": {
                "thread_id": thread_id,
                "user_id": user_id,
                "llm_temperature": temperature,
            }
        }

        async for event in self.graph.astream_events(
            {"messages": msgs},
            config,
            version="v2",
            stream_mode=["messages"],
        ):
            yield event


# --------------------------------------------------------------------------
# FACTORY
# --------------------------------------------------------------------------

async def create_agent(agent_name, model_source):
    mcp_tools = await get_tools(agent_name)
    return PhoenixGraphAgent(agent_name, STATIC_TOOLS + mcp_tools, model_source)
