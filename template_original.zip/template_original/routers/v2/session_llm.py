import os
from langchain.chat_models import init_chat_model
from langchain_core.runnables import ConfigurableField
 
 
def session_llm(model_source: str):
 
    if model_source == "azure":
        
        os.environ["AZURE_OPENAI_API_KEY"] = "65jy7TPBnrrwxQfcCUHWw1JltyzPw5SqeXgwvkXr4MyLwfBRCn2ZJQQJ99ALACYeBjFXJ3w3AAABACOGHblx"
        os.environ["AZURE_OPENAI_ENDPOINT"] = "https://tryout-genai-poc-v2.openai.azure.com"
        os.environ["AZURE_OPENAI_API_VERSION"] = "2024-08-01-preview"
        os.environ["AZURE_OPENAI_CHAT_DEPLOYMENT_NAME"] = "gpt-4o"
 
        llm = init_chat_model(
            model="gpt-4o",
            model_provider="azure_openai",
            azure_deployment="gpt-4o",
            openai_api_version="2024-08-01-preview",
            verbose=True,
        )
 
    elif model_source == "aws":
        # AWS credentials
        os.environ["AWS_ACCESS_KEY_ID"] = "AKIAY4QSMPEO5CE7Z7SI"
        os.environ["AWS_SECRET_ACCESS_KEY"] = "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"
        os.environ["AWS_DEFAULT_REGION"] = "us-east-2"
 
        llm = init_chat_model(
            model="us.anthropic.claude-sonnet-4-20250514-v1:0",
            model_provider="bedrock",
            region_name="us-east-2",
            # streaming=True,
            max_tokens=4096,
        )
 
    else:
        raise ValueError("Invalid model_source")
 
    # ✅ SAME configurable behavior as your original code
    llm = llm.configurable_fields(
        temperature=ConfigurableField(
            id="llm_temperature",
            name="LLM Temperature",
            description="The temperature of the LLM",
        )
    )
 
    return llm
# async def runllm(prompt):
#     async for chunk in llm.astream(prompt,config={"configurable": {"llm_temperature": 0.5}}):
#         print(chunk)

# if __name__ == "__main__":
 
#     from langchain_core.messages import HumanMessage
#     import asyncio

#     # model_source = "azure"  # or "aws"
#     model_source = "aws"
#     llm = session_llm(model_source)
#     prompt = [
#         HumanMessage(content="who is charlie chaplin in 1 line ?")
#         ]
 
#     # response = llm.invoke(prompt,config={"configurable": {"llm_temperature": 0.5}})
#     # print(response.content)

#     asyncio.run(runllm(prompt))