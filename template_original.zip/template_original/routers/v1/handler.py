from fastapi import APIRouter
from pydantic import BaseModel
from phoenix.otel import register
import os 
from routers.v1 import agent2 as agent
from openinference.instrumentation import using_attributes
from fastapi.responses import StreamingResponse
from fastapi import APIRouter, Depends

from auth.auth import get_current_user

router = APIRouter()

class InputData(BaseModel):
    query: str
    thread_id: str
    agent_name: str
    temperature:float
    model_source:str

async def get_response(msg,session_id,agent_name,user_id,temperature,model_source):
    o_agent = await agent.create_agent(agent_name,model_source)
    # with using_attributes(
    #     user_id=user_id,
    #     session_id=session_id
    # ):
    print("\n")
    async for event in o_agent.run(
        message=msg,
        thread_id=session_id,
        user_id=user_id,
        temperature=temperature
    ):

        if event["event"] == "on_chat_model_stream":
            content = event["data"]["chunk"].content

            # Case 1: content is a string
            if isinstance(content, str):
                yield content

            # Case 2: content is a list (e.g. [{"text": "..."}])
            elif isinstance(content, list) and content:
                value = content[0].get("text")
                if value:
                    yield value

            # Case 3: content is None → do nothing safely
            elif content is None:
                pass

        if event["event"] == "on_tool_end":
            yield(f'\n\ncalling tool :  {event["name"]}\n\n')
            yield(f'input : {event["data"]["input"]}\n\n')
            yield(f'output : {event["data"]["output"].content}\n\n')

@router.post("/chat")
async def chat_stream(input: InputData, userinfo: str = Depends(get_current_user)):
    trace_url = "https://o-phoenix.maitra.cloud/v1/traces"
    tracer_provider = register(
        project_name=input.agent_name,
        auto_instrument=True,
        batch=True,
        endpoint=trace_url,
        api_key='eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiJBcGlLZXk6MSJ9.hQWH74arTLBrW0cBWoTRwCXDlutrZaeuCWwwlg3YWjo'
    )
    return StreamingResponse(
        get_response(
            msg=input.query,
            session_id=input.thread_id,
            agent_name=input.agent_name,
            user_id=userinfo['sub'],
            temperature = input.temperature,
            model_source = input.model_source
        ),
        media_type="text/event-stream"
    )
