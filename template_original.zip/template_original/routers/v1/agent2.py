import os
import asyncio
from typing import Annotated
from typing_extensions import TypedDict

from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.prebuilt import ToolNode, tools_condition

from langchain_core.tools import tool
from langchain_core.messages import SystemMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_azure_ai.chat_models import AzureAIChatCompletionsModel
from langchain_core.messages import (
    SystemMessage,
    BaseMessage,
    HumanMessage,
    AIMessage,
    ToolMessage,
)

from langgraph.types import interrupt
from phoenix.client import Client
from langchain_core.runnables import RunnableConfig, ConfigurableField
from langchain_mcp_adapters.client import MultiServerMCPClient
from langchain_openai import AzureChatOpenAI
import sqlite3
import json
from datetime import datetime
import requests
from llm_mgmt import session_llm as sl
# import session_llm as sl
import aiosqlite

# --------------------------------------------------------------------------
# PHOENIX TRACING SETUP
# --------------------------------------------------------------------------
trace_url = "https://o-phoenix.maitra.cloud/v1/traces"
phoenix_api_key = 'eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiJBcGlLZXk6MSJ9.hQWH74arTLBrW0cBWoTRwCXDlutrZaeuCWwwlg3YWjo'

# --------------------------------------------------------------------------
# AGENT CONFIG SETUP
# --------------------------------------------------------------------------
agent_mcp_url = 'https://o-agent-cofig.maitra.cloud/omnicoredb/config/api/v1/agentMCP/'

# --------------------------------------------------------------------------
# STATE
# --------------------------------------------------------------------------
class State(TypedDict):
    messages: Annotated[list, add_messages]

# --------------------------------------------------------------------------
# TOOLS
# --------------------------------------------------------------------------
@tool
def human_assistance(query: str) -> str:
    """Requests human input."""
    return interrupt({"query": query})

@tool
def calculator(a: int, b: int, operator: str):
    """Basic calculator tool.
    Args :
        a = the first number
        b = the second number
        operator = the name of the operation, e.g. : add, multiply etc.
    """
    if operator == 'add':
        return a + b
    if operator == 'multiply':
        return a * b
    if operator == 'subtract':
        return a - b
    if operator == 'divide':
        return a / b
    raise ValueError("Unsupported operator")

TOOLS = [human_assistance, calculator]

# --------------------------------------------------------------------------
# MEMORY PERSISTANT HELPER
# --------------------------------------------------------------------------
def get_db_path(user_id: str):
    return f"./data/memory/memory_{user_id}.db"

async def ensure_session_table(db: aiosqlite.Connection, session_id: str):
    await db.execute("""
        PRAGMA journal_mode=WAL;
    """)

    await db.execute(f"""
        CREATE TABLE IF NOT EXISTS session_{session_id} (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            type TEXT NOT NULL,
            role TEXT,
            content TEXT,
            additional_kwargs TEXT,
            response_metadata TEXT,
            usage_metadata TEXT,
            llm_id TEXT UNIQUE,
            tool_call_id TEXT,
            name TEXT,
            tool_calls TEXT,
            timestamp DATETIME DEFAULT CURRENT_TIMESTAMP
        );
    """)


async def fetch_as_dicts(db, query):
    db.row_factory = aiosqlite.Row
    async with db.execute(query) as cursor:
        rows = await cursor.fetchall()
        return [dict(row) for row in rows]
    
async def load_messages(session_id: str, user_id: str) -> list:
    db_path = get_db_path(user_id)

    async with aiosqlite.connect(db_path) as db:
        await ensure_session_table(db, session_id)
        rows = await fetch_as_dicts(
            db,
            f"SELECT * FROM session_{session_id} ORDER BY id ASC"
        )

    history = []
    for row in rows:
        history.append(deserialize_message(row))

    return history

def deserialize_message(data: dict):
    """Convert stored message dict back into a LangChain message."""

    msg_type = data.get("type")

    if msg_type == "HumanMessage":
        return HumanMessage(
            content=data["content"],
            additional_kwargs=json.loads(data.get("additional_kwargs", {})),
            response_metadata=json.loads(data.get("response_metadata", {})),
            id=data.get("llm_id")
        )

    elif msg_type == "AIMessage":
        return AIMessage(
            content=data["content"],
            additional_kwargs=json.loads(data.get("additional_kwargs", {})),
            response_metadata=json.loads(data.get("response_metadata", {})),
            usage_metadata=json.loads(data.get("usage_metadata", {})),
            tool_calls = json.loads(data.get("tool_calls")),
            id=data.get("llm_id")
        )

    elif msg_type == "SystemMessage":
        return SystemMessage(
            content=data["content"],
            additional_kwargs=json.loads(data.get("additional_kwargs", {})),
            id=data.get("llm_id")
        )

    elif msg_type == "ToolMessage":
        return ToolMessage(
            content=data["content"],
            tool_call_id=data.get("tool_call_id"),
            name=data.get("name"),
            additional_kwargs=json.loads(data.get("additional_kwargs", {})),
            id=data.get("llm_id")
        )

    else:
        raise ValueError(f"Unknown message type during deserialization: {msg_type}")

def serialize_message(msg) :
    print("************************")
    print(msg)
    print("========================")
    if hasattr(msg,'tool_calls') or hasattr(msg, 'tool_use'):
        if type(msg.content) is list:
            try:
                content = msg.content[0]['text']
            except:
                content = msg.content[0]['partial_json']
        else :
            content = msg.content
        base = {
            "type": msg.__class__.__name__,
            "role": getattr(msg, "role", None),
            "content": content,
            "additional_kwargs": json.dumps(getattr(str(msg),"additional_kwargs",{})),
            "response_metadata": json.dumps(msg.response_metadata),
            "usage_metadata": json.dumps(getattr(msg, "usage_metadata", {})),
            "id": getattr(msg, "id", None),
            "tool_call_id": getattr(msg, "tool_call_id", None),
            "name": getattr(msg, "name", None),
            "tool_calls":json.dumps(getattr(msg, "tool_calls", None))
        }
    else :
        if type(msg.content) is list:
            content = msg.content[0]['text']
        else :
            content = msg.content

        base = {
            "type": msg.__class__.__name__,
            "role": getattr(msg, "role", None),
            "content": content,
            "additional_kwargs": json.dumps(getattr(msg,"additional_kwargs",{})),
            "response_metadata": json.dumps(msg.response_metadata),
            "usage_metadata": json.dumps(getattr(msg, "usage_metadata", {})),
            "id": getattr(msg, "id", None),
            "tool_call_id": getattr(msg, "tool_call_id", None),
            "name": getattr(msg, "name", None),
            "tool_calls":json.dumps(getattr(msg, "tool_calls", None))
        }
    return base

async def persist_messages(
    user_id: str,
    session_id: str,
    messages: list[BaseMessage],
):
    db_path = get_db_path(user_id)

    rows = []
    for msg in messages:
        rows.append(serialize_message(msg))

    async with aiosqlite.connect(db_path) as db:
        await ensure_session_table(db, session_id)

        await db.executemany(
            f"""
            INSERT INTO session_{session_id}
            (
                type,
                role,
                content,
                additional_kwargs,
                response_metadata,
                usage_metadata,
                llm_id,
                tool_call_id,
                name,
                tool_calls
            )
            VALUES (
                :type,
                :role,
                :content,
                :additional_kwargs,
                :response_metadata,
                :usage_metadata,
                :id,
                :tool_call_id,
                :name,
                :tool_calls
            )
            ON CONFLICT(llm_id) DO NOTHING
            """,
            rows,
        )

        await db.commit()


# --------------------------------------------------------------------------
# MCP CONFIG HELPER
# --------------------------------------------------------------------------

def get_mcp_config(agent_name: str, config_url: str) -> dict:
    """
    Get MCP server configuration for the given agent.
    
    Args:
        agent_name: Name of the agent
        config_url: Base URL of the configuration service
        
    Returns:
        dict: MCP configuration with server URLs and transport settings
    """
    try:
        payload = {"agent_name": agent_name}
        response = requests.post(config_url + "findmap/", json=payload)
        data = json.loads(response.text)
        
        result = {
            item["MCPserver"]: {
                "url": item["url"],
                "transport": "streamable_http"
            }
            for item in data
        }
    except:
        result = {}
    return result

async def get_tool_list(agent_name):
    url = agent_mcp_url
    config_mcp_server = get_mcp_config(agent_name,url)
    client = MultiServerMCPClient(config_mcp_server)
    tools_list = await client.get_tools()
    return tools_list

# --------------------------------------------------------------------------
# STARTING POINT
# --------------------------------------------------------------------------
async def create_agent(agent_name: str, model_source: str):
    mcp_tools = await get_tool_list(agent_name)
    tools = TOOLS + mcp_tools   # merge static + MCP tools
    return PhoenixGraphAgent(agent_name, tools, model_source)

# --------------------------------------------------------------------------
# AGENT CLASS WITH USER_ID + PHOENIX TRACE
# --------------------------------------------------------------------------
class PhoenixGraphAgent:
    def __init__(self, agent_name: str,tools, model_source):
        self.agent_name = agent_name
        self.system_msg = self._get_system_prompt()
        self.llm = sl.session_llm(model_source)
        self.tools = tools
        self.llm_with_tools = self.llm.bind_tools(self.tools)
        self.graph = self._build_graph()

    # ----------------------------------------------------------------------
    # LOAD SYSTEM PROMPT
    # ----------------------------------------------------------------------
    def _get_system_prompt(self) -> str:
        try:
            client = Client(
                base_url="https://o-phoenix2.maitra.cloud/",
                api_key="eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJqdGkiOiJBcGlLZXk6MSJ9.hQWH74arTLBrW0cBWoTRwCXDlutrZaeuCWwwlg3YWjo"
            )
            prompt_name = self.agent_name.lower().strip()
            prompt = client.prompts.get(prompt_identifier=prompt_name)
            prompt_set = prompt._template["messages"]

            prompt_msg = next(
                (item["content"][0]["text"]
                for item in prompt_set if item.get("role") == "system"),
                None
            )

            if not prompt_msg:
                raise ValueError(f"Invalid system prompt for {self.agent_name}")
        except:
            prompt_msg = "You are an intelligent agent."
        return prompt_msg

    # ----------------------------------------------------------------------
    # NODE: CHATBOT WITH TRACE ANNOTATION
    # ----------------------------------------------------------------------
    async def chatbot(self, state: State, config: RunnableConfig):
        # Extract contextual IDs
        thread_id = config["configurable"].get("thread_id", "unknown_thread")
        user_id = config["configurable"].get("user_id", self.agent_name)

        prompt = ChatPromptTemplate.from_messages([
            SystemMessage(content=self.system_msg),
            MessagesPlaceholder(variable_name="context", optional=True),
        ])

        messages = prompt.format_messages(context=state["messages"])
        final_msg = None

        async for chunk in self.llm_with_tools.astream(messages):
            # Each chunk is an AIMessageChunk
            final_msg = chunk if final_msg is None else final_msg + chunk
            yield {"messages": [chunk]}

        if final_msg:
            yield {"messages": [final_msg]}

    # ----------------------------------------------------------------------
    # NODE: PERSIST MEMORY
    # ----------------------------------------------------------------------
    async def save_memory_node(self, state, config):
        user_id = config["configurable"]["user_id"]
        session_id = config["configurable"]["thread_id"]

        await persist_messages(
            user_id,
            session_id,
            state["messages"]
        )
        return state
    
    # ----------------------------------------------------------------------
    # BUILD GRAPH
    # ----------------------------------------------------------------------
    def _build_graph(self):
        tool_node = ToolNode(tools=self.tools)
        graph_builder = StateGraph(State)

        graph_builder.add_node("chatbot", self.chatbot)
        graph_builder.add_node("save_memory", self.save_memory_node)
        graph_builder.add_node("tools", tool_node)

        graph_builder.add_edge(START, "chatbot")
        graph_builder.add_conditional_edges("chatbot", tools_condition)
        graph_builder.add_edge("tools", "chatbot")
        graph_builder.add_edge("chatbot", "save_memory")
        graph_builder.add_edge("save_memory", END)

        return graph_builder.compile().with_config({"run_name": self.agent_name,
                                                    "parallel_tool_calls": False,
                                                    "recursion_limit": 250})

    # ----------------------------------------------------------------------
    # RUN
    # ----------------------------------------------------------------------
    async def run(self, message: str, thread_id: str, user_id: str, temperature: float = 0.0):
        config = {"configurable": {
            "thread_id": thread_id,
            "user_id": user_id,
            "llm_temperature": temperature,
        }}
        msg = await load_messages(thread_id,user_id)
        msg.append(HumanMessage(content=message))
        async for event in self.graph.astream_events(
            {"messages": msg},
            config,
            version="v2",
            stream_mode=["messages"]
        ):
            yield event

# --------------------------------------------------------------------------
# MAIN EXAMPLE
# --------------------------------------------------------------------------
if __name__ == "__main__":
    async def main():
        agent = await create_agent("test2",'azure')

        # msgs = [
        #     "who is charlie chaplin in 1 line?",
        #     "when did he die?",
        #     "can you calculate the sum of 2 and 6 and then deduct 4 from it?",
        #     "what is the highest score of sachin tendulkar?",
        # ]

        # msgs = ["what are the tools available ?",
        #         "list me all the tables and their schemas."]

        # msgs = [
        #     "when did he retire from ODI?",
        #     "can you write me a code to identify palindrome strings."
        # ]

        # msgs = ["list me all the tables and their schemas."]

        msgs = ["who is charlie chaplin in 1 line?",
                "can you calculate the sum of 2 and 6 and then deduct 4 from it?",
                ]

        # msgs = ["can you calculate the sum of 25 and 62 and then deduct 41 from it?"]
        
        for m in msgs:
            print("\nUSER:", m)
            async for event in agent.run(
                message=m,
                thread_id="1004",
                user_id="user_abc_004",
                temperature=0.0
            ):
                if event["event"] == "on_chat_model_stream":
                    content = event["data"]["chunk"].content

                    # Case 1: content is a string
                    if isinstance(content, str):
                        print(content, end="", flush=True)

                    # Case 2: content is a list (e.g. [{"text": "..."}])
                    elif isinstance(content, list) and content:
                        value = content[0].get("text")
                        if value:
                            print(value, end="", flush=True)

                    # Case 3: content is None → do nothing safely
                    elif content is None:
                        pass


                if event["event"] == "on_tool_end":
                    print(f'\ninput : {event["data"]["input"]}')
                    print(f'output : {event["data"]["output"].content}')

    asyncio.run(main())
