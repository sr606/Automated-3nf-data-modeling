from fastapi import HTTPException, status, Security
from fastapi.security import APIKeyHeader
from keycloak import KeycloakOpenID
import json

def user_auth(user_id):
    # Configure keycloak client
    keycloak_openid = KeycloakOpenID(server_url="https://o-keycloak.maitra.cloud/",
                                    client_id="omnicore-access",
                                    realm_name="omnicore-realm",
                                    client_secret_key="oVpwUyF0qykPFwtAwQ1Nxxeb5NqYOJw8")

    token = keycloak_openid.token(user_id["user_name"], user_id["password"])

    userinfo = keycloak_openid.userinfo(token['access_token'])
    return userinfo

api_key_header = APIKeyHeader(
    name="X-API-Key",
    auto_error=False
)

with open('./data/api_key_store.json', 'r') as api_key_store:
    API_KEY_STORE = json.load(api_key_store)

async def get_current_user(
    api_key: str = Security(api_key_header)
) -> str:
    if not api_key:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="API key missing",
        )

    user_id = API_KEY_STORE.get(api_key)
    userinfo = user_auth(user_id)
    if not user_id:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail="Invalid API key",
        )

    return userinfo

if __name__ == '__main__':
    import asyncio
    user = asyncio.run( get_current_user("test-api-key-123"))
    print(user)