import os
from langchain_core.runnables import ConfigurableField

# --------------------------------------------------------------------------
# ENVIRONMENT CONFIG
# --------------------------------------------------------------------------


os.environ["AZURE_AI_ENDPOINT"] = "https://tryout-genai-poc-v2.cognitiveservices.azure.com/models"
os.environ["AZURE_AI_CREDENTIAL"] = "65jy7TPBnrrwxQfcCUHWw1JltyzPw5SqeXgwvkXr4MyLwfBRCn2ZJQQJ99ALACYeBjFXJ3w3AAABACOGHblx"

def session_llm(model_source):
    # self.llm = AzureAIChatCompletionsModel(
    #     model="gpt-4o",
    #     temperature=0.0,
    #     max_tokens=None,
    #     disable_streaming=False,
    # )
    if model_source == 'azure':
        from langchain_openai import AzureChatOpenAI

        os.environ["AZURE_OPENAI_API_KEY"] = "65jy7TPBnrrwxQfcCUHWw1JltyzPw5SqeXgwvkXr4MyLwfBRCn2ZJQQJ99ALACYeBjFXJ3w3AAABACOGHblx"
        os.environ["AZURE_OPENAI_ENDPOINT"] = "https://tryout-genai-poc-v2.openai.azure.com"
        os.environ["AZURE_OPENAI_API_VERSION"] = "2024-08-01-preview"
        os.environ["AZURE_OPENAI_CHAT_DEPLOYMENT_NAME"] = "gpt-4o"

        # llm = AzureChatOpenAI(
        #     openai_api_version=os.environ["AZURE_OPENAI_API_VERSION"],
        #     azure_deployment=os.environ["AZURE_OPENAI_CHAT_DEPLOYMENT_NAME"],
        #     verbose=True,
        #     max_tokens=None
        # ).configurable_fields(
        #         temperature=ConfigurableField(
        #                         id="llm_temperature",
        #                         name="LLM Temperature",
        #                         description="The temperature of the LLM",
        #                         )
        #         )
        from langchain_azure_ai.chat_models import AzureAIChatCompletionsModel
        llm = AzureAIChatCompletionsModel(
            model="gpt-4o",
            # temperature=0.00,
            max_tokens=None,
            disable_streaming=False
        ).configurable_fields(
                temperature=ConfigurableField(
                                id="llm_temperature",
                                name="LLM Temperature",
                                description="The temperature of the LLM",
                                )
                )


    if model_source == 'aws':
        from langchain_aws.chat_models import ChatBedrock

        os.environ["AWS_ACCESS_KEY_ID"] = "AKIAY4QSMPEO5CE7Z7SI"
        os.environ["AWS_SECRET_ACCESS_KEY"] = "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"

        llm = ChatBedrock(
            model_id = "us.anthropic.claude-sonnet-4-20250514-v1:0",
            region=os.getenv("AWS_REGION", "us-east-2"),
            streaming=True,
            model_kwargs={"max_tokens":65536}
        ).configurable_fields(
                temperature=ConfigurableField(
                                id="llm_temperature",
                                name="LLM Temperature",
                                description="The temperature of the LLM",
                                )
                )


    return llm

# if __name__ == '__main__':
