from fastapi import FastAPI
import uvicorn
from fastapi.middleware.cors import CORSMiddleware
from routers import catalog, validator, profiler
from fastapi_mcp import FastApiMCP
from dotenv import load_dotenv
import os
import logging
from pathlib import Path
from datetime import datetime

log_path = os.environ.get('BASE_LOG_PATH', './data/log')
Path(log_path).mkdir(parents=True, exist_ok=True)

# Create log files for different purposes
log_files = {
    "profiler_mcpserver": os.path.join(log_path, f"profiler_mcpserver_{datetime.now().strftime('%Y%m%d')}.log"),
}

def setup_logger(logger_name, log_file, level=logging.INFO):
    """
    Setup individual logger with file handler and stream handler.
    """
    logger = logging.getLogger(logger_name)
    logger.setLevel(level)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s - %(message)s')

    # File handler
    file_handler = logging.FileHandler(log_file)
    file_handler.setFormatter(formatter)

    # Stream handler
    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(formatter)

    # Add the handlers to the logger
    logger.addHandler(file_handler)
    logger.addHandler(stream_handler)

    return logger

# Create loggers for profiler, catalog, and validator
profiler_logger = setup_logger("profiler_mcpserver", log_files["profiler_mcpserver"])


profiler_logger.info("Profiler logger initialized.")

 

load_dotenv()
os.makedirs("./data/log", exist_ok=True)
# Shared CORS config
def apply_cors(app: FastAPI):
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

# Agent-specific sub-apps
def create_sub_app(title: str, description: str, version: str = "0.1.0") -> FastAPI:
    app = FastAPI(title=title, description=description, version=version)
    apply_cors(app)
    return app

# Main app
app = FastAPI()
apply_cors(app)

data_catalog = create_sub_app(
    title="Data Cataloger",
    description="Data Catalog tool that analyzes database tables and creates the data catalog.",
)

data_catalog.include_router(catalog.router)
FastApiMCP(data_catalog, include_operations=["available_catalog_sources", "get_metadata", "read_biz_context", "get_tables_list", "get_tables_metadata", "generate_catalog_file", "store_catalog"]).mount_http()
app.mount("/api/v1/catalog_data", data_catalog)

data_catalog_validator = create_sub_app(
    title="Data Catalog Validator",
    description="Catalog validation tool that analyzes generated data catalog and compares it with collibra catalog",
)

data_catalog_validator.include_router(validator.router)
FastApiMCP(data_catalog_validator, include_operations=["fetch_available_catalog_list", "get_catalog_tables_list", "generate_catalog_insight_file", "get_catalog_details", "store_catalog_insights"]).mount_http()
app.mount("/api/v1/catalog_validator", data_catalog_validator)


data_profiler = create_sub_app(
    title="Data Profiler",
    description="Data Profile tool that analyzes database data and creates the data profile report.",
)

data_profiler.include_router(profiler.router)
FastApiMCP(data_profiler, include_operations=["available_profile_sources", "generate_profile_file", "get_database_table_metadata", "get_profiling_table_names_list", "get_table_metadata", "execute_profiling_queries", "store_profile"]).mount_http()
app.mount("/api/v1/profile_data", data_profiler)

if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8099)
