import json
import os
from dotenv import load_dotenv
from typing import List
import csv
import psycopg2
from collections import defaultdict
from debug2 import debug2 as dbg
import traceback
from datetime import datetime


load_dotenv()


""""
**************************************
Data Catalog Generation Agent Tools
**************************************
"""

def list_databases():
    """
    Connects to a PostgreSQL RDS instance and lists all databases.
    """
    try:
        DB_HOST = "fanniedb.cwexu1ljahiz.us-east-2.rds.amazonaws.com"
        DB_PORT = "5432"
        DB_USER = "omnicoreuser"
        DB_PASSWORD = "Omnicore.1234"
        conn = psycopg2.connect(
            host=DB_HOST,
            port=DB_PORT,
            user=DB_USER,
            password=DB_PASSWORD,
            dbname="postgres"  # connect to default postgres db
        )
        cur = conn.cursor()
        cur.execute("SELECT datname FROM pg_database WHERE datistemplate = false;")
        databases = [row[0] for row in cur.fetchall()]
        cur.close()
        conn.close()
        exclude = {"postgres", "rdsadmin"}
        # logger.info(f"Successfully fetched {len(databases)} databases")
        return [db for db in databases if db not in exclude]

    except Exception as e:
        # logger.error(f"Error listing databases: {str(e)}", exc_info=True)
        print(f"Error: {e}")
        print("Database not found")
        return []
    

def fetch_metadata(metadata_filepath, db_name):
    """
    Connect to AWS RDS to get the metadata
    """
    try:

        DB_NAME = db_name
        DB_HOST = "fanniedb.cwexu1ljahiz.us-east-2.rds.amazonaws.com"
        DB_PORT = "5432"
        DB_USER = "omnicoreuser"
        DB_PASSWORD = "Omnicore.1234"
 
        conn = psycopg2.connect(
            host=DB_HOST,
            port=DB_PORT,
            dbname=DB_NAME,
            user=DB_USER,
            password=DB_PASSWORD
        )
        cur = conn.cursor()

        # Fetch all tables in public schema
        cur.execute("""
            SELECT table_name
            FROM information_schema.tables
            WHERE table_schema = 'public'
            ORDER BY table_name;
        """)
        tables = cur.fetchall()

        metadata = []

        for table in tables:
            table_name = table[0]

            # Fetch column metadata
            cur.execute("""
                SELECT column_name, data_type, is_nullable
                FROM information_schema.columns
                WHERE table_name = %s
                ORDER BY ordinal_position;
            """, (table_name,))
            columns = cur.fetchall()

            table_entry = {
                "Table_Name": table_name,
                "Columns": []
            }

            for col in columns:
                col_name, data_type, is_nullable = col
                col_entry = {
                    "Column_Name": col_name,
                    "DataType": data_type,
                    "Nullable": is_nullable
                }
                table_entry["Columns"].append(col_entry)

            metadata.append(table_entry)

        cur.close()
        conn.close()

        # Save to JSON file
        with open(metadata_filepath, "w", encoding="utf-8") as f:
            json.dump(metadata, f, indent=4)
        # logger.info(f"Metadata fetched for database: {db_name} - {len(metadata)} tables")
        return "Meta data fetch completed"
    except Exception as e:
        # logger.error(f"Error fetching metadata for {db_name}: {str(e)}", exc_info=True)
        print("❌ Error:", e)


def read_business_context(biz_context_path):  
    """
    Reads the Business Context necessary for data cataloging
    """
    try:
        with open(biz_context_path, 'r', encoding='utf-8') as f:
            content = f.read()
        # logger.info(f"Business context read from: {biz_context_path}")
        return content
    except Exception as e:
        # logger.error(f"Error reading business context: {str(e)}", exc_info=True)
        return ""


def get_list_of_tables(metadata_filepath):
    """
    Retrieves distinct table names from metadata JSON file.
    Assumes JSON file is a list of objects, each with 'Table_Name' and 'Columns'.
    """
    try:
        with open(metadata_filepath, "r") as f:
            data = json.load(f)
        
        table_names = set()
        for table in data:
            if isinstance(table, dict) and "Table_Name" in table:
                table_names.add(table["Table_Name"])
        # logger.info(f"Found {len(table_names)} tables in metadata file")
        return list(table_names)
    except Exception as e:
        # logger.error(f"Error getting list of tables: {str(e)}", exc_info=True)
        return []


def get_table_metadata_from_file(metadata_filepath, table_name):
    """
    Extract metadata for a specific table from the JSON file.
    JSON format: a list of objects, each with 'Table_Name' and 'Columns'.
    """
    # Load JSON file
    try:
        with open(metadata_filepath, "r") as f:
            data = json.load(f)
        
        for table in data:
            if isinstance(table, dict) and table.get("Table_Name") == table_name:
                # logger.info(f"Table metadata found for: {table_name}")
                return table
        
        raise ValueError(f"Table '{table_name}' not found in the file.")
    except Exception as e:
        # logger.error(f"Error getting table metadata for {table_name}: {str(e)}", exc_info=True)
        return {}


def create_storage_file(file_dir, file_name, file_format):
    """
    Generate file to store data catalog
    """
    try:
        file_path = os.path.join(file_dir, file_name)
        if file_format.lower() == "json":
            if not os.path.exists(file_path):
                with open(file_path, "w") as f:
                    json.dump({}, f)
            # logger.info(f"Storage file created: {file_name}")
            return "Generated"
        else:
            raise ValueError(f"Unsupported file format: {file_format}")
    except Exception as e:
        # logger.error(f"Error creating storage file: {str(e)}", exc_info=True)
        return "Error"



def convert_json_to_csv(input_json: str, output_csv: str) -> None:
    """
    Convert a JSON catalog file into a CSV file with predefined columns.
    """
    try:
        # Load JSON data
        with open(input_json, "r", encoding="utf-8") as f:
            data = json.load(f)

        # Define the required CSV columns
        fieldnames = [
            "Name", "Nick Name", "Sensitivity Label", "Status", "Definition", "Acronym", "Resources",
            "Related Terms", "Synonyms", "Stewards", "Experts", "Parent Term Name",
            "IsDefinitionRichText", "Term Template Names"
        ]

        rows = []
        for table in data:
            parent_term_name = table.get("Table_Name", "")
            for col in table.get("Columns", []):
                row = {
                    "Name": col.get("Column_Name", ""),
                    "Nick Name": col.get("Column_Name", ""),
                    "Sensitivity Label": col.get("Sensitivity_Label"),
                    "Status": "Draft",
                    "Definition": col.get("Definition", ""),
                    "Acronym": "",     
                    "Resources": "",   
                    "Related Terms": "", 
                    "Synonyms": "",      
                    "Stewards": "catalog_agent@omnicore.com",
                    "Experts": "catalog_agent@omnicore.com",
                    "Parent Term Name": parent_term_name,
                    "IsDefinitionRichText": "", 
                    "Term Template Names": ""   
                }
                rows.append(row)

        # Write to CSV
        with open(output_csv, "w", newline='', encoding="utf-8") as csvfile:
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            for row in rows:
                writer.writerow(row)
        # logger.info(f"CSV file created successfully: {output_csv}")
        print(f"CSV file '{output_csv}' created successfully.")
    except Exception as e:
        return "Error"
        # logger.error(f"Error converting JSON to CSV: {str(e)}", exc_info=True)

def store_data(store_data: List[str], json_output_filepath: str = None):
    """
    Extracts data catalog from provided JSON strings and stores them in a JSON file (append if exists)
    """
    try:
        # Parse all incoming items
        parsed_data = []
        for item in store_data:
            obj = json.loads(item)
            # Normalize acceptable shapes: either a single table dict or a list of table dicts
            if isinstance(obj, list):
                parsed_data.extend(obj)
            else:
                parsed_data.append(obj)

        # Ensure directory exists
        os.makedirs(os.path.dirname(json_output_filepath), exist_ok=True)

        # Load existing data if file exists
        existing_data = []
        if os.path.isfile(json_output_filepath) and os.path.getsize(json_output_filepath) > 0:
            with open(json_output_filepath, mode='r', encoding='utf-8') as jsonfile:
                try:
                    existing_data = json.load(jsonfile)
                except json.JSONDecodeError:
                    # Corrupted file; start fresh
                    existing_data = []

        # Normalize existing_data to a list of table dicts
        if isinstance(existing_data, dict):
            # If someone stored a dict wrapper, try to unwrap common keys
            # Example: {"Tables": [...]} or {"Table_Metadata": {...}} -> we want a list of tables
            if "Tables" in existing_data and isinstance(existing_data["Tables"], list):
                existing_data = existing_data["Tables"]
            else:
                # If it's a single table dict, wrap; otherwise discard
                if "Table_Name" in existing_data and "Columns" in existing_data:
                    existing_data = [existing_data]
                else:
                    existing_data = []

        # Merge new data
        merged = existing_data + parsed_data

        # Write merged JSON
        with open(json_output_filepath, mode='w', encoding='utf-8') as jsonfile:
            json.dump(merged, jsonfile, indent=4, ensure_ascii=False)
        # logger.info(f"Data stored successfully in: {json_output_filepath}")
        return "Stored"

    except Exception as e:
        # logger.error(f"Error storing data: {str(e)}", exc_info=True)
        return {"Error": str(e)}
    
"""
**************************************
Data Catalog Validation Agent Tools
**************************************
"""
def fetch_catalog_details(json_file_path, table_name):
    """
    Fetch details (Table Name, Column Name, Description) for a specified table 
    from a JSON file containing table metadata.
    
    Parameters:
        json_file (str): Path to the JSON file
        table_name (str): Name of the table to fetch details for
    
    Returns:
        dict: Dictionary containing table name and list of column details
    """
    try:
        # Open and load JSON file
        with open(json_file_path, 'r') as f:
            data = json.load(f)
        
        # Search for the specified table
        for table in data:
            if table["Table_Name"].lower() == table_name.lower():
                # Extract required details
                details = {
                    "Table_Name": table["Table_Name"],
                    "Columns": [
                        {
                            "Column_Name": col["Column_Name"],
                            "Definition": col["Definition"],
                            "Sensitivity_Label": col["Sensitivity_Label"]
                        }
                        for col in table["Columns"]
                    ]
                }
                # logger.info(f"Catalog details fetched for table: {table_name}")
                return details
    
    except Exception as e:
        # logger.error(f"Error fetching catalog details for {table_name}: {str(e)}", exc_info=True)
        return {"Error": str(e)}
    

def governance_csv_to__json(csv_file_path, json_file_path=None):
    """
    Convert a Governance Catalog CSV file into JSON grouped by Parent Term Name,
    with explicit Parent Term Name and nested Columns.
    """
    try:
        grouped_data = defaultdict(list)

        with open(csv_file_path, mode="r", encoding="utf-8-sig") as csv_file:
            reader = csv.DictReader(csv_file)
            for row in reader:
                parent = row.get("Parent Term Name", "Unknown")
                grouped_data[parent].append(row)

        # Transform into desired structure
        result = []
        for parent, rows in grouped_data.items():
            result.append({
                "Parent Term Name": parent,
                "Columns": rows
            })

        # Save to file if path provided
        if json_file_path:
            with open(json_file_path, mode="w", encoding="utf-8") as json_file:
                json.dump(result, json_file, indent=4)
        # logger.info(f"Governance CSV converted to JSON: {json_file_path}")
    except Exception as e:
        return "Error"
        # logger.error(f"Error converting governance CSV to JSON: {str(e)}", exc_info=True)


def fetch_governance_catalog_details(user_id, governance_catalog_filename, table_name):
    """
    Fetch Name and Definition for all columns under a specific Parent Term Name
    from a JSON file.

    Parameters:
        json_file_path (str): Path to the JSON file.
        parent_term_name (str): The Parent Term Name to filter.

    Returns:
        dict: A dictionary with Parent Term Name and a list of {Name, Definition}.
    """
    try:
        # Load JSON file
        governance_catalog_dir = os.path.join(
            os.getenv("UPLOAD_BASE_PATH"),
            f"data_catalog/{user_id}/governance_catalog/"
        )
        os.makedirs(governance_catalog_dir, exist_ok=True)

        base = os.path.splitext(governance_catalog_filename)[0]
        governance_catalog_json_filename = f"{base}.json"
        governance_catalog_json_filepath = os.path.join(governance_catalog_dir, governance_catalog_json_filename)

        if not os.path.exists(governance_catalog_json_filepath):
            governance_catalog_csv_filepath = os.path.join(governance_catalog_dir, governance_catalog_filename)
            governance_csv_to__json(governance_catalog_csv_filepath, governance_catalog_json_filepath)
            

        with open(governance_catalog_json_filepath, mode="r", encoding="utf-8") as f:
            json_data = json.load(f)

        # Search for the parent term
        for entry in json_data:
            if entry.get("Parent Term Name") == table_name:
                columns = entry.get("Columns", [])
                filtered_columns = [
                    {
                        "Column_Name": col.get("Name"), 
                        "Definition": col.get("Definition"),
                        "Sensitivity_Label": col.get("Sensitivity Label")
                    }
                    for col in columns
                ]
                # logger.info(f"Governance catalog details fetched for: {table_name}")
                return {
                    "Table_Name": table_name,
                    "Columns": filtered_columns
                }
        
        return None
    except Exception as e:
        # logger.error(f"Error fetching governance catalog details: {str(e)}", exc_info=True)
        return None


def list_files_in_directory(directory_path):
    """
    List all files in the given directory.
    """
    try:
        entries = os.listdir(directory_path)
        files = [f for f in entries if os.path.isfile(os.path.join(directory_path, f))]
        # logger.info(f"Listed {len(files)} files in directory: {directory_path}")
        return files
    except Exception as e:
        # logger.error(f"Error listing files in directory: {str(e)}", exc_info=True)
        return []


"""
**************************************
Data Profiler Agent Tools
**************************************
"""
def execute_queries(queries, db_name, output_file=None):
    """
    Execute a list of SQL queries against an RDS PostgreSQL database and store results.
    """
    results = []
    try:
        # Connect to the RDS PostgreSQL database
        DB_NAME = db_name
        DB_HOST = "fanniedb.cwexu1ljahiz.us-east-2.rds.amazonaws.com"
        DB_PORT = "5432"
        DB_USER = "omnicoreuser"
        DB_PASSWORD = "Omnicore.1234"

        conn = psycopg2.connect(
            host=DB_HOST,
            port=DB_PORT,
            dbname=DB_NAME,
            user=DB_USER,
            password=DB_PASSWORD
        )
        cursor = conn.cursor()
        
        for query in queries:
            try:
                cursor.execute(query)
                # Fetch results if it's a SELECT query
                if query.strip().lower().startswith("select"):
                    rows = cursor.fetchall()
                    results.append({
                        "query": query,
                        "result": rows
                    })
                else:
                    # For non-SELECT queries (INSERT, UPDATE, DELETE, etc.)
                    conn.commit()
                    results.append({
                        "query": query,
                        "result": f"{cursor.rowcount} rows affected"
                    })
            except psycopg2.Error as e:
                # Append error details for this query
                results.append({
                    "query": query,
                    "error": str(e)
                })
        
        # Close the cursor and connection
        cursor.close()
        conn.close()
        
        # Save results to a JSON file if specified
        if output_file:
            with open(output_file, "w", encoding="utf-8") as f:
                json.dump(results, f, indent=4)
        # logger.info(f"Executed {len(queries)} queries on database: {db_name}")
        return results

    except Exception as e:
        # logger.error(f"Error executing queries on {db_name}: {str(e)}", exc_info=True)
        print(f"❌ Error connecting to the database: {e}")
        return {"error": str(e)}


def get_or_create_file(agent_name, tool_name):
    """
    Function to create a JSON file using the tool name and current date.
    If the file exists, return the file name; otherwise, create the file.
    """
    execution_id = datetime.now().strftime('%Y-%m-%d')
    file_name = f"{tool_name}_{execution_id}"
    file_path = os.path.join(os.getenv("LOG_BASE_PATH", "./data/logs/"), agent_name, file_name)
    os.makedirs(os.path.dirname(file_path), exist_ok=True)
    return file_path