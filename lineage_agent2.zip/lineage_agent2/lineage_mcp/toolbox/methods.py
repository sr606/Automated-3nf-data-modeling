import os
import json
import uuid
import re
import hashlib
from collections import defaultdict
from pathlib import Path
from dotenv import load_dotenv
from xml.sax.saxutils import escape
import networkx as nx
try:
    from langchain_openai import AzureChatOpenAI
except ImportError:
    AzureChatOpenAI = None

try:
    from sql_metadata import Parser
except ImportError:
    Parser = None

try:
    import graphviz
except ImportError:
    graphviz = None

load_dotenv()

SERVICE_ROOT = Path(__file__).resolve().parents[1]
DATA_ROOT = str((SERVICE_ROOT / "data").resolve())
UPLOAD_BASE_PATH = str((SERVICE_ROOT / "data" / "uploads").resolve())
OUTPUT_BASE_PATH = str((SERVICE_ROOT / "data" / "output").resolve())
LOG_BASE_PATH = str((SERVICE_ROOT / "data" / "logs").resolve())
_SEMANTIC_LLM = None


"""
**************************************
Lineage Agent Helper Methods
**************************************
"""


# -----------------------------------------------------
# Utility
# -----------------------------------------------------

def write_json(path, data):
    """
    Write JSON safely while ensuring directory exists.
    """
    os.makedirs(os.path.dirname(path), exist_ok=True)

    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)


def read_json(path):
    """
    Read JSON safely. Returns empty list if file not found.
    """
    if not path or not os.path.exists(path):
        return []

    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


def require_existing_file(path, label):
    """
    Validate that an expected input file exists.
    """

    if not path:
        raise FileNotFoundError(f"Missing required {label}.")

    if not os.path.exists(path):
        raise FileNotFoundError(f"{label} not found: {path}")

    return path


def normalize_lineage_options(options=None):
    """
    Normalize lineage rendering and semantic-enrichment options with stable defaults.
    """

    defaults = {
        "diagram_mode": "logical",
        "include_sql_sources": False,
        "collapse_intermediate_datasets": True,
        "include_lookup_nodes": True,
        "llm_role_classification": False,
        "llm_business_labels": False,
        "llm_sql_grouping": False,
    }

    if not options:
        return defaults

    normalized = defaults.copy()

    for key, value in options.items():
        if value is not None:
            normalized[key] = value

    normalized["diagram_mode"] = str(normalized["diagram_mode"]).lower()

    return normalized


def _safe_source_key(value):
    """
    Normalize a source file identifier for grouping.
    """

    return os.path.basename(value or "lineage")


def _graphs_payload(entries):
    """
    Wrap a list of per-source graph entries in a stable envelope.
    """

    return {"graphs": entries}


def _is_graphs_payload(payload):
    """
    Return True when payload already contains per-source graph entries.
    """

    return isinstance(payload, dict) and isinstance(payload.get("graphs"), list)


def _payload_graphs(payload):
    """
    Read a per-source graph envelope and return its entries.
    """

    if _is_graphs_payload(payload):
        return payload.get("graphs", [])

    return []


def _json_string(data):
    """
    Serialize structured data consistently for tool outputs that expect strings.
    """

    return json.dumps(data, indent=2)


def _lineage_complexity(node_count, edge_count):
    """
    Classify lineage size to drive abstraction and routing heuristics.
    """

    if node_count <= 8 and edge_count <= 8:
        return "small"

    if node_count <= 18 and edge_count <= 22:
        return "medium"

    return "large"


def _display_label(node):
    """
    Build a render label that preserves the original node name and appends semantic context.
    """

    base_label = str(node.get("label") or node.get("id") or "").strip()
    details = [str(item).strip() for item in node.get("details", []) if str(item).strip()]

    if not details:
        return base_label

    return "\n".join([base_label] + details)


def _make_node(node_id, node_type, label=None, details=None, **extra):
    """
    Create a lineage node with stable label and lightweight metadata.
    """

    node = {
        "id": node_id,
        "type": node_type,
        "label": label or node_id,
        "details": list(details or []),
    }
    node.update(extra)
    return node


def build_lineage_diagram_filename(source_files, options=None, extension=".drawio"):
    """
    Build a deterministic diagram filename for the same inputs and options.
    """

    normalized_options = normalize_lineage_options(options)
    safe_sources = sorted(source_files or ["lineage"])
    base_name = "_".join(os.path.splitext(os.path.basename(item))[0] for item in safe_sources[:3])
    base_name = re.sub(r'[^A-Za-z0-9._-]+', "_", base_name).strip("._") or "lineage"
    fingerprint_payload = {
        "source_files": safe_sources,
        "options": normalized_options,
    }
    fingerprint = hashlib.md5(
        json.dumps(fingerprint_payload, sort_keys=True).encode("utf-8")
    ).hexdigest()[:10]

    return f"{base_name}_{fingerprint}{extension}"




def _deduplicate_edges(edges):
    """
    Remove duplicate edges while preserving order.
    """

    deduped = []
    seen = set()

    for edge in edges:
        key = (
            edge.get("source", ""),
            edge.get("target", ""),
            edge.get("kind", ""),
            edge.get("label", ""),
        )

        if key in seen:
            continue

        seen.add(key)
        deduped.append(edge)

    return deduped


def _node_detail_lines(stage_meta, node_type):
    """
    Build lightweight display details from already-extracted stage semantics.
    """

    detail_map = {
        "SOURCE": ["Source table"],
        "SOURCE_GROUP": ["Grouped upstream sources"],
        "EXTRACT": ["Source extract"],
        "TRANSFORM": ["Transformation"],
        "DECISION": ["Conditional transform"],
        "LOOKUP": ["Lookup"],
        "STORE": ["Store"],
        "DB_TARGET": ["Final target"],
        "FILE_TARGET": ["File target"],
        "TARGET": ["Target"],
        "EXCEPTION": ["Exception output"],
        "DATASET": ["Intermediate dataset"],
    }
    details = list(detail_map.get(node_type, []))
    for item in (stage_meta or {}).get("constraints", [])[:2]:
        expression = str(item.get("expression") or "").strip()
        if expression:
            details.append(f"Condition: {expression[:80]}")
    return details


def _normalize_stage_role(stage_meta):
    """
    Trust the LLM-provided stage type and only sanitize it into the supported node set.
    """

    allowed = {
        "SOURCE", "SOURCE_GROUP", "EXTRACT", "LOOKUP", "STORE",
        "TRANSFORM", "DECISION", "DB_TARGET", "FILE_TARGET",
        "TARGET", "EXCEPTION", "DATASET",
    }
    raw_role = str((stage_meta or {}).get("stage_type") or "").strip().upper()
    alias_map = {
        "FILE SOURCE": "SOURCE",
        "DATABASE SOURCE": "SOURCE",
        "SOURCE DEFINITION": "SOURCE",
        "SOURCE": "SOURCE",
        "SOURCE_QUALIFIER": "EXTRACT",
        "SOURCE QUALIFIER": "EXTRACT",
        "XML SOURCE QUALIFIER": "EXTRACT",
        "EXTRACT": "EXTRACT",
        "LOOKUP": "LOOKUP",
        "STORE": "STORE",
        "TRANSFORM": "TRANSFORM",
        "TRANSFORMATION": "TRANSFORM",
        "JOINER": "TRANSFORM",
        "SORTER": "TRANSFORM",
        "EXPRESSION": "TRANSFORM",
        "TARGET": "TARGET",
        "TARGET DEFINITION": "TARGET",
        "DB_TARGET": "DB_TARGET",
        "FILE_TARGET": "FILE_TARGET",
        "DATASET": "DATASET",
    }
    role = alias_map.get(raw_role, raw_role)
    return role if role in allowed else "TRANSFORM"


def _edge_kind_from_input(entry, target_stage=None, source_stage=None):
    """
    Classify relationship label from an input link.
    """

    alias = (entry.get("alias") or "").lower()
    link_name = (entry.get("link_name") or "").lower()
    target_stage_type = (target_stage.get("stage_type") or "").lower() if target_stage else ""
    target_stage_kind = (target_stage.get("stage_kind") or "").lower() if target_stage else ""
    source_role = _normalize_stage_role(source_stage)

    if any(token in alias or token in link_name for token in ("reject", "error", "err_", "rej_")):
        return "exception"

    if _normalize_stage_role(target_stage) in {"LOOKUP", "STORE"}:
        return "input"

    if source_role == "LOOKUP":
        return "lookup"

    if "lookup" in alias or "lookup" in link_name:
        return "lookup"

    return "input"


def _get_semantic_llm():
    """
    Create a cached Azure OpenAI client for semantic enrichment.
    """

    global _SEMANTIC_LLM

    if _SEMANTIC_LLM is not None:
        return _SEMANTIC_LLM

    if AzureChatOpenAI is None:
        return None

    deployment = os.getenv("AZURE_OPENAI_CHAT_DEPLOYMENT_NAME")
    version = os.getenv("AZURE_OPENAI_API_VERSION")
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    api_key = os.getenv("AZURE_OPENAI_API_KEY")

    if not all([deployment, version, endpoint, api_key]):
        return None

    _SEMANTIC_LLM = AzureChatOpenAI(
        azure_deployment=deployment,
        openai_api_version=version,
        azure_endpoint=endpoint,
        api_key=api_key,
        temperature=0.0,
    )
    return _SEMANTIC_LLM


def _extract_json_object(text):
    """
    Extract the first JSON object from a model response.
    """

    if not text:
        return {}

    text = text.strip()

    try:
        return json.loads(text)
    except Exception:
        pass

    start = text.find("{")
    end = text.rfind("}")

    if start == -1 or end == -1 or end <= start:
        return {}

    try:
        return json.loads(text[start:end + 1])
    except Exception:
        return {}


def _collapse_semantic_nodes(edges, nodes, removable_types):
    """
    Collapse helper nodes while preserving lineage flow.
    """

    node_type_map = {node["id"]: node["type"] for node in nodes}
    incoming = defaultdict(list)
    outgoing = defaultdict(list)

    for edge in edges:
        incoming[edge["target"]].append(edge)
        outgoing[edge["source"]].append(edge)

    collapsed_edges = []
    removed_nodes = set()

    for node_id, node_type in node_type_map.items():
        if node_type not in removable_types:
            continue

        parents = incoming.get(node_id, [])
        children = outgoing.get(node_id, [])

        if not parents or not children:
            continue

        removed_nodes.add(node_id)

        for parent in parents:
            for child in children:
                edge_kind = "lookup" if node_type == "LOOKUP" else child.get("kind", parent.get("kind", "flow"))
                collapsed_edges.append({
                    "source": parent["source"],
                    "target": child["target"],
                    "kind": edge_kind,
                })

    passthrough_edges = [
        edge for edge in edges
        if edge["source"] not in removed_nodes and edge["target"] not in removed_nodes
    ]

    final_nodes = [node for node in nodes if node["id"] not in removed_nodes]

    return final_nodes, _deduplicate_edges(passthrough_edges + collapsed_edges)


def _build_dataset_graph(stages, tables, options):
    """
    Build a technical graph that keeps intermediate dataset nodes visible.
    """

    nodes = {}
    edges = []
    dataset_aliases = {}
    dataset_consumers = defaultdict(list)
    stage_inbound = defaultdict(int)
    stage_outbound = defaultdict(int)
    table_targets = defaultdict(set)

    for stage in stages:
        stage_name = stage["stage"]

        for output in stage.get("outputs", []):
            dataset_id = output.get("dataset_id")
            alias = output.get("alias") or dataset_id
            if dataset_id:
                dataset_aliases[dataset_id] = alias

        for inp in stage.get("inputs", []):
            dataset_id = inp.get("dataset_id")
            if dataset_id:
                dataset_consumers[dataset_id].append({
                    "stage": stage_name,
                    "kind": _edge_kind_from_input(inp, stage, None),
                })

    for stage in stages:
        stage_name = stage["stage"]
        stage_role = _normalize_stage_role(stage)
        nodes.setdefault(
            stage_name,
            _make_node(
                stage_name,
                stage_role,
                label=stage.get("display_name") or stage_name,
                details=_node_detail_lines(stage, stage_role),
            ),
        )

        for output in stage.get("outputs", []):
            dataset_id = output.get("dataset_id")
            alias = output.get("alias") or dataset_id
            dataset_node = alias or dataset_id

            if not dataset_id or not dataset_node:
                continue

            nodes.setdefault(dataset_node, _make_node(dataset_node, "DATASET", details=_node_detail_lines({}, "DATASET")))
            edges.append({
                "source": stage_name,
                "target": dataset_node,
                "kind": "flow",
            })
            stage_outbound[stage_name] += 1

        for inp in stage.get("inputs", []):
            dataset_id = inp.get("dataset_id")
            dataset_node = dataset_aliases.get(dataset_id) or inp.get("alias") or dataset_id

            if not dataset_id or not dataset_node:
                continue

            nodes.setdefault(dataset_node, _make_node(dataset_node, "DATASET", details=_node_detail_lines({}, "DATASET")))
            edges.append({
                "source": dataset_node,
                "target": stage_name,
                "kind": _edge_kind_from_input(inp, stage, None),
            })
            stage_inbound[stage_name] += 1

    for table in tables:
        table_name = table.get("table")
        stage_name = table.get("stage")
        if not table_name or not stage_name:
            continue
        if stage_inbound.get(stage_name, 0) > 0 and not options.get("include_sql_sources"):
            continue
        nodes.setdefault(table_name, _make_node(table_name, "SOURCE", details=_node_detail_lines({}, "SOURCE")))
        table_targets[table_name].add(stage_name)

    for table_name, stage_names in table_targets.items():
        for stage_name in sorted(stage_names):
            edges.append({
                "source": table_name,
                "target": stage_name,
                "kind": "sql_source",
            })

    return {
        "nodes": list(nodes.values()),
        "edges": _deduplicate_edges(edges),
    }


def _aggregate_parallel_sources(nodes, edges, min_group_size=3):
    """
    Group many SQL source tables feeding the same downstream stage into one source node.
    """

    node_map = {node["id"]: dict(node) for node in nodes}
    incoming = defaultdict(list)
    outgoing = defaultdict(list)

    for edge in edges:
        incoming[edge["target"]].append(edge)
        outgoing[edge["source"]].append(edge)

    groups = defaultdict(list)

    for node_id, node in node_map.items():
        if node.get("type") != "SOURCE":
            continue

        if incoming.get(node_id):
            continue

        source_edges = outgoing.get(node_id, [])
        if not source_edges:
            continue

        kinds = {edge.get("kind") for edge in source_edges}
        targets = {edge.get("target") for edge in source_edges}

        if kinds != {"sql_source"} or len(targets) != 1:
            continue

        groups[next(iter(targets))].append(node_id)

    nodes_to_remove = set()
    replacement_edges = []

    for target_id, member_ids in groups.items():
        if len(member_ids) < min_group_size:
            continue

        sorted_members = sorted(member_ids, key=str.lower)
        group_id = f"__source_group__{re.sub(r'[^A-Za-z0-9_]+', '_', target_id).strip('_').lower() or 'target'}"
        group_label = "Upstream Sources"
        detail_lines = [f"{len(sorted_members)} source tables"] + sorted_members

        node_map[group_id] = _make_node(
            group_id,
            "SOURCE_GROUP",
            label=group_label,
            details=detail_lines,
            members=sorted_members,
        )
        replacement_edges.append({
            "source": group_id,
            "target": target_id,
            "kind": "sql_source",
        })
        nodes_to_remove.update(sorted_members)

    if not nodes_to_remove:
        return nodes, edges

    final_nodes = [
        node for node_id, node in node_map.items()
        if node_id not in nodes_to_remove
    ]
    final_edges = [
        edge for edge in edges
        if edge["source"] not in nodes_to_remove and edge["target"] not in nodes_to_remove
    ]
    final_edges.extend(replacement_edges)

    return final_nodes, _deduplicate_edges(final_edges)


def _build_semantic_graph(stages, stage_edges, tables, options):
    """
    Build a clean stage-level graph for logical lineage diagrams.
    """

    nodes = {}
    edges = []
    stage_map = {stage["stage"]: stage for stage in stages}
    for edge in stage_edges:
        source_name = edge.get("source")
        target_name = edge.get("target")

        if not source_name or not target_name:
            continue

        source_stage = stage_map.get(source_name)
        target_stage = stage_map.get(target_name)
        source_role = _normalize_stage_role(source_stage)
        target_role = _normalize_stage_role(target_stage)
        nodes.setdefault(
            source_name,
            _make_node(
                source_name,
                source_role,
                label=(source_stage or {}).get("display_name") or source_name,
                details=_node_detail_lines(source_stage, source_role),
            ),
        )
        nodes.setdefault(
            target_name,
            _make_node(
                target_name,
                target_role,
                label=(target_stage or {}).get("display_name") or target_name,
                details=_node_detail_lines(target_stage, target_role),
            ),
        )
        edges.append({
            "source": source_name,
            "target": target_name,
            "kind": edge.get("kind", "flow"),
            "label": str(edge.get("label") or "").strip(),
        })

    for stage_name, stage in stage_map.items():
        node_role = _normalize_stage_role(stage)
        nodes[stage_name] = _make_node(
            stage_name,
            node_role,
            label=stage.get("display_name") or stage_name,
            details=_node_detail_lines(stage, node_role),
        )

    complexity = _lineage_complexity(len(stage_map), len(stage_edges))
    add_sql_sources = options.get("include_sql_sources")
    table_targets = defaultdict(set)

    if add_sql_sources:
        for table in tables:
            table_name = table.get("table")
            stage_name = table.get("stage")

            if not table_name or not stage_name or stage_name not in stage_map:
                continue

            table_targets[table_name].add(stage_name)

        for table_name, stage_names in table_targets.items():
            nodes[table_name] = _make_node(table_name, "SOURCE", details=_node_detail_lines({}, "SOURCE"))
            for stage_name in sorted(stage_names):
                edges.append({
                    "source": table_name,
                    "target": stage_name,
                    "kind": "sql_source",
                })

    if not options.get("include_lookup_nodes"):
        node_values, edge_values = _collapse_semantic_nodes(
            edges,
            list(nodes.values()),
            {"LOOKUP"},
        )
        nodes = {node["id"]: node for node in node_values}
        edges = edge_values

    if options.get("diagram_mode") == "logical":
        node_values, edge_values = _aggregate_parallel_sources(list(nodes.values()), edges)
        nodes = {node["id"]: node for node in node_values}
        edges = edge_values

    return {
        "nodes": list(nodes.values()),
        "edges": _deduplicate_edges(edges),
        "complexity": complexity,
        "sql_sources": sorted(table_targets.keys()),
    }


def _build_nx_graph(node_ids, edges, allowed_kinds=None):
    """
    Build a directed lineage graph using NetworkX.
    """

    graph = nx.DiGraph()
    graph.add_nodes_from(node_ids)
    filtered = []

    for edge in edges:
        if allowed_kinds is not None and edge.get("kind") not in allowed_kinds:
            continue
        source = edge.get("source")
        target = edge.get("target")
        if not source or not target:
            continue
        graph.add_edge(source, target)
        filtered.append(edge)

    return graph, filtered


def _longest_path(node_ids, edges):
    """
    Compute a stable longest-path spine using NetworkX.
    """

    if not node_ids:
        return []

    graph, _ = _build_nx_graph(node_ids, edges)

    if graph.number_of_edges() == 0:
        return sorted(node_ids)[:1]

    if nx.is_directed_acyclic_graph(graph):
        return list(nx.algorithms.dag.dag_longest_path(graph))

    condensed = nx.condensation(graph)
    component_path = list(nx.algorithms.dag.dag_longest_path(condensed))
    component_members = defaultdict(list)

    for node_id, component_id in condensed.graph.get("mapping", {}).items():
        component_members[component_id].append(node_id)

    path = [
        sorted(component_members.get(component_id, []), key=str.lower)[0]
        for component_id in component_path
        if component_members.get(component_id)
    ]

    return path or sorted(node_ids)[:1]


def _dag_layers(node_ids, edges):
    """
    Assign left-to-right ranks using NetworkX longest-path layering.
    """

    graph, _ = _build_nx_graph(node_ids, edges)
    rank = {node_id: 0 for node_id in node_ids}

    if nx.is_directed_acyclic_graph(graph):
        for node_id in nx.topological_sort(graph):
            parent_ranks = [rank[parent] for parent in graph.predecessors(node_id)]
            rank[node_id] = (max(parent_ranks) + 1) if parent_ranks else 0
    else:
        condensed = nx.condensation(graph)
        component_rank = {}
        for component_id in nx.topological_sort(condensed):
            parents = list(condensed.predecessors(component_id))
            component_rank[component_id] = (max(component_rank[parent] for parent in parents) + 1) if parents else 0
        mapping = condensed.graph.get("mapping", {})
        for node_id in node_ids:
            rank[node_id] = component_rank.get(mapping.get(node_id), 0)

    children = {node_id: sorted(graph.successors(node_id)) for node_id in graph.nodes}
    parents = {node_id: sorted(graph.predecessors(node_id)) for node_id in graph.nodes}

    return rank, children, parents


def _graphviz_plain_layout(nodes, edges, sizes):
    """
    Ask Graphviz for node positions and return draw.io-friendly coordinates.
    
    Uses safe identifiers (node_0, node_1, etc.) to avoid parsing issues with
    special characters in node IDs, then maps results back to original IDs.
    """

    if graphviz is None:
        raise RuntimeError("Graphviz Python package is not installed.")

    dot = graphviz.Digraph(engine="dot")
    dot.attr(
        rankdir="LR",
        nodesep="0.95",
        ranksep="1.45",
        splines="ortho",
        newrank="true",
        ordering="out",
        concentrate="false",
    )

    # Create mapping from safe IDs to original IDs
    safe_id_map = {}
    id_to_safe = {}
    
    for index, node in enumerate(nodes):
        original_id = node["id"]
        safe_id = f"node_{index}"
        safe_id_map[safe_id] = original_id
        id_to_safe[original_id] = safe_id
        
        node_size = sizes.get(original_id, {"width": 220, "height": 70})
        dot.node(
            safe_id,
            label=_display_label(node),
            width=f"{node_size['width'] / 72:.3f}",
            height=f"{node_size['height'] / 72:.3f}",
            shape="box",
            fixedsize="false",
        )

    for edge in edges:
        source_safe_id = id_to_safe.get(edge["source"], edge["source"])
        target_safe_id = id_to_safe.get(edge["target"], edge["target"])
        dot.edge(source_safe_id, target_safe_id)

    try:
        plain = dot.pipe(format="plain").decode("utf-8")
    except Exception as exc:
        raise RuntimeError(
            "Graphviz layout failed. Ensure the `dot` executable is installed and available on PATH."
        ) from exc

    positions = {}
    graph_height = 0.0

    for line in plain.splitlines():
        if not line.strip():
            continue
            
        parts = line.split()
        if not parts:
            continue

        if parts[0] == "graph" and len(parts) >= 4:
            try:
                graph_height = float(parts[3])
            except (ValueError, IndexError):
                continue
                
        elif parts[0] == "node" and len(parts) >= 6:
            try:
                safe_id = parts[1]
                original_id = safe_id_map.get(safe_id, safe_id)
                
                x_center = float(parts[2]) * 72
                y_center = float(parts[3]) * 72
                width = float(parts[4]) * 72
                height = float(parts[5]) * 72
                
                positions[original_id] = {
                    "x": int(round(x_center - (width / 2))),
                    "y": int(round((graph_height * 72) - y_center - (height / 2))),
                }
            except (ValueError, IndexError) as e:
                raise ValueError(
                    f"Failed to parse Graphviz output line: '{line}'. "
                    f"Parts: {parts}. Error: {e}"
                ) from e

    if not positions:
        raise RuntimeError("Graphviz returned no node positions.")

    return positions


def _spread_missing_or_colliding_positions(nodes, edges, sizes, positions):
    """
    Apply a minimal repair when Graphviz leaves nodes unplaced or stacked.
    """

    row_gap = 170
    grouped = defaultdict(list)

    for node in nodes:
        node_id = node["id"]
        if node_id in positions:
            key = (positions[node_id]["x"], positions[node_id]["y"])
            grouped[key].append(node_id)

    for (_, y_value), node_ids in grouped.items():
        if len(node_ids) <= 1:
            continue
        for offset, node_id in enumerate(sorted(node_ids)):
            positions[node_id]["y"] = y_value + (offset * row_gap)

    if len(positions) == len(nodes):
        return positions

    node_ids = [node["id"] for node in nodes]
    rank_map, _, _ = _dag_layers(node_ids, edges)
    x_gap = 420
    base_x = 40
    base_y = 40
    next_y_by_rank = defaultdict(lambda: base_y)

    for node_id in sorted(node_ids, key=lambda item: (rank_map.get(item, 0), item.lower())):
        if node_id in positions:
            rank = rank_map.get(node_id, 0)
            next_y_by_rank[rank] = max(next_y_by_rank[rank], positions[node_id]["y"] + row_gap)
            continue
        rank = rank_map.get(node_id, 0)
        positions[node_id] = {
            "x": base_x + (rank * x_gap),
            "y": next_y_by_rank[rank],
        }
        next_y_by_rank[rank] += row_gap

    return positions


def _generate_layout_single(graph_entry):
    """
    Generate layout for one lineage graph using Graphviz.
    """

    nodes = graph_entry.get("nodes", [])
    edges = graph_entry.get("edges", [])
    options = normalize_lineage_options(graph_entry.get("options", {}))
    annotations = graph_entry.get("annotations", {})
    complexity = graph_entry.get("complexity") or _lineage_complexity(len(nodes), len(edges))
    positions = {}
    sizes = {}
    node_ids = [node["id"] for node in nodes]

    for node_id in node_ids:
        node = next((item for item in nodes if item["id"] == node_id), {"id": node_id})
        width, height = _node_box_size(_display_label(node))
        sizes[node_id] = {"width": width, "height": height}

    positions = _graphviz_plain_layout(nodes, edges, sizes)
    positions = _spread_missing_or_colliding_positions(nodes, edges, sizes, positions)

    return {
        "source_file": _safe_source_key(graph_entry.get("source_file")),
        "nodes": nodes,
        "positions": positions,
        "sizes": sizes,
        "edges": edges,
        "options": options,
        "annotations": annotations,
        "complexity": complexity,
        "semantic_hints_applied": graph_entry.get("semantic_hints_applied", False),
    }


def _node_box_size(label):
    """
    Compute a width that keeps long labels inside the node box.
    """

    lines = [line for line in str(label or "").splitlines() if line] or [""]
    max_length = max(len(line) for line in lines)
    line_count = len(lines)
    width = max(220, min(420, 160 + (max_length * 5)))
    height = max(70, min(240, 40 + (line_count * 22)))
    return width, height


def _edge_style(kind, route="", complexity="medium"):
    """
    Return draw.io edge style tuned for logical lineage.
    """

    base = "edgeStyle=none;rounded=1;html=1;"

    if kind == "lookup":
        return base + "dashed=1;dashPattern=6 4;"

    if kind == "sql_source":
        return base + "dashed=1;dashPattern=2 4;"

    return base


def _ordered_nodes_for_render(nodes, positions, annotations):
    """
    Order nodes deterministically for cleaner XML output.
    """

    lane_priority = {
        "source": 0,
        "lookup": 1,
        "support": 2,
        "main": 3,
        "branch": 4,
    }

    return sorted(
        nodes,
        key=lambda node: (
            lane_priority.get(annotations.get(node["id"], {}).get("lane", "main"), 9),
            positions.get(node["id"], {}).get("x", 0),
            positions.get(node["id"], {}).get("y", 0),
            node["id"].lower(),
        )
    )


def _edge_waypoints(edge, positions, sizes, annotations, complexity="medium"):
    """
    Create explicit waypoints only for large diagrams that benefit from a bend.
    """

    if complexity != "large":
        return []

    source_pos = positions.get(edge["source"])
    target_pos = positions.get(edge["target"])
    source_size = sizes.get(edge["source"], {"width": 220, "height": 70})
    target_size = sizes.get(edge["target"], {"width": 220, "height": 70})

    if not source_pos or not target_pos:
        return []

    source_center_x = source_pos["x"] + (source_size["width"] / 2)
    source_center_y = source_pos["y"] + (source_size["height"] / 2)
    target_center_x = target_pos["x"] + (target_size["width"] / 2)
    target_center_y = target_pos["y"] + (target_size["height"] / 2)

    if edge.get("kind") in {"lookup", "sql_source", "exception"}:
        bend_y = max(source_center_y, target_center_y) + 40
        return [
            {"x": source_center_x, "y": bend_y},
            {"x": target_center_x, "y": bend_y},
        ]

    return []


def _derive_logical_lineage(nodes, edges, options):
    """
    Derive a logical graph with lightweight annotations and Graphviz-driven layout.
    """

    node_ids = [node["id"] for node in nodes]
    node_types = {node["id"]: node["type"] for node in nodes}
    complexity = _lineage_complexity(len(nodes), len(edges))
    non_lookup_edges = [edge for edge in edges if edge.get("kind") not in {"lookup", "sql_source"}]
    main_path = _longest_path(node_ids, non_lookup_edges)
    if len(main_path) < 2:
        main_path = _longest_path(node_ids, edges)
    if not main_path:
        main_path = sorted(node_ids)

    main_set = set(main_path)
    graph, all_edges = _build_nx_graph(node_ids, edges)

    annotations = {}

    for node in nodes:
        node_id = node["id"]
        node_type = node_types.get(node_id, "DATASET")
        is_main = node_id in main_set
        has_incoming = graph.in_degree(node_id) > 0
        has_outgoing = graph.out_degree(node_id) > 0
        lane = "support"
        role = "main" if is_main else "support"

        if node_type in {"SOURCE", "SOURCE_GROUP", "EXTRACT"}:
            lane = "source"
        elif node_type in {"LOOKUP", "STORE"}:
            lane = "lookup"
        elif node_type in {"FILE_TARGET", "DB_TARGET", "TARGET", "EXCEPTION"} and has_incoming and not is_main:
            lane = "branch"
            role = "branch"
        elif is_main:
            lane = "main"
        elif has_incoming and not has_outgoing:
            lane = "branch"
            role = "branch"

        annotations[node_id] = {
            "role": role,
            "lane": lane,
        }

    logical_edges = []

    for edge in all_edges:
        logical_edges.append({
            "source": edge["source"],
            "target": edge["target"],
            "kind": edge.get("kind", "input"),
        })

    return {
        "nodes": nodes,
        "edges": _deduplicate_edges(logical_edges),
        "main_path": main_path,
        "annotations": annotations,
        "options": options,
        "complexity": complexity,
    }


def _derive_technical_lineage(nodes, edges, options):
    """
    Preserve the technical dataset-level graph and add only lightweight render annotations.
    """

    node_ids = [node["id"] for node in nodes]
    node_types = {node["id"]: node["type"] for node in nodes}
    complexity = _lineage_complexity(len(nodes), len(edges))
    non_lookup_edges = [edge for edge in edges if edge.get("kind") not in {"lookup", "sql_source"}]
    main_path = _longest_path(node_ids, non_lookup_edges)
    if not main_path:
        main_path = _longest_path(node_ids, edges)
    if not main_path:
        main_path = sorted(node_ids)

    main_set = set(main_path)
    annotations = {}

    for node in nodes:
        node_id = node["id"]
        node_type = node_types.get(node_id, "DATASET")

        if node_type == "SOURCE":
            lane = "source"
            role = "support"
        elif node_type in {"LOOKUP", "STORE"}:
            lane = "lookup"
            role = "support"
        elif node_type in {"FILE_TARGET", "DB_TARGET", "TARGET", "EXCEPTION"}:
            lane = "branch"
            role = "branch"
        elif node_id in main_set:
            lane = "main"
            role = "main"
        else:
            lane = "support"
            role = "support"

        annotations[node_id] = {
            "role": role,
            "lane": lane,
        }

    return {
        "nodes": nodes,
        "edges": _deduplicate_edges(edges),
        "main_path": main_path,
        "annotations": annotations,
        "options": options,
        "complexity": complexity,
    }


def _style_for_node_type(node_type):
    """
    Return draw.io style per node category.
    """

    base = "whiteSpace=wrap;html=1;strokeColor=#666666;"

    styles = {
        "SOURCE": base + "shape=cylinder3;boundedLbl=1;size=15;fillColor=#fff2cc;",
        "SOURCE_GROUP": base + "shape=cylinder3;boundedLbl=1;size=18;fillColor=#fff2cc;",
        "EXTRACT": base + "rounded=1;fillColor=#f8cecc;",
        "TRANSFORM": base + "rounded=1;fillColor=#f8cecc;",
        "DECISION": base + "shape=rhombus;perimeter=rhombusPerimeter;fillColor=#f8cecc;",
        "DATASET": base + "shape=document;boundedLbl=1;fillColor=#dae8fc;",
        "LOOKUP": base + "shape=document;boundedLbl=1;fillColor=#dae8fc;",
        "STORE": base + "shape=document;boundedLbl=1;fillColor=#dae8fc;",
        "DB_TARGET": base + "shape=cylinder3;boundedLbl=1;size=15;fillColor=#d5e8d4;",
        "FILE_TARGET": base + "shape=document;boundedLbl=1;fillColor=#d5e8d4;",
        "TARGET": base + "shape=document;boundedLbl=1;fillColor=#d5e8d4;",
        "EXCEPTION": base + "shape=document;boundedLbl=1;fillColor=#ffe6cc;",
    }

    return styles.get(node_type, base + "rounded=1;fillColor=#f5f5f5;")


# -----------------------------------------------------
# State Tracking
# -----------------------------------------------------

def save_lineage_state(session_id, user_id, state):
    """
    Save lineage pipeline state for debugging and recovery.

    State is merged with existing state instead of overwriting.
    """

    state_dir = os.path.join(
        OUTPUT_BASE_PATH,
        "lineage_state",
        user_id
    )

    os.makedirs(state_dir, exist_ok=True)

    state_path = os.path.join(state_dir, f"{session_id}.json")

    existing = {}

    if os.path.exists(state_path):
        existing = read_json(state_path)

    existing.update(state)

    write_json(state_path, existing)


def load_lineage_state(user_id, session_id):
    """
    Load lineage state for a given session.
    """

    state_dir = os.path.join(
        OUTPUT_BASE_PATH,
        "lineage_state",
        user_id
    )

    state_path = os.path.join(state_dir, f"{session_id}.json")

    if os.path.exists(state_path):
        return read_json(state_path)

    return {}


def get_previous_state(user_id, key):
    """
    Retrieve latest value for a specific key from lineage state files.
    Used by router when pipeline tools skip inputs.
    """

    state_dir = os.path.join(
        OUTPUT_BASE_PATH,
        "lineage_state",
        user_id
    )

    if not os.path.exists(state_dir):
        return None

    files = sorted(os.listdir(state_dir), reverse=True)

    for f in files:

        state = read_json(os.path.join(state_dir, f))

        if key in state:
            return state[key]

    return None


# -----------------------------------------------------
# File Utilities
# -----------------------------------------------------

def get_or_create_file(agent_name: str, tool_name: str):
    """
    Create a log file for the tool if it doesn't exist.

    Returns the path to the log file.
    """

    log_dir = os.path.join(
        OUTPUT_BASE_PATH,
        "logs",
        agent_name
    )

    os.makedirs(log_dir, exist_ok=True)

    log_file = os.path.join(log_dir, f"{tool_name}.log")

    if not os.path.exists(log_file):
        with open(log_file, "w") as f:
            f.write("")

    return log_file


def list_files_in_directory(directory_path: str):
    """
    Safely list files in a directory.

    Returns only file names (not directories).
    """

    if not directory_path:
        return []

    if not os.path.exists(directory_path):
        return []

    files = []

    for f in os.listdir(directory_path):

        full_path = os.path.join(directory_path, f)

        if os.path.isfile(full_path):
            files.append(f)

    return files


def get_lineage_upload_dir(user_id: str, category: str) -> str:
    """
    Build a lineage upload directory for a user and category.
    """

    return os.path.join(UPLOAD_BASE_PATH, "lineage", user_id, category)


def get_lineage_output_dir(user_id: str, category: str) -> str:
    """
    Build a lineage output directory for a user and category.
    """

    return os.path.join(OUTPUT_BASE_PATH, "lineage", user_id, category)


def resolve_lineage_artifact(user_id: str, category: str, filename: str, base_type: str = "upload"):
    """
    Resolve a lineage artifact filename to an absolute path.
    """

    if not filename:
        return None

    if os.path.isabs(filename):
        return filename

    base_dir = (
        get_lineage_upload_dir(user_id, category)
        if base_type == "upload"
        else get_lineage_output_dir(user_id, category)
    )

    return os.path.join(base_dir, filename)


# -----------------------------------------------------
# Read ETL Sources
# -----------------------------------------------------

def read_etl_sources(job_files, output_path):
    """
    Read ETL pseudocode files and store contents into JSON.
    """

    contents = []

    for file in job_files:

        if not os.path.exists(file):
            continue

        with open(file, "r", encoding="utf-8") as f:

            contents.append({
                "file": os.path.basename(file),
                "content": f.read()
            })

    write_json(output_path, contents)

    return output_path


# -----------------------------------------------------
# LLM Lineage Extraction
# -----------------------------------------------------

def _llm_required_client():
    """
    Return the configured Azure chat client or raise a clear error.
    """

    llm = _get_semantic_llm()
    if llm is None:
        raise RuntimeError(
            "Azure OpenAI chat client is not configured. "
            "Set AZURE_OPENAI_CHAT_DEPLOYMENT_NAME, AZURE_OPENAI_API_VERSION, "
            "AZURE_OPENAI_ENDPOINT, and AZURE_OPENAI_API_KEY."
        )
    return llm


def _llm_content_text(response):
    """
    Normalize LangChain response payloads into a string.
    """

    content = response.content if hasattr(response, "content") else str(response)
    if isinstance(content, list):
        parts = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict):
                text = item.get("text") or item.get("content") or ""
                if text:
                    parts.append(str(text))
        return "\n".join(part for part in parts if part).strip()
    return str(content or "").strip()


def _llm_json_response(prompt):
    """
    Invoke the lineage LLM and parse the first JSON object.
    """

    response = _llm_required_client().invoke(prompt)
    parsed = _extract_json_object(_llm_content_text(response))
    if not isinstance(parsed, dict):
        raise ValueError("LLM did not return a valid JSON object.")
    return parsed


def _chunk_text_with_overlap(text, chunk_size=7000, chunk_overlap=800):
    """
    Split long pseudocode into stable overlapping chunks.
    """

    sample = str(text or "")
    if len(sample) <= chunk_size:
        return [{
            "chunk_id": "chunk_001",
            "chunk_index": 1,
            "char_start": 0,
            "char_end": len(sample),
            "content": sample,
        }]

    chunks = []
    step = max(1, chunk_size - chunk_overlap)
    chunk_index = 1

    for start in range(0, len(sample), step):
        end = min(len(sample), start + chunk_size)
        chunk_text = sample[start:end]
        if not chunk_text.strip():
            continue
        chunks.append({
            "chunk_id": f"chunk_{chunk_index:03d}",
            "chunk_index": chunk_index,
            "char_start": start,
            "char_end": end,
            "content": chunk_text,
        })
        chunk_index += 1
        if end >= len(sample):
            break

    return chunks


def _normalize_llm_stage(stage, source_file, chunk_index, chunk_id=""):
    """
    Normalize one LLM-extracted stage into the canonical stage shape.
    """

    if not isinstance(stage, dict):
        return None

    stage_name = str(stage.get("stage") or "").strip()
    if not stage_name:
        return None

    sql_blocks = stage.get("sql", [])
    if isinstance(sql_blocks, str):
        sql_blocks = [sql_blocks] if sql_blocks.strip() else []
    elif not isinstance(sql_blocks, list):
        sql_blocks = []

    constraints = []
    for item in stage.get("constraints", []):
        if isinstance(item, dict):
            expression = str(item.get("expression") or "").strip()
        else:
            expression = str(item or "").strip()
        if expression:
            constraints.append({
                "link_name": "",
                "expression": expression[:300],
            })

    return {
        "source_file": source_file,
        "parser_type": "llm",
        "job_index": stage.get("job_index", 1),
        "chunk_id": str(stage.get("chunk_id") or chunk_id or "").strip(),
        "chunk_index": chunk_index,
        "stage": stage_name,
        "display_name": str(stage.get("display_name") or stage_name).strip() or stage_name,
        "pipeline_id": str(stage.get("pipeline_id") or "").strip(),
        "type": "TRANSFORM",
        "stage_kind": str(stage.get("stage_kind") or stage.get("kind") or "LLM_STAGE").strip() or "LLM_STAGE",
        "stage_type": str(stage.get("stage_type") or stage.get("type") or "TRANSFORM").strip() or "TRANSFORM",
        "line_start": int(stage.get("line_start") or 0),
        "line_end": int(stage.get("line_end") or 0),
        "inputs": [],
        "outputs": [],
        "sql": [str(item).strip() for item in sql_blocks if str(item).strip()],
        "constraints": constraints,
        "confidence": float(stage.get("confidence") or 0.0),
        "evidence": str(stage.get("evidence") or "")[:1000],
    }


def _normalize_llm_edge(edge):
    """
    Normalize one LLM-extracted edge into canonical graph edge shape.
    """

    if not isinstance(edge, dict):
        return None

    source = str(edge.get("source") or "").strip()
    target = str(edge.get("target") or "").strip()
    if not source or not target or source == target:
        return None

    raw_kind = str(edge.get("kind") or "input").strip()
    label = str(edge.get("label") or "").strip()
    kind_lower = raw_kind.lower()
    evidence = str(edge.get("evidence") or "")[:1000]

    if not label:
        if "master" in kind_lower or "(master)" in evidence.lower():
            label = "Master"
        elif "detail" in kind_lower or "(detail)" in evidence.lower():
            label = "Detail"

    if "lookup" in kind_lower:
        kind = "lookup"
    elif "exception" in kind_lower or "reject" in kind_lower:
        kind = "exception"
    elif "sql" in kind_lower:
        kind = "sql_source"
    elif kind_lower in {"input", "flow", "master", "detail"}:
        kind = "input"
    else:
        kind = "input"

    return {
        "source": source,
        "target": target,
        "chunk_id": str(edge.get("chunk_id") or "").strip(),
        "pipeline_id": str(edge.get("pipeline_id") or "").strip(),
        "kind": kind,
        "label": label[:80],
        "evidence": evidence,
        "confidence": float(edge.get("confidence") or 0.0),
        "is_inferred": bool(edge.get("is_inferred", False)),
    }


def _merge_llm_chunk_graph(source_file, chunks_payload):
    """
    Merge chunk-level LLM extraction into one per-source graph.
    """

    stage_map = {}
    edge_candidates = []
    unresolved_edges = []
    memory_notes = []

    for chunk_payload in chunks_payload:
        if not isinstance(chunk_payload, dict):
            continue

        chunk_index = int(chunk_payload.get("chunk_index") or 0)
        for raw_stage in chunk_payload.get("stages", []):
            stage = _normalize_llm_stage(
                raw_stage,
                source_file,
                chunk_index,
                chunk_payload.get("chunk_id", ""),
            )
            if not stage:
                continue
            existing = stage_map.get(stage["stage"])
            if not existing:
                stage_map[stage["stage"]] = stage
                continue

            existing["line_start"] = min(
                value for value in [existing.get("line_start", 0), stage.get("line_start", 0)] if value >= 0
            )
            existing["line_end"] = max(existing.get("line_end", 0), stage.get("line_end", 0))
            existing["sql"] = sorted(set(existing.get("sql", []) + stage.get("sql", [])))
            existing["constraints"] = existing.get("constraints", []) + [
                item for item in stage.get("constraints", [])
                if item not in existing.get("constraints", [])
            ]
            if stage.get("confidence", 0.0) > existing.get("confidence", 0.0):
                existing["stage_kind"] = stage.get("stage_kind", existing.get("stage_kind"))
                existing["stage_type"] = stage.get("stage_type", existing.get("stage_type"))
                existing["confidence"] = stage.get("confidence", existing.get("confidence", 0.0))
                existing["evidence"] = stage.get("evidence", existing.get("evidence", ""))

        for raw_edge in chunk_payload.get("edges", []):
            edge = _normalize_llm_edge(raw_edge)
            if not edge:
                continue
            if edge["source"] and edge["target"]:
                edge_candidates.append(edge)

        for raw_edge in chunk_payload.get("unresolved_edges", []):
            edge = _normalize_llm_edge(raw_edge)
            if edge:
                unresolved_edges.append(edge)

        summary = str(chunk_payload.get("memory_summary") or "").strip()
        if summary:
            memory_notes.append(summary[:600])

    valid_stage_names = set(stage_map)
    edges = []
    for edge in edge_candidates:
        if edge["source"] in valid_stage_names and edge["target"] in valid_stage_names:
            edges.append(edge)
        else:
            unresolved_edges.append(edge)

    edge_index = 1
    inbound = defaultdict(list)
    outbound = defaultdict(list)
    for edge in _deduplicate_edges(edges):
        dataset_id = f"dataset_llm_{edge_index}"
        edge_index += 1
        outbound[edge["source"]].append({
            "dataset_id": dataset_id,
            "alias": edge["target"],
            "link_name": "",
        })
        inbound[edge["target"]].append({
            "dataset_id": dataset_id,
            "alias": edge["source"],
            "link_name": "",
        })

    for stage_name, stage in stage_map.items():
        stage["inputs"] = inbound.get(stage_name, [])
        stage["outputs"] = outbound.get(stage_name, [])

    return {
        "source_file": source_file,
        "stages": sorted(stage_map.values(), key=lambda item: (item.get("line_start", 0), item.get("stage", "").lower())),
        "edges": _deduplicate_edges(edges),
        "unresolved_edges": _deduplicate_edges(unresolved_edges),
        "memory_summary": " | ".join(memory_notes[:8]),
    }


def _llm_extract_chunk_payload(source_file, chunk, memory_state):
    """
    Ask the LLM to extract stages and edges from one pseudocode chunk.
    """

    payload = {
        "source_file": source_file,
        "chunk_id": chunk["chunk_id"],
        "chunk_index": chunk["chunk_index"],
        "char_start": chunk["char_start"],
        "char_end": chunk["char_end"],
        "memory": memory_state,
        "chunk_text": chunk["content"],
    }

    prompt = f"""
You are extracting ETL lineage from pseudocode in a chunked workflow.
Return JSON only.

Rules:
- Only extract stages and edges that are supported by this chunk or the provided memory.
- Preserve original stage names exactly.
- Use stable categories for stage_type such as SOURCE, EXTRACT, LOOKUP, STORE, TRANSFORM, TARGET, FILE_TARGET, DB_TARGET.
- Include SQL blocks only when present in the chunk.
- Put uncertain cross-chunk links into unresolved_edges instead of forcing them into edges.
- Keep evidence short and factual.
- This is a logical lineage extraction, not an execution diagram.
- Include only mapping-level data-flow components such as sources, source qualifiers, sorters, joiners, expressions, lookups, stores, and targets.
- Exclude workflow/session/execution artifacts such as SESSION_CONFIGURATION, WORKFLOW_DEFINITION, SESSION_DEFINITION, workflow tasks, task instances, start tasks, reader or writer extensions, XML readers, file writers, and session names.
- Do not turn XML output groups, schema groups, parent/child group definitions, or column groups into standalone lineage nodes.
- If the chunk describes parallel branches or hierarchical XML groups, preserve that meaning through edge evidence or labels such as Master, Detail, Parent stream, or Child stream instead of inventing new transformation nodes.

Return this shape:
{{
  "stages": [
    {{
      "stage": "stage_name",
      "display_name": "original visible stage name",
      "pipeline_id": "optional stable pipeline identifier when the file contains multiple separate flows",
      "chunk_id": "{chunk["chunk_id"]}",
      "stage_kind": "raw kind",
      "stage_type": "TRANSFORM",
      "line_start": 0,
      "line_end": 0,
      "sql": ["select ..."],
      "constraints": ["x = y"],
      "confidence": 0.0,
      "evidence": "short quote or explanation"
    }}
  ],
  "edges": [
    {{
      "source": "stage_a",
      "target": "stage_b",
      "pipeline_id": "optional stable pipeline identifier when known",
      "chunk_id": "{chunk["chunk_id"]}",
      "kind": "input | master | detail | lookup | exception | sql_source",
      "label": "optional short edge label such as Master or Detail",
      "confidence": 0.0,
      "evidence": "short quote or explanation",
      "is_inferred": false
    }}
  ],
  "unresolved_edges": [
    {{
      "source": "stage_a",
      "target": "stage_b",
      "pipeline_id": "optional stable pipeline identifier when known",
      "chunk_id": "{chunk["chunk_id"]}",
      "kind": "input | master | detail | lookup | exception | sql_source",
      "label": "optional short edge label such as Master or Detail",
      "confidence": 0.0,
      "evidence": "why this link needs another chunk",
      "is_inferred": true
    }}
  ],
  "memory_summary": "short summary of entities and open links discovered in this chunk"
}}

Input:
{json.dumps(payload, indent=2)}
"""

    result = _llm_json_response(prompt)
    result["chunk_id"] = chunk["chunk_id"]
    result["chunk_index"] = chunk["chunk_index"]
    return result


def llm_extract_lineage_graph(source_file, output_path, chunk_size=7000, chunk_overlap=800):
    """
    Extract a lineage graph from ETL pseudocode one chunk at a time via LLM.
    """

    source_file = require_existing_file(source_file, "lineage source file")
    sources = read_json(source_file)
    graph_entries = []

    for entry in sources:
        source_name = _safe_source_key(entry.get("file"))
        text = str(entry.get("content") or "")
        chunks = _chunk_text_with_overlap(text, chunk_size=chunk_size, chunk_overlap=chunk_overlap)
        memory_state = {
            "accepted_stages": [],
            "open_links": [],
            "notes": "",
        }
        chunk_payloads = []

        for chunk in chunks:
            payload = _llm_extract_chunk_payload(source_name, chunk, memory_state)
            chunk_payloads.append(payload)
            memory_state = {
                "accepted_stages": sorted([{
                    "stage": str(item.get("stage") or "").strip(),
                    "chunk_id": str(item.get("chunk_id") or chunk_item.get("chunk_id") or "").strip(),
                } for chunk_item in chunk_payloads
                    for item in chunk_item.get("stages", [])
                    if isinstance(item, dict) and str(item.get("stage") or "").strip()
                ], key=lambda item: (item.get("stage", "").lower(), item.get("chunk_id", ""))),
                "open_links": [
                    {
                        "source": item.get("source"),
                        "target": item.get("target"),
                        "kind": item.get("kind"),
                        "chunk_id": item.get("chunk_id") or chunk_item.get("chunk_id"),
                    }
                    for chunk_item in chunk_payloads
                    for item in chunk_item.get("unresolved_edges", [])
                    if isinstance(item, dict)
                ][:25],
                "notes": {
                    "last_chunk_id": chunk.get("chunk_id"),
                    "last_summary": str(payload.get("memory_summary") or "")[:1000],
                },
            }

        graph_entries.append(_merge_llm_chunk_graph(source_name, chunk_payloads))

    write_json(output_path, _graphs_payload(graph_entries))
    return output_path


def _llm_validate_graph_entry(graph_entry):
    """
    Ask the LLM to semantically validate an extracted logical lineage graph.
    """

    payload = {
        "source_file": graph_entry.get("source_file"),
        "stages": graph_entry.get("stages", []),
        "edges": graph_entry.get("edges", []),
        "unresolved_edges": graph_entry.get("unresolved_edges", []),
        "memory_summary": graph_entry.get("memory_summary", ""),
    }

    prompt = f"""
You are validating an ETL logical lineage graph.
Return JSON only.

Validation scope:
- detect execution/session/workflow artifacts that do not belong in logical lineage
- detect parameter placeholder nodes like $PMsrc_* or $PMtgt_* that should not be standalone nodes
- detect mixed pipelines that should be separated into distinct logical flows
- detect reused stage names that actually represent different transformations in different contexts
- detect obvious semantic mistakes in source/target/qualifier/join/transform usage
- preserve mapping-level lineage only

Return this shape:
{{
  "issues": [
    {{
      "severity": "error | warning",
      "type": "issue_type",
      "message": "short message",
      "stage": "optional stage name",
      "recommendation": "optional suggested fix"
    }}
  ],
  "validation_summary": "short summary"
}}

Input:
{json.dumps(payload, indent=2)}
"""

    return _llm_json_response(prompt)


def validate_lineage_graph(graph_file, output_path):
    """
    Deterministically validate an LLM-extracted lineage graph.
    """

    graph_file = require_existing_file(graph_file, "LLM lineage graph file")
    payload = read_json(graph_file)
    graph_entries = _payload_graphs(payload) if _is_graphs_payload(payload) else [payload]
    validated = []

    for graph_entry in graph_entries:
        stages = graph_entry.get("stages", [])
        edges = graph_entry.get("edges", [])
        source_file = _safe_source_key(graph_entry.get("source_file"))
        issues = []
        stage_names = []
        seen = set()

        for stage in stages:
            name = str(stage.get("stage") or "").strip()
            if not name:
                issues.append({"severity": "error", "type": "blank_stage", "message": "Stage without a name."})
                continue
            if name in seen:
                issues.append({"severity": "error", "type": "duplicate_stage", "message": f"Duplicate stage: {name}"})
            seen.add(name)
            stage_names.append(name)

        stage_name_set = set(stage_names)
        valid_edges = []
        for edge in edges:
            source = str(edge.get("source") or "").strip()
            target = str(edge.get("target") or "").strip()
            if source not in stage_name_set or target not in stage_name_set:
                issues.append({
                    "severity": "error",
                    "type": "unknown_edge_endpoint",
                    "message": f"Edge references unknown stage: {source} -> {target}",
                })
                continue
            valid_edges.append(edge)

        graph, _ = _build_nx_graph(stage_names, valid_edges)
        if stage_names and not nx.is_directed_acyclic_graph(graph):
            issues.append({
                "severity": "warning",
                "type": "cycle_detected",
                "message": "The extracted lineage graph contains a cycle.",
            })

        for stage in stages:
            name = stage.get("stage")
            if graph.in_degree(name) == 0 and graph.out_degree(name) == 0:
                issues.append({
                    "severity": "warning",
                    "type": "isolated_stage",
                    "message": f"Stage is isolated: {name}",
                })

        llm_validation = _llm_validate_graph_entry(graph_entry)
        for item in llm_validation.get("issues", []):
            if not isinstance(item, dict):
                continue
            issues.append({
                "severity": str(item.get("severity") or "warning"),
                "type": str(item.get("type") or "llm_validation_issue"),
                "message": str(item.get("message") or "")[:500],
                "stage": str(item.get("stage") or "")[:200],
                "recommendation": str(item.get("recommendation") or "")[:500],
            })

        validated.append({
            "source_file": source_file,
            "stages": stages,
            "edges": _deduplicate_edges(valid_edges),
            "unresolved_edges": graph_entry.get("unresolved_edges", []),
            "issues": issues,
            "valid": not any(item.get("severity") == "error" for item in issues),
            "memory_summary": graph_entry.get("memory_summary", ""),
            "validation_summary": str(llm_validation.get("validation_summary") or "")[:1000],
        })

    write_json(output_path, _graphs_payload(validated))
    return output_path


def _llm_repair_graph_entry(graph_entry):
    """
    Ask the LLM to repair only the issues reported by validation.
    """

    issues = graph_entry.get("issues", [])
    if not issues:
        return graph_entry

    payload = {
        "source_file": graph_entry.get("source_file"),
        "stages": graph_entry.get("stages", []),
        "edges": graph_entry.get("edges", []),
        "unresolved_edges": graph_entry.get("unresolved_edges", []),
        "issues": issues,
        "memory_summary": graph_entry.get("memory_summary", ""),
        "validation_summary": graph_entry.get("validation_summary", ""),
    }

    prompt = f"""
You are repairing an ETL lineage graph after validation.
Return JSON only.

Rules:
- Preserve original visible stage names through `display_name`.
- Only modify graph parts required to address the listed issues.
- Prefer removing weak edges over inventing unsupported ones.
- Keep unresolved links in unresolved_edges when certainty is low.
- Filter out execution-only or workflow/session artifacts from logical lineage.
- Filter out parameter placeholder nodes such as $PMsrc_* and $PMtgt_* from logical lineage.
- Split mixed logical pipelines by assigning a stable `pipeline_id`.
- When the same stage name is reused in different pipelines, disambiguate the node id in `stage` but preserve the original visible name in `display_name`.
- Preserve mapping-level flow only.
- If a join has role-specific inputs, preserve them with edge labels such as Master and Detail.
- Return this shape:
{{
  "stages": [
    {{
      "stage": "unique stage id",
      "display_name": "original visible label",
      "pipeline_id": "pipeline_a"
    }}
  ],
  "edges": [
    {{
      "source": "unique stage id",
      "target": "unique stage id",
      "pipeline_id": "pipeline_a"
    }}
  ],
  "unresolved_edges": [...],
  "repair_summary": "short summary"
}}

Input:
{json.dumps(payload, indent=2)}
"""

    repaired = _llm_json_response(prompt)
    repaired["source_file"] = graph_entry.get("source_file")
    repaired["memory_summary"] = graph_entry.get("memory_summary", "")
    return repaired


def _split_graph_entry_by_pipeline(graph_entry):
    """
    Split one repaired graph entry into multiple per-pipeline graph entries.
    """

    stages = graph_entry.get("stages", [])
    edges = graph_entry.get("edges", [])
    unresolved_edges = graph_entry.get("unresolved_edges", [])
    source_file = _safe_source_key(graph_entry.get("source_file"))

    stage_pipeline = {}
    for stage in stages:
        if isinstance(stage, dict):
            stage_name = str(stage.get("stage") or "").strip()
            pipeline_id = str(stage.get("pipeline_id") or "").strip()
            if stage_name and pipeline_id:
                stage_pipeline[stage_name] = pipeline_id

    if stage_pipeline:
        groups = defaultdict(lambda: {"stages": [], "edges": [], "unresolved_edges": []})
        for stage in stages:
            stage_name = str(stage.get("stage") or "").strip()
            pipeline_id = stage_pipeline.get(stage_name, "pipeline_1")
            groups[pipeline_id]["stages"].append(stage)
        for edge in edges:
            pipeline_id = str(edge.get("pipeline_id") or "").strip()
            if not pipeline_id:
                pipeline_id = stage_pipeline.get(str(edge.get("source") or "").strip()) or stage_pipeline.get(str(edge.get("target") or "").strip()) or "pipeline_1"
            groups[pipeline_id]["edges"].append(edge)
        for edge in unresolved_edges:
            pipeline_id = str(edge.get("pipeline_id") or "").strip()
            if not pipeline_id:
                pipeline_id = stage_pipeline.get(str(edge.get("source") or "").strip()) or stage_pipeline.get(str(edge.get("target") or "").strip()) or "pipeline_1"
            groups[pipeline_id]["unresolved_edges"].append(edge)

        return [{
            "source_file": source_file,
            "pipeline_id": pipeline_id,
            "stages": value["stages"],
            "edges": _deduplicate_edges(value["edges"]),
            "unresolved_edges": _deduplicate_edges(value["unresolved_edges"]),
            "repair_summary": graph_entry.get("repair_summary", ""),
            "memory_summary": graph_entry.get("memory_summary", ""),
        } for pipeline_id, value in groups.items() if value["stages"]]

    node_ids = [str(stage.get("stage") or "").strip() for stage in stages if str(stage.get("stage") or "").strip()]
    graph, _ = _build_nx_graph(node_ids, edges)
    components = list(nx.weakly_connected_components(graph)) if node_ids else []
    if len(components) <= 1:
        return [graph_entry]

    split_entries = []
    for index, component in enumerate(components, start=1):
        component_nodes = set(component)
        split_entries.append({
            "source_file": source_file,
            "pipeline_id": f"pipeline_{index}",
            "stages": [stage for stage in stages if str(stage.get("stage") or "").strip() in component_nodes],
            "edges": _deduplicate_edges([edge for edge in edges if str(edge.get("source") or "").strip() in component_nodes and str(edge.get("target") or "").strip() in component_nodes]),
            "unresolved_edges": _deduplicate_edges([edge for edge in unresolved_edges if str(edge.get("source") or "").strip() in component_nodes or str(edge.get("target") or "").strip() in component_nodes]),
            "repair_summary": graph_entry.get("repair_summary", ""),
            "memory_summary": graph_entry.get("memory_summary", ""),
        })

    return split_entries


def repair_lineage_graph_if_needed(validation_file, output_path):
    """
    Repair an LLM lineage graph only when validation surfaced issues.
    """

    validation_file = require_existing_file(validation_file, "validated lineage graph file")
    payload = read_json(validation_file)
    graph_entries = _payload_graphs(payload) if _is_graphs_payload(payload) else [payload]
    repaired_entries = []

    for graph_entry in graph_entries:
        repaired = _llm_repair_graph_entry(graph_entry)
        normalized_stages = []
        for stage in repaired.get("stages", []):
            normalized = _normalize_llm_stage(
                stage,
                _safe_source_key(repaired.get("source_file")),
                stage.get("chunk_index", 0) if isinstance(stage, dict) else 0,
                stage.get("chunk_id", "") if isinstance(stage, dict) else "",
            )
            if normalized:
                normalized_stages.append(normalized)
        repaired_entry = {
            "source_file": _safe_source_key(repaired.get("source_file")),
            "stages": normalized_stages,
            "edges": [
                edge for edge in (
                    _normalize_llm_edge(item) for item in repaired.get("edges", [])
                ) if edge
            ],
            "unresolved_edges": [
                edge for edge in (
                    _normalize_llm_edge(item) for item in repaired.get("unresolved_edges", [])
                ) if edge
            ],
            "repair_summary": str(repaired.get("repair_summary") or "")[:1000],
            "memory_summary": graph_entry.get("memory_summary", ""),
        }
        repaired_entries.extend(_split_graph_entry_by_pipeline(repaired_entry))

    write_json(output_path, _graphs_payload(repaired_entries))
    return output_path


# -----------------------------------------------------
# SQL Metadata Extraction
# -----------------------------------------------------

def extract_sql_metadata(graph_file, output_path):
    """
    Extract SQL tables from an extracted or repaired lineage graph.
    """

    graph_file = require_existing_file(graph_file, "lineage graph file")
    payload = read_json(graph_file)
    if _is_graphs_payload(payload):
        stages = []
        for graph_entry in _payload_graphs(payload):
            stages.extend(graph_entry.get("stages", []))
    else:
        stages = payload

    tables = []
    seen = set()

    for stage in stages:
        source_file = _safe_source_key(stage.get("source_file"))

        for sql in stage.get("sql", []):

            extracted = []

            if Parser is not None:

                try:
                    parser = Parser(sql)
                    extracted = parser.tables
                except Exception:
                    extracted = []

            # fallback regex
            if not extracted:
                extracted = re.findall(
                    r'(?:FROM|JOIN)\s+([A-Za-z0-9_.]+)',
                    sql,
                    re.I
                )

            for table in extracted:

                key = (source_file, table.lower(), stage["stage"])

                if key in seen:
                    continue

                seen.add(key)

                tables.append({
                    "source_file": source_file,
                    "table": table,
                    "stage": stage["stage"]
                })

    write_json(output_path, tables)

    return output_path


# -----------------------------------------------------
# Normalize Lineage Graph
# -----------------------------------------------------

def normalize_lineage_graph(dataset_file, sql_file, output_path, options=None):
    """
    Convert extracted lineage graph content and SQL tables into normalized graph.
    """

    dataset_file = require_existing_file(dataset_file, "lineage graph file")
    sql_file = require_existing_file(sql_file, "sql metadata file")
    options = normalize_lineage_options(options)

    dataset_payload = read_json(dataset_file)
    tables = read_json(sql_file)

    if _is_graphs_payload(dataset_payload):
        dataset_graphs = _payload_graphs(dataset_payload)
    elif isinstance(dataset_payload, dict):
        dataset_graphs = [{
            "source_file": "lineage",
            "edges": dataset_payload.get("edges", []),
            "stages": dataset_payload.get("stages", []),
        }]
    else:
        dataset_graphs = [{
            "source_file": "lineage",
            "edges": dataset_payload,
            "stages": [],
        }]

    tables_by_source = defaultdict(list)
    for table in tables:
        tables_by_source[_safe_source_key(table.get("source_file"))].append(table)

    normalized_graphs = []

    for graph_entry in dataset_graphs:
        source_file = _safe_source_key(graph_entry.get("source_file"))
        edges = graph_entry.get("edges", [])
        stages = graph_entry.get("stages", [])
        source_tables = tables_by_source.get(source_file, [])

        if options.get("diagram_mode") == "technical" and not options.get("collapse_intermediate_datasets"):
            graph_payload = _build_dataset_graph(stages, source_tables, options)
            complexity = _lineage_complexity(
                len(graph_payload.get("nodes", [])),
                len(graph_payload.get("edges", [])),
            )
            sql_sources = [table.get("table") for table in source_tables]
        else:
            graph_payload = _build_semantic_graph(stages, edges, source_tables, options)
            complexity = graph_payload.get("complexity", _lineage_complexity(len(stages), len(edges)))
            sql_sources = graph_payload.get("sql_sources", [])

        normalized_graphs.append({
            "source_file": source_file,
            "nodes": graph_payload.get("nodes", []),
            "edges": graph_payload.get("edges", []),
            "sql_sources": sql_sources,
            "options": options,
            "complexity": complexity,
            "semantic_hints_applied": False,
        })

    normalized = _graphs_payload(normalized_graphs)

    write_json(output_path, normalized)

    return output_path


# -----------------------------------------------------
# Build Lineage Graph
# -----------------------------------------------------

def build_lineage_graph_bottom_up(graph_file, output_path):
    """
    Build lineage graph paths from normalized graph.
    """

    graph_file = require_existing_file(graph_file, "normalized graph file")
    graph = read_json(graph_file)

    graph_entries = _payload_graphs(graph) if _is_graphs_payload(graph) else [graph]
    lineage_entries = []

    for graph_entry in graph_entries:
        options = normalize_lineage_options(graph_entry.get("options", {}))

        if options.get("diagram_mode") == "technical" and not options.get("collapse_intermediate_datasets"):
            rendered_graph = _derive_technical_lineage(
                graph_entry.get("nodes", []),
                graph_entry.get("edges", []),
                options,
            )
        else:
            rendered_graph = _derive_logical_lineage(
                graph_entry.get("nodes", []),
                graph_entry.get("edges", []),
                options,
            )

        lineage_entries.append({
            "source_file": _safe_source_key(graph_entry.get("source_file")),
            "paths": [rendered_graph.get("main_path", [])] if rendered_graph.get("main_path") else [],
            "edges": rendered_graph.get("edges", []),
            "nodes": rendered_graph.get("nodes", []),
            "annotations": rendered_graph.get("annotations", {}),
            "sql_sources": graph_entry.get("sql_sources", []),
            "options": graph_entry.get("options", {}),
            "complexity": rendered_graph.get("complexity", graph_entry.get("complexity")),
            "semantic_hints_applied": graph_entry.get("semantic_hints_applied", False),
        })

    lineage = _graphs_payload(lineage_entries)

    write_json(output_path, lineage)

    return output_path


# -----------------------------------------------------
# Layout Generation
# -----------------------------------------------------

def generate_layout(graph_file, output_path):
    """
    Generate node layout coordinates for visualization.
    """

    graph_file = require_existing_file(graph_file, "lineage graph file")
    graph = read_json(graph_file)

    graph_entries = _payload_graphs(graph) if _is_graphs_payload(graph) else [graph]
    layout = _graphs_payload([
        _generate_layout_single(graph_entry)
        for graph_entry in graph_entries
    ])

    write_json(output_path, layout)

    return output_path


# -----------------------------------------------------
# Draw.io XML Generation
# -----------------------------------------------------

def generate_drawio_xml(layout_file):
    """
    Convert the finalized lineage layout JSON into draw.io XML format.
    """

    layout_file = require_existing_file(layout_file, "layout file")
    layout = read_json(layout_file)

    layout_entries = _payload_graphs(layout) if _is_graphs_payload(layout) else [layout]
    diagrams = []

    for layout_entry in layout_entries:
        nodes = layout_entry.get("nodes")
        pos = layout_entry.get("positions")
        sizes = layout_entry.get("sizes", {})
        edges = layout_entry.get("edges")
        annotations = layout_entry.get("annotations", {})
        complexity = layout_entry.get("complexity", "medium")

        if nodes is None or pos is None or edges is None:
            raise ValueError(f"Invalid layout file format: {layout_file}")

        xml = []

        xml.append('<mxfile host="app.diagrams.net" version="29.6.1">')
        xml.append('  <diagram name="Logical ETL Lineage" id="0">')
        xml.append('    <mxGraphModel dx="1895" dy="958" grid="1" gridSize="10" guides="1" tooltips="1" connect="1" arrows="1" fold="1" page="1" pageScale="1" pageWidth="827" pageHeight="1169" math="0" shadow="0">')
        xml.append("      <root>")
        xml.append('        <mxCell id="0"/>')
        xml.append('        <mxCell id="1" parent="0"/>')
        xml.append("")
        xml.append("        <!-- Nodes -->")

        id_map = {}
        ordered_nodes = _ordered_nodes_for_render(nodes, pos, annotations)

        for index, node in enumerate(ordered_nodes, start=1):
            node_id = f"n{index}"
            id_map[node["id"]] = node_id

            geometry = pos.get(node["id"], {"x": 0, "y": 0})
            render_label = _display_label(node)
            label = escape(render_label, {'"': "&quot;"})
            style = _style_for_node_type(node.get("type")).replace(
                "whiteSpace=wrap;html=1;",
                "whiteSpace=wrap;html=1;overflow=hidden;align=center;verticalAlign=middle;spacing=6;"
            )
            node_size = sizes.get(node["id"], {})
            width = node_size.get("width") or _node_box_size(render_label)[0]
            height = node_size.get("height") or _node_box_size(render_label)[1]

            xml.append(
                f'        <mxCell id="{node_id}" value="{label}" '
                f'style="{style}" vertex="1" parent="1">'
            )
            xml.append(
                f'          <mxGeometry x="{geometry["x"]}" y="{geometry["y"]}" width="{width}" height="{height}" as="geometry"/>'
            )
            xml.append("        </mxCell>")

        xml.append("")
        xml.append("        <!-- Edges -->")

        for index, edge in enumerate(edges, start=1):
            source_id = id_map.get(edge["source"], "")
            target_id = id_map.get(edge["target"], "")
            value = escape(str(edge.get("label") or ""), {'"': "&quot;"})
            route = edge.get("route", "")
            style = _edge_style(edge.get("kind", ""), route, complexity)
            waypoints = _edge_waypoints(edge, pos, sizes, annotations, complexity)

            xml.append(
                f'        <mxCell id="e{index}" edge="1" parent="1" '
                f'source="{source_id}" target="{target_id}" value="{value}" style="{style}">'
            )
            if waypoints:
                xml.append('          <mxGeometry relative="1" as="geometry">')
                xml.append('            <Array as="points">')
                for point in waypoints:
                    xml.append(
                        f'              <mxPoint x="{point["x"]}" y="{point["y"]}"/>'
                    )
                xml.append('            </Array>')
                xml.append('          </mxGeometry>')
            else:
                xml.append('          <mxGeometry relative="1" as="geometry"/>')
            xml.append("        </mxCell>")

        xml.append("      </root>")
        xml.append("    </mxGraphModel>")
        xml.append("  </diagram>")
        xml.append("</mxfile>")

        diagrams.append({
            "source_file": _safe_source_key(layout_entry.get("source_file")),
            "drawio_xml": "\n".join(xml),
        })

    if len(diagrams) == 1:
        return diagrams[0]["drawio_xml"]

    return _json_string({"diagrams": diagrams})


# -----------------------------------------------------
# Store XML
# -----------------------------------------------------

def store_lineage_xml(xml, directory, filename):
    """
    Store generated draw.io XML lineage diagram.
    """

    if filename is None:
        filename = f"lineage_{uuid.uuid4().hex}.drawio"

    os.makedirs(directory, exist_ok=True)

    path = os.path.join(directory, filename)

    with open(path, "w", encoding="utf-8") as f:
        f.write(xml)

    return path
