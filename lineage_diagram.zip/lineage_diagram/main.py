#!/usr/bin/env python3
"""Importable lineage agent entry point for batch processing."""

from pathlib import Path
from typing import Any

from dotenv import load_dotenv

from sttm_final_v3.sttm_all_v3_new.lineage_diagram.lineage_agent.brain.methods import run_lineage_pipeline


load_dotenv()

DEFAULT_INPUT_DIR = Path("/home/admin/gaurav_code_repo/sttm_final_v3/sttm_all_v3_new/sttm_mcp/tmp/")
DEFAULT_OUTPUT_DIR = Path("/home/admin/gaurav_code_repo/sttm_final_v3/sttm_all_v3_new/sttm_mcp/lineage_diagram/data/output")


def find_input_files(input_dir: Path) -> list[Path]:
    """Find supported input files in the input directory."""
    if not input_dir.exists():
        return []

    files = list(input_dir.glob("*.txt"))
    files.extend(input_dir.glob("*.xml"))
    files.extend(input_dir.glob("*.json"))
    return sorted(files)


def process_single_file(input_file: Path, output_dir: Path, model_override: str = "") -> dict[str, Any]:
    """Process a single input file through the lineage pipeline."""
    result = run_lineage_pipeline(
        input_path=str(input_file),
        output_dir=str(output_dir),
        model_override=model_override,
    )
    result["status"] = "success"
    result["input_file"] = str(input_file)
    return result


def run_lineage_agent(
    input_dir: str | Path = DEFAULT_INPUT_DIR,
    output_dir: str | Path = DEFAULT_OUTPUT_DIR,
    model_override: str = "",
) -> list[str]:
    """Run the lineage pipeline for all supported files and return generated output folders."""
    resolved_input_dir = Path(input_dir)
    resolved_output_dir = Path(output_dir)
    resolved_output_dir.mkdir(parents=True, exist_ok=True)

    generated_output_paths: list[str] = []
    input_files = find_input_files(resolved_input_dir)

    for input_file in input_files:
        result = process_single_file(input_file, resolved_output_dir, model_override=model_override)
        run_dir = str(result.get("run_dir") or "").strip()
        if run_dir:
            generated_output_paths.append(run_dir)

    return generated_output_paths


def main() -> list[str]:
    """Compatibility wrapper for direct execution."""
    return run_lineage_agent()


# if __name__ == "__main__":
#     main()
