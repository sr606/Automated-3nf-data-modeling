import os
import re
import json
import time
from pathlib import Path
import httpx

from dotenv import load_dotenv
from pydantic import SecretStr
from langchain_openai import AzureChatOpenAI

load_dotenv()

# ============================================
# 🔁 CONFIG
# ============================================
MAX_RETRIES = 3
INPUT_DIR = "data/output"
OUTPUT_DIR = "data/output"

SYSTEM_PROMPT = """You are a JSON-only data lineage processing engine.
Your entire response must be a single valid JSON object.
First character must be { and last character must be }.
No explanation. No markdown. No ```json fences. No text outside the JSON."""


# ============================================
# 🔁 LLM SETUP
# ============================================
def get_llm():
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    deployment = os.getenv("AZURE_OPENAI_CHAT_DEPLOYMENT_NAME")
    api_key = os.getenv("AZURE_OPENAI_API_KEY")

    if not all([endpoint, deployment, api_key]):
        raise ValueError("Missing Azure OpenAI environment variables")

    return AzureChatOpenAI(
        azure_endpoint=endpoint,
        azure_deployment=deployment,
        api_key=SecretStr(api_key),
        api_version="2024-02-01",
        temperature=0.0,
        streaming=False,
        http_client=httpx.Client(
            timeout=httpx.Timeout(300.0, read=600.0)
        )
    )


# ============================================
# 🔁 JSON PARSE
# ============================================
def safe_json_parse(response: str) -> dict:
    response = response.strip()
    response = re.sub(r"```json|```", "", response).strip()
    start = response.find("{")
    end = response.rfind("}") + 1
    if start == -1 or end == 0:
        return {"error": "No JSON found", "raw_output": response}
    try:
        return json.loads(response[start:end])
    except Exception as e:
        return {"error": "Invalid JSON", "exception": str(e), "raw_output": response}


# ============================================
# 🔁 PYTHON MERGE
# Only mechanical deduplication by node id
# LLM handles everything else
# ============================================
def merge_nodes_python(nodes: list) -> list:
    """
    Merge duplicate node IDs by unioning list fields.
    This is pure deduplication — no business logic.
    LLM will handle type, link quality, and edge building.
    """
    node_map: dict[str, dict] = {}
    type_rank = {"target": 4, "lookup": 3, "transform": 2, "source": 1}

    for node in nodes:
        node_id = node.get("id")
        if not node_id:
            continue

        if node_id not in node_map:
            node_map[node_id] = node
            continue

        existing = node_map[node_id]

        for field in [
            "input_links", "output_links", "processing_logic",
            "business_rules", "transformations", "lookups", "joins", "filters"
        ]:
            merged = existing.get(field, []) + node.get(field, [])
            seen = set()
            result = []
            for x in merged:
                key = json.dumps(x, sort_keys=True) if isinstance(x, dict) else str(x)
                if key not in seen:
                    seen.add(key)
                    result.append(x)
            existing[field] = result

        if not existing.get("sql") and node.get("sql"):
            existing["sql"] = node["sql"]

        existing_meta = existing.get("raw_metadata", {})
        for k, v in node.get("raw_metadata", {}).items():
            if k not in existing_meta:
                existing_meta[k] = v
        existing["raw_metadata"] = existing_meta

        existing_rank = type_rank.get(existing.get("type", "transform"), 2)
        new_rank = type_rank.get(node.get("type", "transform"), 2)
        if new_rank > existing_rank:
            existing["type"] = node["type"]

    return list(node_map.values())


# ============================================
# 🔁 PHASE 2 PROMPT
# ============================================
def build_phase2_prompt(nodes: list, master_stage_ids: list) -> str:
    return f"""
You are a DATA LINEAGE GRAPH BUILDER.

You receive a list of stage nodes extracted from a DataStage job.
Your job is to produce a clean, accurate lineage graph with correct nodes and edges.

---

### ALL KNOWN STAGE IDs IN THIS JOB

These are every real stage that exists in this job:
{json.dumps(master_stage_ids, indent=2)}

This is ground truth. Use it throughout every step below.

---

### WHAT YOU ARE BUILDING

A lineage graph where:
- Each node is a real data processing stage
- Each edge represents data flowing from one stage to another
- An edge exists when one stage's output_link name matches another stage's input_link name

The graph will be used to draw a lineage diagram.
Every decision you make should serve that goal.

---

### STEP 1: ASSESS EACH NODE

For each node, read its full content and assess:
- Are its input_links and output_links correct and clean?
- Is its type correct given its role in the pipeline?
- Does it belong in a lineage graph?

A node belongs in the lineage graph if it participates in data movement.
A node does NOT belong if it is a pure infrastructure artifact
with no data flow role — meaning it has no real links after assessment
and no meaningful processing content that affects data.

---

### STEP 2: CLEAN LINKS

For each node's input_links and output_links:

A real link is a named connector that carries data between two stages.
It was explicitly defined in the original job as a flow connector.

Keep a value if it represents real data flow into or out of this stage.
A value can match a stage ID and still be a valid link — this is common in DataStage.

Remove a value only if it is clearly not a data flow connector:
- Pure number or single character
- Contains spaces and reads as a description
- Equals this node's own id
- Came from a metadata configuration field, not a flow definition
  (fields like Partner, FileName, Target Table, ConnectorName are config, not flow)
- Is an auto-generated alias of this node's own id with no flow meaning

When uncertain → keep.
A lost link = a missing edge = broken lineage.

---

### STEP 3: ASSIGN NODE TYPE

Assign exactly one of: source | transform | lookup | target

source    → data enters the pipeline here, no upstream stages feeding it
target    → data exits the pipeline here, writes to final destination
lookup    → provides reference data as side input, not in the main data flow
transform → processes, routes, filters, or joins data between stages

Use the full node context: links, stage_type, processing content, metadata.

---

### STEP 4: BUILD EDGES

This is the most important step.

For each node N, for each link L in its output_links:
  Search all other nodes for any node M where L appears in M.input_links
  If found → create edge:
  {{
    "from": N.id,
    "to": M.id,
    "link_name": L
  }}

Rules:
- Only create edges between nodes you are keeping in the graph
- Never create an edge that is not supported by a real link match
- Never infer or guess an edge
- Deduplicate edges

---

### OUTPUT

Return ONLY this JSON:

{{
  "nodes": [
    {{
      "id": "",
      "type": "",
      "stage_type": "",
      "input_links": [],
      "output_links": [],
      "processing_logic": [],
      "business_rules": [],
      "transformations": [],
      "lookups": [],
      "joins": [],
      "filters": [],
      "sql": null,
      "raw_metadata": {{}}
    }}
  ],
  "edges": [
    {{
      "from": "",
      "to": "",
      "link_name": ""
    }}
  ]
}}

sql → copy exactly, every character unchanged
raw_metadata → preserve all technical fields
input_links and output_links → only fields where values may be removed

---

NODES:
{json.dumps(nodes, indent=2)}
"""


# ============================================
# 🔁 LLM CALL
# ============================================
def call_llm(prompt: str, llm) -> dict:
    for attempt in range(MAX_RETRIES):
        try:
            print(f"  [LLM Attempt {attempt + 1}/{MAX_RETRIES}]")

            response = llm.invoke([
                ("system", SYSTEM_PROMPT),
                ("human", prompt),
            ]).content.strip()

            parsed = safe_json_parse(response)
            if "error" not in parsed:
                return parsed

            print(f"  [Parse failed] {parsed.get('error')}")

        except Exception as e:
            print(f"  [Exception] {e}")

        time.sleep(2)

    return {"error": "LLM failed after all retries"}


# ============================================
# 🔁 SPLIT OUTPUTS
# ============================================
def split_outputs(result: dict) -> tuple[list, dict, list]:
    nodes = result.get("nodes", [])
    edges = result.get("edges", [])

    graph_nodes = []
    metadata_store = {}

    for node in nodes:
        node_id = node.get("id")
        if not node_id:
            continue

        graph_nodes.append({
            "id": node_id,
            "type": node.get("type", "transform"),
            "input_links": node.get("input_links", []),
            "output_links": node.get("output_links", [])
        })

        metadata_store[node_id] = {
            "stage_type": node.get("stage_type", ""),
            "processing_logic": node.get("processing_logic", []),
            "business_rules": node.get("business_rules", []),
            "transformations": node.get("transformations", []),
            "lookups": node.get("lookups", []),
            "joins": node.get("joins", []),
            "filters": node.get("filters", []),
            "sql": node.get("sql"),
            "raw_metadata": node.get("raw_metadata", {})
        }

    return graph_nodes, metadata_store, edges


# ============================================
# 🔁 COVERAGE REPORT
# ============================================
def print_coverage(graph_nodes: list, edges: list, master_stage_ids: list):
    node_ids = {n["id"] for n in graph_nodes}
    connected = {e["from"] for e in edges} | {e["to"] for e in edges}
    isolated = node_ids - connected
    missing = set(master_stage_ids) - node_ids

    print(f"\n[Coverage Report]")
    print(f"  Nodes in graph : {len(node_ids)}")
    print(f"  Edges built    : {len(edges)}")
    print(f"  Connected nodes: {len(connected)}")

    if isolated:
        print(f"  Isolated nodes : {isolated}")
    if missing:
        print(f"  Missing stages : {missing}")


# ============================================
# 🔁 MAIN PHASE 2 FUNCTION
# ============================================
def run_phase2_pipeline():
    input_path = Path(INPUT_DIR)
    output_path = Path(OUTPUT_DIR)
    output_path.mkdir(parents=True, exist_ok=True)

    llm = get_llm()
    files = list(input_path.glob("*phase15.json"))

    if not files:
        print("[ERROR] No phase15 files found")
        return

    print(f"[Found] {len(files)} phase15 file(s)")

    for file in files:
        print(f"\n{'='*50}")
        print(f"[Processing] {file.name}")
        print(f"{'='*50}")

        with open(file, "r", encoding="utf-8") as f:
            phase15_data = json.load(f)

        nodes = phase15_data.get("nodes", [])
        master_stage_ids = phase15_data.get("master_stage_ids", [])

        if not nodes:
            print(f"[Skipped] {file.name} — no nodes")
            continue

        # Python merge: deduplicate same node id across chunks
        print(f"\n[A] Merging {len(nodes)} nodes...")
        merged = merge_nodes_python(nodes)
        print(f"  → {len(merged)} unique nodes")

        # LLM: clean, type, drop garbage, build edges
        print(f"\n[B] LLM graph building...")
        prompt = build_phase2_prompt(merged, master_stage_ids)
        result = call_llm(prompt, llm)

        if "error" in result:
            print(f"[Failed] {file.name} — {result['error']}")
            continue

        graph_nodes, metadata_store, edges = split_outputs(result)

        print_coverage(graph_nodes, edges, master_stage_ids)

        stem = file.stem.replace("_phase15", "")

        with open(output_path / f"{stem}_graph_nodes.json", "w", encoding="utf-8") as f:
            json.dump(graph_nodes, f, indent=2)

        with open(output_path / f"{stem}_metadata_store.json", "w", encoding="utf-8") as f:
            json.dump(metadata_store, f, indent=2)

        with open(output_path / f"{stem}_edges.json", "w", encoding="utf-8") as f:
            json.dump(edges, f, indent=2)

        print(f"\n[Saved]")
        print(f"  → {stem}_graph_nodes.json  ({len(graph_nodes)} nodes)")
        print(f"  → {stem}_metadata_store.json")
        print(f"  → {stem}_edges.json  ({len(edges)} edges)")


# ============================================
# 🔁 ENTRY
# ============================================
if __name__ == "__main__":
    run_phase2_pipeline()
