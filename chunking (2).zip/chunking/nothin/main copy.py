import json
from pathlib import Path


import json
from pathlib import Path


def build_chunks_dict(chunks_dict: dict[str, str]):
    node_map: dict[str, list[dict]] = {}

    for chunk_id, content in chunks_dict.items():
        lines = str(content or "").splitlines()

        current_stage = None
        buffer = []
        chunk_counter = 1

        def save_chunk(stage_name, chunk_lines):
            nonlocal chunk_counter

            if stage_name and chunk_lines:
                chunk_text = "\n".join(chunk_lines)

                node_map.setdefault(stage_name, []).append({
                    "chunk_id": f"{stage_name}_{chunk_counter}",
                    "content": chunk_text
                })

                chunk_counter += 1

        for line in lines:
            stripped = line.strip()

            if stripped.startswith("STAGE:"):
                save_chunk(current_stage, buffer)
                buffer = []

                parts = stripped.split("STAGE:", 1)[1].strip()
                current_stage = parts.split("(")[0].strip()
                chunk_counter = 1  # reset per stage

            buffer.append(line)

        save_chunk(current_stage, buffer)

    return node_map

# =============================
# 🔹 MAIN PIPELINE FUNCTION
# =============================
def generate_chunks_from_directory(input_dir="data/input", output_dir="data/output"):
    input_path = Path(input_dir)
    output_path = Path(output_dir)

    output_path.mkdir(parents=True, exist_ok=True)

    # 🔹 Process each file separately
    for file in input_path.glob("*"):
        if file.is_file():
            print(f"📂 Processing: {file.name}")

            with open(file, "r", encoding="utf-8") as f:
                content = f.read()

            # 🔹 Pass SINGLE file as dict
            chunks_dict = {file.stem: content}

            result = build_chunks_dict(chunks_dict)

            # 🔹 Create separate output file
            output_file = output_path / f"{file.stem}_chunks.json"

            with open(output_file, "w", encoding="utf-8") as f:
                json.dump(result, f, indent=2, ensure_ascii=False)

            print(f"✅ Saved: {output_file}")

    print("🎯 All files processed successfully!")


# =============================
# 🔹 RUN
# =============================
if __name__ == "__main__":
    generate_chunks_from_directory()