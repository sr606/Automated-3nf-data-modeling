import os
import re
import json
import time
from pathlib import Path
import httpx

from dotenv import load_dotenv
from pydantic import SecretStr
from langchain_openai import AzureChatOpenAI

# ============================================
# 🔹 LOAD ENV
# ============================================
load_dotenv()

# ============================================
# 🔹 CONFIG
# ============================================
BATCH_SIZE = 5
MAX_RETRIES = 3
INPUT_DIR = "data/output"
OUTPUT_DIR = "data/output"

# ============================================
# 🔹 SYSTEM PROMPT
# ============================================
SYSTEM_PROMPT = """You are a JSON-only data lineage processing engine.
Your entire response must be a single valid JSON object.
First character must be { and last character must be }.
No explanation. No markdown. No ```json fences. No text of any kind outside the JSON."""


# ============================================
# 🔹 LLM SETUP
# ============================================
def get_llm():
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    deployment = os.getenv("AZURE_OPENAI_CHAT_DEPLOYMENT_NAME")
    api_key = os.getenv("AZURE_OPENAI_API_KEY")

    if not all([endpoint, deployment, api_key]):
        raise ValueError("Missing Azure OpenAI environment variables")

    return AzureChatOpenAI(
        azure_endpoint=endpoint,
        azure_deployment=deployment,
        api_key=SecretStr(api_key),
        api_version="2024-02-01",
        temperature=0.0,
        streaming=False,
        http_client=httpx.Client(
            timeout=httpx.Timeout(300.0, read=600.0)
        )
    )


# ============================================
# 🔹 JSON RECOVERY + PARSE
# ============================================
def safe_json_parse(response: str) -> dict:
    """Defensively extract and parse JSON regardless of wrapping."""
    response = response.strip()

    # Strip markdown fences
    response = re.sub(r"```json|```", "", response).strip()

    # Find outermost JSON object boundaries
    start = response.find("{")
    end = response.rfind("}") + 1

    if start == -1 or end == 0:
        return {
            "error": "No JSON found in response",
            "raw_output": response
        }

    try:
        return json.loads(response[start:end])
    except Exception as e:
        return {
            "error": "Invalid JSON",
            "exception": str(e),
            "raw_output": response
        }


def recover_chunk(v: dict) -> dict | None:
    """
    Try to recover a valid JSON node from a failed Phase 1 chunk.
    Phase 1 errors store the raw LLM output in 'raw_output' which
    often contains valid JSON wrapped in prose or markdown.
    """
    raw = v.get("raw_output", "")
    if not raw:
        return None

    result = safe_json_parse(raw)

    if "error" not in result:
        return result

    return None


# ============================================
# 🔹 PROMPT — PASTE YOUR PROMPT HERE
# ============================================
def build_phase2_prompt(batch_json: str) -> str:
    return f"""
You are a DATA LINEAGE MERGE AGENT building a graph for a lineage diagram.

You receive a JSON array. Each item is either:
- A Phase 1 extraction: dict with stage IDs as keys, each having "nodes" and "edges"
- A partial merge result: dict with "nodes" (list) and "edges" (list)

Produce one unified graph. Every decision must serve lineage diagram accuracy.

---

### STEP 1: BUILD MASTER NODE ID SET

Collect every real stage ID across all input items:
- Raw chunks: every top-level key
- Merged results: every "id" in the "nodes" list

This set is ground truth. Use it in every step below.

---

### STEP 2: DROP NON-LINEAGE NODES

A lineage diagram shows data movement between real processing stages.
Drop a node only if it clearly has NO role in data movement:
- It is a pure infrastructure artifact (transaction coordinator, internal connector wrapper)
  with no meaningful input_links, output_links, processing_logic, or sql
- It creates a circular self-reference (same value in both input and output links)
  and has no other connections

When in doubt → KEEP. A false positive ruins the diagram. A false negative just adds noise.

---

### STEP 3: CLEAN LINKS

For every node's input_links and output_links:

Split any value containing "|" into separate values first.

Then remove a value if:
- It equals this node's own id
- It is a pure number or single character
- It is a known stage id from the Master Node ID Set
  (stage names are nodes, not links — they must never appear as link values)
- It was auto-generated from this node's own id
  (node's id + any suffix like _Out _In _Output _output _result)
  AND that exact string is NOT itself a real node id in the Master Node ID Set

Keep everything else — genuine link names connect the graph.

---

### STEP 4: MERGE DUPLICATE NODES

Same node id appearing in multiple chunks:
- Union all list fields, deduplicate within each
- sql: keep whichever instance has it, never overwrite with null
- raw_metadata: merge keys, prefer richer value on conflict
- type: use most specific (target > lookup > transform > source)

---

### STEP 5: ASSIGN NODE TYPE

Goal: type must be correct for the lineage diagram to make sense.

source  → data enters the pipeline here (no real input_links after cleaning)
target  → data exits the pipeline here (no real output_links after cleaning,
          writes to database/file, terminal node)
lookup  → provides reference data as a side input to another stage
          (hashed files, reference datasets — not the main data flow)
transform → processes, filters, joins, routes, or transforms data between stages

Use input_links, output_links, stage_type, raw_metadata context, and processing_logic together.
A node with context="target" or write mode metadata and no real output links → target.
A node feeding another stage only as a reference/lookup → lookup.

---

### STEP 6: BUILD EDGES

Edges are the lineage. Build them carefully.

For each node N, for each link L in N.output_links:
  Search all other nodes for any node M where L appears in M.input_links
  If found → edge: {{"from": N.id, "to": M.id, "link_name": L}}

Also carry forward any existing edges from input where both from and to
exist in the Master Node ID Set.

Deduplicate. Never invent. Every edge must be traceable to a real link match.

---

### OUTPUT

Return ONLY this JSON. Nothing before it. Nothing after it.

{{
  "nodes": [
    {{
      "id": "",
      "type": "",
      "stage_type": "",
      "input_links": [],
      "output_links": [],
      "processing_logic": [],
      "business_rules": [],
      "transformations": [],
      "lookups": [],
      "joins": [],
      "filters": [],
      "sql": null,
      "raw_metadata": {{}}
    }}
  ],
  "edges": [
    {{
      "from": "",
      "to": "",
      "link_name": ""
    }}
  ]
}}

sql → copy exactly, every character, no changes ever
raw_metadata → keep all technical fields, drop only UI layout noise
links → the only fields where values may be removed

INPUT:
{batch_json}
"""


# ============================================
# 🔹 LLM CALL
# ============================================
def call_llm(prompt: str, llm) -> dict:
    for attempt in range(MAX_RETRIES):
        try:
            print(f"  [LLM Attempt {attempt + 1}/{MAX_RETRIES}]")

            response = llm.invoke(
                [
                    ("system", SYSTEM_PROMPT),
                    ("human", prompt),
                ]
            ).content.strip()

            parsed = safe_json_parse(response)

            if "error" not in parsed:
                return parsed

            print(f"  [Parse failed] {parsed.get('error')}")

        except Exception as e:
            print(f"  [Exception] {e}")

        time.sleep(2)

    return {"error": "LLM failed after all retries"}


# ============================================
# 🔹 CHUNK PREPARATION
# ============================================
def prepare_chunks(phase1_data: dict) -> list:
    """
    Extract valid chunks from Phase 1 output.
    Attempts to recover JSON from failed chunks before discarding.
    """
    chunks = []
    recovered = 0
    skipped = 0

    for stage_id, v in phase1_data.items():
        if not isinstance(v, dict):
            skipped += 1
            continue

        if "error" not in v:
            chunks.append(v)
        else:
            result = recover_chunk(v)
            if result:
                chunks.append(result)
                recovered += 1
                print(f"  [Recovered] {stage_id}")
            else:
                skipped += 1
                print(f"  [Skipped] {stage_id} — unrecoverable")

    print(f"  [Chunks] {len(chunks)} valid | {recovered} recovered | {skipped} skipped")
    return chunks


# ============================================
# 🔹 BATCH MERGE
# ============================================
def merge_in_batches(chunks: list, llm) -> list:
    batches = [
        chunks[i:i + BATCH_SIZE]
        for i in range(0, len(chunks), BATCH_SIZE)
    ]

    merged = []

    for idx, batch in enumerate(batches):
        print(f"  [Batch {idx + 1}/{len(batches)}] {len(batch)} items")

        batch_input = json.dumps(batch, separators=(",", ":"))
        prompt = build_phase2_prompt(batch_input)
        result = call_llm(prompt, llm)

        if "error" in result:
            print(f"  [Batch {idx + 1}] Failed — skipping")
        else:
            merged.append(result)

    return merged


# ============================================
# 🔹 HIERARCHICAL MERGE
# ============================================
def hierarchical_merge(chunks: list, llm) -> dict:
    """
    Repeatedly merges batches until a single unified graph remains.
    
    Pass 1: N raw chunks → N/BATCH_SIZE merged results
    Pass 2: merged results → fewer results
    ...until 1 final graph remains
    """
    current = chunks
    level = 1

    while len(current) > 1:
        print(f"\n[Merge Level {level}] {len(current)} items → batching by {BATCH_SIZE}")
        current = merge_in_batches(current, llm)

        if not current:
            return {"error": "All batches failed during merge"}

        level += 1

    if not current:
        return {"error": "No results after merge"}

    return current[0]


# ============================================
# 🔹 SPLIT OUTPUTS
# ============================================
def split_graph_outputs(final_graph: dict) -> tuple[list, dict, list]:
    """
    Split the final merged graph into 3 separate outputs:
    - graph_nodes: lightweight node list for graph rendering
    - metadata_store: full node detail keyed by node id
    - edges: directed edges for lineage diagram
    """
    nodes = final_graph.get("nodes", [])
    edges = final_graph.get("edges", [])

    graph_nodes = []
    metadata_store = {}

    for node in nodes:
        node_id = node.get("id")

        if not node_id:
            continue

        graph_nodes.append({
            "id": node_id,
            "type": node.get("type", "transform"),
            "input_links": node.get("input_links", []),
            "output_links": node.get("output_links", [])
        })

        metadata_store[node_id] = {
            "stage_type": node.get("stage_type", ""),
            "processing_logic": node.get("processing_logic", []),
            "business_rules": node.get("business_rules", []),
            "transformations": node.get("transformations", []),
            "lookups": node.get("lookups", []),
            "joins": node.get("joins", []),
            "filters": node.get("filters", []),
            "sql": node.get("sql"),
            "raw_metadata": node.get("raw_metadata", {})
        }

    return graph_nodes, metadata_store, edges


# ============================================
# 🔹 MAIN PHASE 2 FUNCTION
# ============================================
def generate_phase2_outputs(phase1_data: dict, llm) -> dict:
    print("\n[Phase 2] Preparing chunks...")
    chunks = prepare_chunks(phase1_data)

    if not chunks:
        return {"error": "No valid chunks to process"}

    print(f"\n[Phase 2] Starting hierarchical merge of {len(chunks)} chunks...")
    final_graph = hierarchical_merge(chunks, llm)

    if "error" in final_graph:
        print(f"[Phase 2] Merge failed: {final_graph['error']}")
        return final_graph

    graph_nodes, metadata_store, edges = split_graph_outputs(final_graph)

    print(f"\n[Phase 2] Complete — {len(graph_nodes)} nodes | {len(edges)} edges")

    return {
        "graph_nodes": graph_nodes,
        "metadata_store": metadata_store,
        "edges": edges
    }


# ============================================
# 🔹 PIPELINE RUNNER
# ============================================
def run_phase2_pipeline():
    input_path = Path(INPUT_DIR)
    output_path = Path(OUTPUT_DIR)
    output_path.mkdir(parents=True, exist_ok=True)

    llm = get_llm()

    files = list(input_path.glob("*phase1.json"))

    if not files:
        print("[ERROR] No phase1 files found")
        return

    print(f"[Found] {len(files)} phase1 file(s)")

    for file in files:
        print(f"\n{'='*50}")
        print(f"[Processing] {file.name}")
        print(f"{'='*50}")

        with open(file, "r", encoding="utf-8") as f:
            phase1_data = json.load(f)

        result = generate_phase2_outputs(phase1_data, llm)

        if "error" in result:
            print(f"[Skipped] {file.name} — {result['error']}")
            continue

        stem = file.stem.replace("_phase1", "")

        graph_nodes_path = output_path / f"{stem}_graph_nodes.json"
        metadata_path = output_path / f"{stem}_metadata_store.json"
        edges_path = output_path / f"{stem}_edges.json"

        with open(graph_nodes_path, "w", encoding="utf-8") as f:
            json.dump(result["graph_nodes"], f, indent=2)

        with open(metadata_path, "w", encoding="utf-8") as f:
            json.dump(result["metadata_store"], f, indent=2)

        with open(edges_path, "w", encoding="utf-8") as f:
            json.dump(result["edges"], f, indent=2)

        print(f"\n[Saved]")
        print(f"  → {graph_nodes_path.name}")
        print(f"  → {metadata_path.name}")
        print(f"  → {edges_path.name}")


# ============================================
# 🔹 ENTRY
# ============================================
if __name__ == "__main__":
    run_phase2_pipeline()