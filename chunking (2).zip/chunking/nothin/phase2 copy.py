import os
import json
import time
from pathlib import Path
import httpx

from dotenv import load_dotenv
from pydantic import SecretStr
from langchain_openai import AzureChatOpenAI

# ============================================
# 🔹 LOAD ENV
# ============================================
load_dotenv()

# ============================================
# 🔹 CONFIG
# ============================================
BATCH_SIZE = 5   # 🔥 change here if needed
MAX_RETRIES = 3


# ============================================
# 🔹 LLM SETUP
# ============================================
def get_llm():
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    deployment = os.getenv("AZURE_OPENAI_CHAT_DEPLOYMENT_NAME")
    api_key = os.getenv("AZURE_OPENAI_API_KEY")

    if not all([endpoint, deployment, api_key]):
        raise ValueError("❌ Missing Azure OpenAI environment variables")

    timeout = httpx.Timeout(300.0, read=600.0)

    return AzureChatOpenAI(
        azure_endpoint=endpoint,
        azure_deployment=deployment,
        api_key=SecretStr(api_key),
        api_version="2024-02-01",
        temperature=0.0,
        streaming=False,
        http_client=httpx.Client(timeout=timeout)
    )


# ============================================
# 🔹 CLEAN + PARSE
# ============================================
def clean_llm_json(response: str) -> str:
    response = response.strip()

    if response.startswith("```"):
        response = response.replace("```json", "")
        response = response.replace("```", "")

    return response.strip()


def safe_json_parse(response: str):
    cleaned = clean_llm_json(response)

    try:
        return json.loads(cleaned)
    except Exception as e:
        return {
            "error": "Invalid JSON from LLM",
            "exception": str(e),
            "raw_output": response
        }


# ============================================
# 🔹 PHASE 2 PROMPT
# ============================================
def build_phase2_prompt(batch_json: str) -> str:
    return f"""
You are a Graph Normalization and Validation Engine.

Your responsibility is to merge and clean structured graph JSON data.

You MUST NOT:
- infer missing information
- create new nodes or edges
- modify logic or meaning
- hallucinate relationships

You MUST:
- merge duplicate nodes
- normalize edges
- resolve partial connections using existing link mappings
- enforce schema consistency
- remove invalid or duplicate data

You operate deterministically, not creatively.

IMPORTANT:
- Return ONLY valid JSON
- Do NOT include explanations
- Do NOT add new nodes, edges, or logic
- Output must start with {{ and end with }}

OBJECTIVE:
Normalize and merge multiple chunk-level graph JSONs into a single consistent graph.

STRICT RULES:

1. NO HALLUCINATION:
- Do NOT create new nodes, edges, or relationships
- Do NOT infer missing logic
- Only use data explicitly present in input

2. NODE MERGING:
- Nodes with same "id" must be merged into one
- Combine fields:
  - processing_logic
  - business_rules
  - transformations
  - lookups
  - joins
  - filters
- Remove duplicates within lists
- Preserve all unique information

3. EDGE NORMALIZATION:
- Keep only valid edges:
  - "from" and "to" must match existing node ids OR be null
- Remove edges where both "from" and "to" are null

4. PARTIAL EDGE RESOLUTION:
- If "from" is null:
  → find node whose "output_links" contains edge.link_name
  → set "from" to that node id

- If "to" is null:
  → find node whose "input_links" contains edge.link_name
  → set "to" to that node id

- If no match found:
  → keep null (do NOT infer)

5. LINK CONSISTENCY:
- Ensure "link_name" remains unchanged
- Do NOT replace link_name with stage names

6. NODE CONSISTENCY:
- Ensure all edges reference exact node ids
- Do NOT modify node names

7. TYPE STANDARDIZATION:
- Ensure node "type" is one of:
  source | transform | lookup | target | exception | intermediate

8. REMOVE DUPLICATES:
- Remove duplicate nodes (same id)
- Remove duplicate edges (same from, to, link_name)

9. CLEAN METADATA:
- Keep raw_metadata minimal
- Remove large nested structures (e.g., column definitions)
- Preserve only essential metadata

10. PRESERVE STRUCTURE:
- Do NOT remove valid nodes or edges
- Maintain complete connectivity

ADDITIONAL CONSTRAINTS:

11. EDGE VALIDATION:
- "from" and "to" must be valid node ids or null
- If a link name appears in "from" or "to", replace it with null
- If "from" or "to" is not in node ids → set to null
- Remove invalid edges - self loops/ duplicate edges/ null-null edges

12. LINK VALIDATION:
- link_name must match actual link identifiers, only allow link_name == input_links/output_links
- Do NOT modify incorrect link_name, but ignore it during resolution

13. STRICT MATCHING:
- Resolve edges ONLY using exact string matches
- Do NOT perform fuzzy matching or inference

14. METADATA CLEANING:
- Remove large nested structures such as:
  - column definitions
  - schema blocks
- Keep only essential metadata:
  - connection info
  - table/file names
  - execution settings

15. ORDER STABILITY:
- Maintain deterministic ordering of nodes and edges

OUTPUT FORMAT:
{{
  "nodes": [...],
  "edges": [...]
}}

INPUT:
{batch_json}

"""


# ============================================
# 🔹 SINGLE MERGE CALL
# ============================================
def call_llm(prompt, llm):
    for attempt in range(MAX_RETRIES):
        try:
            print(f"\n[Attempt {attempt+1}]")

            response = llm.invoke(
                [
                    ("system", "Return only valid JSON. Do not ask for missing input if JSON is already present."),
                    ("human", prompt),
                ]
            ).content.strip()

            print("\n[Raw response - first 1000 chars]\n")
            print(response[:1000])

            parsed = safe_json_parse(response)

            if "error" not in parsed:
                return parsed
            else:
                print("[JSON parse failed]")

        except Exception as e:
            print(f"[Exception] {e}")

        time.sleep(2)

    return {"error": "LLM failed after retries"}

# ============================================
# 🔹 BATCH MERGE
# ============================================
def merge_in_batches(chunks, llm):
    print(f"[Merge] {len(chunks)} chunks in batches of {BATCH_SIZE}")

    batches = [
        chunks[i:i + BATCH_SIZE]
        for i in range(0, len(chunks), BATCH_SIZE)
    ]

    merged_batches = []

    for idx, batch in enumerate(batches):
        print(f"   [Batch {idx+1}/{len(batches)}]")

        batch_input = json.dumps(batch, separators=(",", ":"))
        prompt = build_phase2_prompt(batch_input)

        result = call_llm(prompt, llm)
        merged_batches.append(result)

    return merged_batches


# ============================================
# 🔹 ITERATIVE MERGE (HIERARCHICAL)
# ============================================
def hierarchical_merge(all_chunks, llm):
    current_level = all_chunks

    level = 1

    while len(current_level) > 1:
        print(f"\n[Merge level {level}] {len(current_level)} items")

        current_level = merge_in_batches(current_level, llm)
        level += 1

    return current_level[0]


# ============================================
# 🔹 MAIN PHASE 2 FUNCTION
# ============================================
def generate_phase2_graph(phase1_data, llm):
    print(f"[Total chunks] {len(phase1_data)}")

    # 🔹 Extract valid chunks
    chunks = [
        v for v in phase1_data.values()
        if isinstance(v, dict) and "error" not in v
    ]

    if not chunks:
        return {"error": "No valid chunks"}

    # 🔥 Hierarchical merge
    final_graph = hierarchical_merge(chunks, llm)

    return final_graph


# ============================================
# 🔹 PIPELINE RUNNER
# ============================================
def run_phase2_pipeline(input_dir="data/output", output_dir="data/output"):
    input_path = Path(input_dir)
    output_path = Path(output_dir)

    output_path.mkdir(parents=True, exist_ok=True)

    llm = get_llm()

    input_files = list(input_path.glob("*phase1.json"))

    if not input_files:
        print("[Error] No phase1 files found")
        return

    print(f"[Found] {len(input_files)} files")

    for file in input_files:
        print(f"\n[Processing] {file.name}")

        with open(file, "r", encoding="utf-8") as f:
            phase1_data = json.load(f)

        result = generate_phase2_graph(phase1_data, llm)

        output_file = output_path / file.name.replace("phase1.json", "phase2.json")

        with open(output_file, "w", encoding="utf-8") as f:
            json.dump(result, f, indent=2, ensure_ascii=False)

        print(f"[Saved] {output_file}")


# ============================================
# 🔹 ENTRY
# ============================================
if __name__ == "__main__":
    run_phase2_pipeline()
