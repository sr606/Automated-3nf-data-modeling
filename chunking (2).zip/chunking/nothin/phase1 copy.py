import os
import json
import time
from pathlib import Path
import httpx

from dotenv import load_dotenv
from pydantic import SecretStr
from langchain_openai import AzureChatOpenAI


# ============================================
# 🔹 LOAD ENV
# ============================================
load_dotenv()


# ============================================
# 🔹 LLM SETUP
# ============================================
def get_llm():
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    deployment = os.getenv("AZURE_OPENAI_CHAT_DEPLOYMENT_NAME")
    api_key = os.getenv("AZURE_OPENAI_API_KEY")

    if not all([endpoint, deployment, api_key]):
        raise ValueError("❌ Missing Azure OpenAI environment variables")

    timeout = httpx.Timeout(300.0, read=600.0)

    return AzureChatOpenAI(
        azure_endpoint=endpoint,
        azure_deployment=deployment,
        api_key=SecretStr(api_key),
        api_version="2024-02-01",
        temperature=0.0,
        streaming=False,
        http_client=httpx.Client(timeout=timeout)
    )


# ============================================
# 🔹 CLEAN LLM OUTPUT
# ============================================
def clean_llm_json(response: str) -> str:
    response = response.strip()

    if response.startswith("```"):
        response = response.replace("```json", "")
        response = response.replace("```", "")

    return response.strip()


def safe_json_parse(response: str):
    cleaned = clean_llm_json(response)

    try:
        return json.loads(cleaned)
    except Exception as e:
        return {
            "error": "Invalid JSON from LLM",
            "exception": str(e),
            "raw_output": response
        }


# ============================================
# 🔹 CORE FUNCTION
# ============================================
def generate_graph_json_one_by_one_chunk(chunks_dict, llm):
    final_results = {}

    print(f"📦 Total chunks received: {len(chunks_dict)}")

    for i, (chunk_id, chunk_content) in enumerate(chunks_dict.items()):
        start_time = time.time()

        prompt = f"""
IMPORTANT:
- Return ONLY valid JSON
- Do NOT wrap output in ``` or ```json
- Do NOT include explanations
- Output must start with { and end with }

═══════════════════════════════════════════
PURPOSE
═══════════════════════════════════════════
Extract all stages as nodes and all direct stage-to-stage connections as edges
from this chunk. Output will be merged with other chunks to build a full DAG
for data lineage. Every node and edge must be self-consistent and merge-safe.

═══════════════════════════════════════════
INPUT FORMAT DETECTION — DO THIS FIRST
═══════════════════════════════════════════
Before extracting anything, identify which format this chunk uses:

FORMAT A — global_links present and non-empty:
  The chunk contains a "global_links" array of [source, target] pairs
  where entries alternate between stage names and link names:
    ["stage_A", "link_X"]  means stage_A emits link_X
    ["link_X", "stage_B"]  means link_X delivers to stage_B
  → Resolve by chaining: stage_A → link_X → stage_B becomes edge: stage_A → stage_B via link_X
  → Use global_links as the PRIMARY source for edges
  → Use stage raw_text and properties as PRIMARY source for node metadata

FORMAT B — no global_links or global_links is empty:
  The chunk has no global_links array or it is []
  → Resolve edges from raw_text: look for "Input Link:", "Output Link:",
    "Target Stage:", "from X", "to X" patterns inside each stage's raw_text
  → Also use input_links and output_links arrays from the stage definition
    as supporting evidence, but raw_text is the source of truth
  → Cross-reference: if stage A mentions "Output Link: X → stage_B",
    create edge from A to B with link_name X

═══════════════════════════════════════════
LINK RESOLUTION RULE — CORE RULE
═══════════════════════════════════════════
Links are connectors between stages — they are NOT nodes.

A link name (e.g. "Lnk_Vehicle_off_Road_Data", "lkVehicleDim_REg", "V0S2P7")
must NEVER appear as a node "id".

To resolve a link to an edge:
  STEP 1: Find which stage EMITS this link (it appears in that stage's output)
  STEP 2: Find which stage RECEIVES this link (it appears in that stage's input)
  STEP 3: Create edge: {{ from: emitting_stage_id, to: receiving_stage_id, link_name: link }}

If STEP 1 or STEP 2 cannot be resolved within this chunk → set that endpoint to null.
A link with both endpoints null → do NOT create an edge for it.

LINK CHAIN RESOLUTION (for FORMAT A global_links):
  Scan the global_links array for consecutive pairs sharing the same link name:
    ["stage_A", "link_X"] followed by ["link_X", "stage_B"]
    → edge: from=stage_A, to=stage_B, link_name=link_X
  If the second pair ["link_X", "stage_B"] does not appear in this chunk
    → edge: from=stage_A, to=null, link_name=link_X

═══════════════════════════════════════════
CHUNK ISOLATION — HIGHEST PRIORITY RULE
═══════════════════════════════════════════
- A node MUST only be created if its stage is explicitly defined in THIS chunk
  with its own stage_id and properties
- A stage that appears only as a link endpoint, flow reference, or mention in
  raw_text is NOT a node — do NOT create a node for it
- The EXECUTION_FLOW, DATA_FLOW_SUMMARY, STAGES_SUMMARY, LINKS_SUMMARY,
  and PARENT_CHILD_HIERARCHY sections at the end of raw_text are
  REFERENCE DOCUMENTATION ONLY — do NOT create new nodes or edges from them
  if those stages are not defined in the stages block of this chunk

NODE EXISTENCE TEST (apply before creating any node):
  Ask: "Does this chunk's stages block contain an explicit definition
        for this stage with its own stage_id?"
  YES → create the node
  NO  → do NOT create the node

═══════════════════════════════════════════
NODE EXTRACTION RULE
═══════════════════════════════════════════
For each stage defined in the stages block:

1. USE stage_id as the node "id" — copy exactly, no modification
2. USE stage_type from the stage definition
3. CLASSIFY type using the decision tree below
4. EXTRACT all fields from raw_text into the correct schema fields
5. SET input_links and output_links to resolved STAGE IDs only
   (not link names — apply link resolution rule above)
   If the connected stage is not in this chunk → omit it from the array
   (do not put null inside arrays — arrays contain only valid stage IDs)

NODE TYPE DECISION TREE — apply in order, stop at first match:
  1. Reads from DB/file/API, nothing feeds it data rows, is the origin?
     → source
  2. Serves only as reference data for lookups (hashed file read, dimension cache)?
     → lookup
  3. Writes final data to DB table or file, terminal stage?
     → target
  4. Handles rejected, errored, or invalid records specifically?
     → exception
  5. Applies transformations, routing, conditional logic, derivations?
     → transform
  6. Passes data through with no meaningful logic change?
     → intermediate

STAGE TYPE EXAMPLES:
  OracleConnector reading source data          → source
  CHashedFileStage / HashedFileStage reading   → lookup
  CTransformerStage                            → transform
  OracleConnector writing to target table      → target
  SeqFileStage writing exception/reject file   → exception
  HashedOutput / Hashed File Output writing    → target
  CustomStage managing transactions only       → intermediate
  CustomStage with connection context=source   → source
  CustomStage with connection context=target   → intermediate (wraps target connector)

═══════════════════════════════════════════
DATA COMPLETENESS RULE
═══════════════════════════════════════════
Every node MUST be fully populated. Per-node checklist:

  □ processing_logic  — ALL execution steps from raw_text, preserve order
                        NEVER omit steps even if technical or repetitive

  □ transformations   — ALL column mappings, derivations, CASE expressions,
                        MAP statements, column definitions with types
                        NEVER leave empty if mappings exist in raw_text

  □ business_rules    — ALL stage variables, conditional expressions,
                        constraints, exception routing conditions
                        NEVER leave empty if conditions exist in raw_text

  □ sql               — copy EXACTLY as written, no truncation, no summary
                        Store only in "sql" field, nowhere else

  □ filters           — ALL row-level filter/constraint conditions

  □ lookups           — ALL reference lookups, keying logic, lookup file names

  □ joins             — ALL join conditions between datasets

  □ raw_metadata      — connector config, session config, file config,
                        technical properties ONLY
                        NEVER place logic, conditions, or derivations here

  If a field has no data in raw_text → use [] or null
  If a field HAS data in raw_text → omission is an extraction failure

═══════════════════════════════════════════
EDGE EXTRACTION RULE
═══════════════════════════════════════════
Edges represent direct stage-to-stage data flow, resolved through links.

BEFORE creating any edge:
  1. Is this connection explicitly traceable in this chunk
     (via global_links chain OR raw_text link references)?
     NO → do NOT create the edge
  2. Is "from" a valid stage_id defined in this chunk or resolvable to null?
     Is "to" a valid stage_id defined in this chunk or resolvable to null?
     Both null → do NOT create the edge
  3. Does an identical edge (same from, to, link_name) already exist?
     YES → do NOT duplicate it

FLOW TYPE:
  main      → normal data flow between stages
  lookup    → reference/dimension data flow into a transform or target
  exception → reject, error, or validation failure flow

CONDITION:
  Populate only if the flow has an explicit filter or constraint
  (e.g. "svException = -1", "SUPP_SK = -99")
  Otherwise null

═══════════════════════════════════════════
GRAPH CONSISTENCY RULE
═══════════════════════════════════════════
Before finalising output, apply all three checks:

CHECK 1 — BIDIRECTIONAL CONSISTENCY:
  If stage A is in node B's input_links → stage B must be in stage A's output_links
  If stage B is in node A's output_links → stage A must be in stage B's input_links
  Fix arrays to be consistent — edges are the source of truth

CHECK 2 — ARRAY CONTENTS:
  Every value in input_links and output_links must exactly match a node "id"
  in this chunk's output — never link names, never external stage names

CHECK 3 — EDGE ID EXACTNESS:
  "from" and "to" must exactly match a node "id" in this chunk, or be null
  Never append type labels (use "V0S1P2" not "V0S1P2 OracleConnector")

═══════════════════════════════════════════
DUPLICATE NODE RULE
═══════════════════════════════════════════
- Each stage_id must appear as a node exactly once
- If the same stage is referenced in multiple places in this chunk,
  merge all information into a single node
- Never split or repeat a node

═══════════════════════════════════════════
FIELD MAPPING PRIORITY
═══════════════════════════════════════════
processing_logic  → ordered execution steps
business_rules    → conditional logic, stage variables, exception conditions,
                    constraints, routing rules based on values
transformations   → column mappings, derivations, CASE on columns, type casts,
                    MAP statements, column definitions
lookups           → reference lookups with key expressions and file/table names
joins             → join conditions between datasets
filters           → row-level WHERE-style conditions, row constraints
sql               → full SQL only, verbatim, never summarised
raw_metadata      → connector config, session/transaction/file config,
                    technical properties — NEVER logic or derivations

═══════════════════════════════════════════
MERGE-SAFETY RULES
═══════════════════════════════════════════
These rules ensure this chunk's output can be safely merged with other chunks:

1. NODE IDs must use the exact stage_id from the input — never invent or shorten
2. LINK NAMES in edges must be the exact link identifier from the source —
   never invent or paraphrase
3. NULL ENDPOINTS signal cross-chunk connections — downstream merge will resolve them
4. Do NOT resolve cross-chunk connections by guessing — preserve null
5. Do NOT add nodes from other chunks even if you recognise them from context

═══════════════════════════════════════════
STRICT OUTPUT SCHEMA
═══════════════════════════════════════════
{
  "nodes": [
    {
      "id": "exact_stage_id",
      "type": "source | transform | lookup | target | exception | intermediate",
      "stage_type": "exact_stage_type_from_input",
      "input_links": ["stage_id_only"],
      "output_links": ["stage_id_only"],
      "processing_logic": [],
      "business_rules": [],
      "transformations": [],
      "lookups": [],
      "joins": [],
      "filters": [],
      "sql": null,
      "raw_metadata": {}
    }
  ],
  "edges": [
    {
      "from": "stage_id_or_null",
      "to": "stage_id_or_null",
      "link_name": "exact_link_identifier",
      "flow_type": "main | lookup | exception",
      "condition": null
    }
  ]
}

INPUT:
{chunk_content}
"""

        response = None

        # 🔁 Retry mechanism
        for attempt in range(3):
            try:
                response = llm.invoke(prompt).content.strip()
                parsed = safe_json_parse(response)

                # if parsed successfully → break
                if "error" not in parsed:
                    break

            except Exception as e:
                if attempt == 2:
                    parsed = {
                        "error": "LLM call failed",
                        "exception": str(e)
                    }
                else:
                    time.sleep(2)

        final_results[chunk_id] = parsed

        elapsed = time.time() - start_time
        print(f"✅ {chunk_id} | {elapsed:.2f}s")

    return final_results


# ============================================
# 🔹 PIPELINE RUNNER
# ============================================
def run_phase1_pipeline(input_dir="data/output", output_dir="data/output"):
    input_path = Path(input_dir)
    output_path = Path(output_dir)

    output_path.mkdir(parents=True, exist_ok=True)

    llm = get_llm()

    input_files = list(input_path.glob("*chunks.json"))

    if not input_files:
        print("❌ No chunk files found")
        return

    print(f"📂 Found {len(input_files)} chunk files")

    for file in input_files:
        print(f"\n🚀 Processing: {file.name}")

        with open(file, "r", encoding="utf-8") as f:
            chunks_dict = json.load(f)

        result = generate_graph_json_one_by_one_chunk(chunks_dict, llm)

        output_file = output_path / file.name.replace("chunks.json", "phase1.json")

        with open(output_file, "w", encoding="utf-8") as f:
            json.dump(result, f, indent=2, ensure_ascii=False)

        print(f"💾 Saved: {output_file}")


# ============================================
# 🔹 ENTRY POINT
# ============================================
if __name__ == "__main__":
    run_phase1_pipeline()