import json
import shutil
import time
from datetime import datetime
from pathlib import Path

from methods.lineage import (
    generate_chunks_from_directory,
    run_phase1_pipeline,
    run_phase15_pipeline,
    run_phase2_pipeline,
    run_phase3_pipeline,
)

BASE_DIR = Path(__file__).resolve().parent
OUTPUT_DIR = BASE_DIR / "data" / "output"
ARTIFACTS_DIR = BASE_DIR / "data" / "artifacts"

PHASE_OUTPUT_PATTERNS = {
    "phase0_chunking": ["*_chunks.json"],
    "phase1_extraction": ["*_phase1.json"],
    "phase15_link_cleanup": ["*_phase15.json"],
    "phase2_graph_build": [
        "*_graph_nodes.json",
        "*_metadata_store.json",
        "*_edges.json",
    ],
    "phase3_diagrams": [
        "*_lineage_technical.dot",
        "*_lineage_technical.png",
        "*_lineage_technical.svg",
        "*_lineage_business.dot",
        "*_lineage_business.png",
        "*_lineage_business.svg",
    ],
}


def collect_phase_files(patterns: list[str], modified_after: float | None = None) -> list[Path]:
    files: list[Path] = []
    for pattern in patterns:
        files.extend(OUTPUT_DIR.glob(pattern))
    unique = []
    for path in sorted({p.resolve() for p in files}):
        if modified_after is not None and path.stat().st_mtime < modified_after:
            continue
        unique.append(path)
    return unique


def write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with open(path, "w", encoding="utf-8") as file:
        json.dump(payload, file, indent=2)


def snapshot_phase_outputs(run_dir: Path, phase_name: str, modified_after: float) -> dict:
    phase_dir = run_dir / phase_name
    phase_dir.mkdir(parents=True, exist_ok=True)

    copied_files = []
    for source in collect_phase_files(PHASE_OUTPUT_PATTERNS[phase_name], modified_after=modified_after):
        target = phase_dir / source.name
        shutil.copy2(source, target)
        copied_files.append(str(target.relative_to(BASE_DIR)))

    manifest = {
        "phase": phase_name,
        "captured_at": datetime.now().isoformat(),
        "file_count": len(copied_files),
        "files": copied_files,
    }
    write_json(phase_dir / "artifact_manifest.json", manifest)
    print(f"[Artifacts] {phase_name}: {len(copied_files)} file(s) copied to {phase_dir}")
    return manifest


def run_full_pipeline() -> Path:
    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    ARTIFACTS_DIR.mkdir(parents=True, exist_ok=True)

    run_id = datetime.now().strftime("run_%Y%m%d_%H%M%S")
    run_dir = ARTIFACTS_DIR / run_id
    run_dir.mkdir(parents=True, exist_ok=True)

    manifest = {
        "run_id": run_id,
        "created_at": datetime.now().isoformat(),
        "phases": [],
    }

    phases = [
        ("phase0_chunking", generate_chunks_from_directory),
        ("phase1_extraction", run_phase1_pipeline),
        ("phase15_link_cleanup", run_phase15_pipeline),
        ("phase2_graph_build", run_phase2_pipeline),
        ("phase3_diagrams", run_phase3_pipeline),
    ]

    for phase_name, runner in phases:
        print(f"\n{'='*72}\n[Running] {phase_name}\n{'='*72}")
        phase_started_at = time.time()
        runner()
        manifest["phases"].append(snapshot_phase_outputs(run_dir, phase_name, modified_after=phase_started_at))

    write_json(run_dir / "run_manifest.json", manifest)
    print(f"\n[Completed] Full pipeline finished successfully")
    print(f"[Artifacts] {run_dir}")
    return run_dir


if __name__ == "__main__":
    run_full_pipeline()
