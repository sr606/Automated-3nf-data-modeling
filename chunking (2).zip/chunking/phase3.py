import os
import re
import json
from pathlib import Path
from enum import Enum
import httpx

from dotenv import load_dotenv
from pydantic import SecretStr
from langchain_openai import AzureChatOpenAI
from graphviz import Source

load_dotenv()

# ============================================
# CONFIG
# ============================================
OUTPUT_DIR = "data/output"

SYSTEM_PROMPT = """You are a Graphviz DOT code generator.
Your entire response must be valid Graphviz DOT code only.
No explanation. No markdown. No ```dot fences. No text outside the DOT code.
First line must start with: digraph"""


# ============================================
# DIAGRAM MODE
# ============================================
class DiagramMode(str, Enum):
    TECHNICAL = "technical"
    BUSINESS = "business"


# ============================================
# LLM SETUP
# ============================================
def get_llm() -> AzureChatOpenAI:
    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    deployment = os.getenv("AZURE_OPENAI_CHAT_DEPLOYMENT_NAME")
    api_key = os.getenv("AZURE_OPENAI_API_KEY")

    if not all([endpoint, deployment, api_key]):
        raise ValueError("Missing Azure OpenAI environment variables")

    return AzureChatOpenAI(
        azure_endpoint=endpoint,
        azure_deployment=deployment,
        api_key=SecretStr(api_key),
        api_version="2024-02-01",
        temperature=0.0,
        streaming=False,
        http_client=httpx.Client(
            timeout=httpx.Timeout(300.0, read=600.0)
        )
    )


# ============================================
# LOAD PHASE 2 OUTPUTS
# ============================================
def load_phase2_outputs(base_path: Path, stem: str) -> tuple[list, list, dict]:
    with open(base_path / f"{stem}_graph_nodes.json", "r", encoding="utf-8") as f:
        nodes = json.load(f)

    with open(base_path / f"{stem}_edges.json", "r", encoding="utf-8") as f:
        edges = json.load(f)

    metadata_path = base_path / f"{stem}_metadata_store.json"
    metadata = {}
    if metadata_path.exists():
        with open(metadata_path, "r", encoding="utf-8") as f:
            metadata = json.load(f)

    return nodes, edges, metadata


# ============================================
# SLIM METADATA
# Trim to what's useful per mode — keeps LLM context small
# ============================================
def prepare_slim_metadata(metadata: dict, mode: DiagramMode) -> dict:
    slim = {}

    for node_id, meta in metadata.items():
        entry = {}

        if meta.get("stage_type"):
            entry["stage_type"] = meta["stage_type"]

        if mode == DiagramMode.TECHNICAL:
            # Technical: include raw transformations + rules (first 2 each)
            txfms = meta.get("transformations", [])
            if txfms:
                entry["transformations"] = txfms[:2]

            rules = meta.get("business_rules", [])
            if rules:
                entry["business_rules"] = rules[:2]

        elif mode == DiagramMode.BUSINESS:
            # Business: only insights — skip technical/SQL-heavy content
            insights = meta.get("insights", [])
            if insights:
                entry["insights"] = insights[:1]  # max 1 insight for clean labels

            # Fallback: first business rule if no insights key
            if not insights:
                rules = meta.get("business_rules", [])
                if rules:
                    entry["business_rules"] = rules[:1]

        if entry:
            slim[node_id] = entry

    return slim


# ============================================
# TECHNICAL PROMPT
# Full lineage: raw IDs, stage types, technical labels
# ============================================
def build_technical_prompt(nodes: list, edges: list, metadata: dict) -> str:
    return f"""You are a data lineage diagram generator.
Generate Graphviz DOT code for a lineage diagram from the provided nodes, edges, and metadata.

---

NODE TYPES → VISUAL STYLE

source    → shape=folder,    fillcolor="#d5f5e3", style=filled
transform → shape=box,       fillcolor="#e8daef", style=filled
lookup    → shape=diamond,   fillcolor="#fdebd0", style=filled
target    → shape=cylinder,  fillcolor="#d6eaf8", style=filled

All nodes: fontname=Helvetica, fontsize=11

---

NODE LABEL

Line 1: node_id
Line 2: (stage_type) — only if present in metadata
Line 3–4: max 2 transformations from metadata — only if each fits in under 6 words
           skip if technical, SQL-like, or over 6 words

Format: "NodeID\\n(StageType)\\nshort rule"

---

EDGE RULES

- Use link_name as the edge label, fontsize=8
- If two edges share the same source AND target, merge into ONE edge:
  label = "link1 / link2"
- Main pipeline path (longest source-to-target chain): penwidth=2, color=black
- All other edges: penwidth=1, color="#555555"

---

LAYOUT

digraph DataLineage {{
  rankdir=LR
  splines=ortho
  nodesep=0.5
  ranksep=1.5
  fontname=Helvetica

  node [fontname=Helvetica fontsize=11 width=1.8]
  edge [fontname=Helvetica fontsize=8 color="#555555"]
}}

---

CLUSTERS

Group nodes by type. Label only — no fillcolor on the cluster itself.

  subgraph cluster_sources    {{ label="Sources"    ... }}
  subgraph cluster_lookups    {{ label="Lookups"    ... }}
  subgraph cluster_transforms {{ label="Transforms" ... }}
  subgraph cluster_targets    {{ label="Targets"    ... }}

---

RULES — never break these

1. Every input node appears in the graph exactly once
2. Every node referenced in edges must appear as a node — if missing from input, add as type transform
3. No duplicate edges — merge same source+target pairs into one edge
4. Never infer nodes or edges not in the input
5. Never dump raw metadata, SQL, or long field names into labels

---

nodes:
{json.dumps(nodes, indent=2)}

edges:
{json.dumps(edges, indent=2)}

metadata:
{json.dumps(metadata, indent=2)}
"""


# ============================================
# BUSINESS PROMPT
# Clean lineage: plain English, insights only, no IDs
# ============================================
def build_business_prompt(nodes: list, edges: list, metadata: dict) -> str:
    return f"""You are a data lineage diagram generator for business audiences.
Generate Graphviz DOT code that is clean, readable, and free of technical IDs.

---

NODE TYPES → VISUAL STYLE

source    → shape=folder,    fillcolor="#d5f5e3", style=filled
transform → shape=box,       fillcolor="#e8daef", style=filled
lookup    → shape=diamond,   fillcolor="#fdebd0", style=filled
target    → shape=cylinder,  fillcolor="#d6eaf8", style=filled

All nodes: fontname=Helvetica, fontsize=11

---

NODE LABEL RULES

Line 1: Readable name — strip technical prefixes (V0S, Trx, ORA_, HF_, Lnk_)
         e.g. "ORA_Ext_Vehicle_Off_Road_Data" → "Vehicle Off Road Data"
Line 2: Business role in plain English, max 5 words
         e.g. "CTransformerStage" → "Data transformer"
              "OracleConnector"   → "Oracle source"
              "SeqFileStage"      → "Exception file"
Line 3: ONE business insight from metadata — only if meaningful to a non-technical reader
         skip if it contains field names, SQL, keys, or acronyms unexplained

Total label: max 3 lines. Max 6 words per line. Cut ruthlessly.

Example:
  "Vehicle Off Road Data\\nOracle source\\nRegistration-based matching"

---

EDGE RULES

- Replace link_name with a plain English verb phrase, max 4 words
  e.g. "Lnk_Vehicle_off_Road_Data" → "feeds"
       "Load_HFVehicleoffRoad"     → "loads to warehouse"
       "lkVehicleDim_REg"          → "enriches with vehicle data"
- If two edges share the same source AND target, merge into ONE edge
  label = shortest meaningful phrase covering both
- fontsize=8
- Main pipeline path: penwidth=2, color=black
- All other edges: penwidth=1, color="#888888"

---

LAYOUT

digraph BusinessLineage {{
  rankdir=LR
  splines=ortho
  nodesep=0.5
  ranksep=1.8
  fontname=Helvetica

  node [fontname=Helvetica fontsize=11 width=2.0]
  edge [fontname=Helvetica fontsize=8 color="#888888"]
}}

---

CLUSTERS

subgraph cluster_sources    {{ label="Data Sources"   ... }}
subgraph cluster_lookups    {{ label="Reference Data" ... }}
subgraph cluster_transforms {{ label="Processing"     ... }}
subgraph cluster_targets    {{ label="Destinations"   ... }}

No fillcolor on cluster itself.

---

RULES — never break these

1. Every input node appears in the graph exactly once
2. Every node referenced in edges must appear as a node — if missing, add as type transform
3. No duplicate edges — merge same source+target pairs into one edge
4. Labels are plain English — no IDs, prefixes, field names, or SQL
5. Metadata is context, not display — use it only to derive a short insight
6. If no meaningful business insight exists for a node, use only 2 lines

---

nodes:
{json.dumps(nodes, indent=2)}

edges:
{json.dumps(edges, indent=2)}

metadata:
{json.dumps(metadata, indent=2)}
"""


# ============================================
# PROMPT ROUTER
# ============================================
def build_prompt(nodes: list, edges: list, metadata: dict, mode: DiagramMode) -> str:
    if mode == DiagramMode.TECHNICAL:
        return build_technical_prompt(nodes, edges, metadata)
    return build_business_prompt(nodes, edges, metadata)


# ============================================
# LLM CALL
# ============================================
def call_llm(prompt: str, llm: AzureChatOpenAI) -> str:
    response = llm.invoke([
        ("system", SYSTEM_PROMPT),
        ("human", prompt),
    ]).content.strip()

    # Strip markdown fences if model wraps output
    response = re.sub(r"```dot|```", "", response).strip()

    # Ensure starts at digraph
    start = response.find("digraph")
    if start != -1:
        response = response[start:]

    return response


# ============================================
# VALIDATE DOT
# ============================================
def validate_dot(dot_code: str) -> bool:
    if not dot_code.strip().startswith("digraph"):
        return False
    if "{" not in dot_code or "}" not in dot_code:
        return False
    return True


# ============================================
# RENDER DOT → PNG + SVG
# ============================================
def render_dot(dot_code: str, output_path: str) -> None:
    dot_file = f"{output_path}.dot"
    with open(dot_file, "w", encoding="utf-8") as f:
        f.write(dot_code)
    print(f"    DOT  → {dot_file}")

    try:
        src = Source(dot_code)
        src.render(output_path, format="png", cleanup=False)
        print(f"    PNG  → {output_path}.png")
        src.render(output_path, format="svg", cleanup=False)
        print(f"    SVG  → {output_path}.svg")
    except Exception as e:
        print(f"    [Render Error] {e}")


# ============================================
# GENERATE ONE DIAGRAM
# ============================================
def generate_diagram(
    nodes: list,
    edges: list,
    metadata: dict,
    llm: AzureChatOpenAI,
    output_path: str,
    mode: DiagramMode,
) -> bool:
    label = mode.value.upper()
    print(f"\n  [{label}] Generating DOT...")

    slim_metadata = prepare_slim_metadata(metadata, mode)
    prompt = build_prompt(nodes, edges, slim_metadata, mode)
    dot_code = call_llm(prompt, llm)

    if not validate_dot(dot_code):
        print(f"  [{label}] Invalid DOT output — skipping render")
        print(f"  Preview: {dot_code[:200]}")
        return False

    render_dot(dot_code, output_path)
    return True


# ============================================
# MAIN RUNNER
# ============================================
def run_phase3_pipeline() -> None:
    base_path = Path(OUTPUT_DIR)
    base_path.mkdir(parents=True, exist_ok=True)

    llm = get_llm()

    graph_files = list(base_path.glob("*_graph_nodes.json"))

    if not graph_files:
        print("[ERROR] No graph_nodes files found in", OUTPUT_DIR)
        return

    print(f"[Found] {len(graph_files)} graph(s)\n")

    for file in graph_files:
        stem = file.stem.replace("_graph_nodes", "")

        print(f"{'='*55}")
        print(f"  Graph: {stem}")
        print(f"{'='*55}")

        nodes, edges, metadata = load_phase2_outputs(base_path, stem)

        if not nodes:
            print(f"  [Skipped] No nodes found\n")
            continue

        if not edges:
            print(f"  [Warning] No edges — diagram will show isolated nodes")

        print(f"  Nodes : {len(nodes)}")
        print(f"  Edges : {len(edges)}")

        # --- Technical diagram ---
        technical_path = str(base_path / f"{stem}_lineage_technical")
        generate_diagram(nodes, edges, metadata, llm, technical_path, DiagramMode.TECHNICAL)

        # --- Business diagram ---
        business_path = str(base_path / f"{stem}_lineage_business")
        generate_diagram(nodes, edges, metadata, llm, business_path, DiagramMode.BUSINESS)

        print(f"\n  [Done] {stem}\n")


# ============================================
# ENTRY
# ============================================
if __name__ == "__main__":
    run_phase3_pipeline()
