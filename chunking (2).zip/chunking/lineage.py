import json
import re
from pathlib import Path

STOP_HEADERS = {
    "EXECUTION_FLOW:",
    "DATA_FLOW_SUMMARY:",
    "STAGES_SUMMARY:",
    "LINKS_SUMMARY:",
    "PARENT_CHILD_HIERARCHY:",
    "LINK_METADATA_STATUS:",
    "LINK_EXECUTION_MODES:",
    "LOOKUP_OPERATIONS:",
    "SORT_OPERATIONS:",
    "chunk pseudo code ended",
}


def is_stop_line(line: str) -> bool:
    return any(h in line for h in STOP_HEADERS)


def extract_stage_name(line: str):
    match = re.search(r"STAGE:\s*([^\(\n]+)", line)
    if match:
        return match.group(1).strip()
    return None


def build_chunks(text: str):
    lines = text.splitlines()
    node_map = {}
    current_stage = None
    buffer = []
    chunk_counter = 1

    def save_stage():
        nonlocal buffer, current_stage, chunk_counter

        if current_stage and buffer:
            node_map.setdefault(current_stage, []).append({
                "chunk_id": f"{current_stage}_{chunk_counter}",
                "content": "\n".join(buffer).strip()
            })

    for line in lines:
        stripped = line.strip()

        if is_stop_line(stripped):
            save_stage()
            current_stage = None
            buffer = []
            chunk_counter = 1
            continue

        if stripped.startswith("STAGE:"):
            save_stage()
            current_stage = extract_stage_name(stripped)
            buffer = [line]
            chunk_counter = 1
            continue

        if current_stage:
            buffer.append(line)

    save_stage()
    return node_map


def generate_chunks_from_directory(input_dir="data/input", output_dir="data/output"):
    input_path = Path(input_dir)
    output_path = Path(output_dir)
    output_path.mkdir(parents=True, exist_ok=True)

    for file in input_path.glob("*"):
        if file.is_file():
            print(f"\n📂 Processing: {file.name}")

            with open(file, "r", encoding="utf-8", errors="ignore") as f:
                content = f.read()

            chunks = build_chunks(content)
            stage_count = len(chunks)
            print(f"🧩 Extracted Stages: {stage_count}")

            if stage_count == 0:
                print("⚠️ WARNING: No stages found → using fallback chunk")
                chunks = {
                    "FULL_SCRIPT": [
                        {
                            "chunk_id": "FULL_SCRIPT_1",
                            "content": content.strip(),
                            "fallback": True
                        }
                    ]
                }

            output_file = output_path / f"{file.stem}_chunks.json"

            with open(output_file, "w", encoding="utf-8") as f:
                json.dump(chunks, f, indent=2, ensure_ascii=False)

            print(f"✅ Saved: {output_file}")

    print("\n🎯 Chunking completed successfully!")


if __name__ == "__main__":
    generate_chunks_from_directory()
