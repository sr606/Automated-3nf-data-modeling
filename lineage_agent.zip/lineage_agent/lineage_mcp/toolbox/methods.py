import os
import json
import uuid
import re
from collections import defaultdict
from pathlib import Path
from dotenv import load_dotenv
from sql_metadata import Parser

load_dotenv()

SERVICE_ROOT = Path(__file__).resolve().parents[1]


def resolve_project_path(path_value, default_relative_path):
    """
    Resolve env-configured paths relative to the lineage_mcp folder instead of cwd.
    """

    raw_path = path_value or default_relative_path
    path = Path(raw_path)

    if not path.is_absolute():
        path = SERVICE_ROOT / path

    return str(path.resolve())


UPLOAD_BASE_PATH = resolve_project_path(
    os.getenv("UPLOAD_BASE_PATH"),
    "data/uploads"
)
OUTPUT_BASE_PATH = resolve_project_path(
    os.getenv("OUTPUT_BASE_PATH"),
    "data/output"
)


"""
**************************************
Lineage Agent Helper Methods
**************************************
"""


# -----------------------------------------------------
# Utility
# -----------------------------------------------------

def write_json(path, data):
    """
    Write JSON safely while ensuring directory exists.
    """
    os.makedirs(os.path.dirname(path), exist_ok=True)

    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, indent=4)


def read_json(path):
    """
    Read JSON safely. Returns empty list if file not found.
    """
    if not path or not os.path.exists(path):
        return []

    with open(path, "r", encoding="utf-8") as f:
        return json.load(f)


# -----------------------------------------------------
# State Tracking
# -----------------------------------------------------

def save_lineage_state(session_id, state):
    """
    Save lineage pipeline state for debugging and recovery.

    State is merged with existing state instead of overwriting.
    """

    state_dir = os.path.join(
        OUTPUT_BASE_PATH,
        "lineage_state"
    )

    os.makedirs(state_dir, exist_ok=True)

    state_path = os.path.join(state_dir, f"{session_id}.json")

    existing = {}

    if os.path.exists(state_path):
        existing = read_json(state_path)

    existing.update(state)

    write_json(state_path, existing)


def load_lineage_state(session_id):
    """
    Load lineage state for a given session.
    """

    state_dir = os.path.join(
        OUTPUT_BASE_PATH,
        "lineage_state"
    )

    state_path = os.path.join(state_dir, f"{session_id}.json")

    if os.path.exists(state_path):
        return read_json(state_path)

    return {}


def get_previous_state(key):
    """
    Retrieve latest value for a specific key from lineage state files.
    Used by router when pipeline tools skip inputs.
    """

    state_dir = os.path.join(
        OUTPUT_BASE_PATH,
        "lineage_state"
    )

    if not os.path.exists(state_dir):
        return None

    files = sorted(os.listdir(state_dir), reverse=True)

    for f in files:

        state = read_json(os.path.join(state_dir, f))

        if key in state:
            return state[key]

    return None

    
# -----------------------------------------------------
# File Utilities
# -----------------------------------------------------
 
def get_or_create_file(agent_name: str, tool_name: str):
    """
    Create a log file for the tool if it doesn't exist.
 
    Returns the path to the log file.
    """
 
    log_dir = os.path.join(
        OUTPUT_BASE_PATH,
        "logs",
        agent_name
    )
 
    os.makedirs(log_dir, exist_ok=True)
 
    log_file = os.path.join(log_dir, f"{tool_name}.log")
 
    if not os.path.exists(log_file):
        with open(log_file, "w") as f:
            f.write("")
 
    return log_file
 
 
def list_files_in_directory(directory_path: str):
    """
    Safely list files in a directory.
 
    Returns only file names (not directories).
    """
 
    if not directory_path:
        return []
 
    if not os.path.exists(directory_path):
        return []
 
    files = []
 
    for f in os.listdir(directory_path):
 
        full_path = os.path.join(directory_path, f)
 
        if os.path.isfile(full_path):
            files.append(f)
 
    return files


def get_lineage_upload_dir(user_id: str, category: str) -> str:
    """
    Build a lineage upload directory for a user and category.
    """

    return os.path.join(UPLOAD_BASE_PATH, "lineage", user_id, category)


def get_lineage_output_dir(user_id: str, category: str) -> str:
    """
    Build a lineage output directory for a user and category.
    """

    return os.path.join(OUTPUT_BASE_PATH, "lineage", user_id, category)


def resolve_lineage_artifact(user_id: str, category: str, filename: str, base_type: str = "upload"):
    """
    Resolve a lineage artifact filename to an absolute path.
    """

    if not filename:
        return None

    if os.path.isabs(filename):
        return filename

    base_dir = (
        get_lineage_upload_dir(user_id, category)
        if base_type == "upload"
        else get_lineage_output_dir(user_id, category)
    )

    return os.path.join(base_dir, filename)

# -----------------------------------------------------
# Read ETL Sources
# -----------------------------------------------------

def read_etl_sources(job_files, output_path):
    """
    Read ETL pseudocode files and store contents into JSON.
    """

    contents = []

    for file in job_files:

        if not os.path.exists(file):
            continue

        with open(file, "r", encoding="utf-8") as f:

            contents.append({
                "file": os.path.basename(file),
                "content": f.read()
            })

    write_json(output_path, contents)

    return output_path


# -----------------------------------------------------
# Job Boundary Detection
# -----------------------------------------------------

def detect_job_boundaries(source_file, output_path):
    """
    Detect independent ETL pipelines inside pseudocode.
    """

    data = read_json(source_file)

    jobs = []

    for entry in data:

        text = entry.get("content", "")

        segments = re.split(r'//\s*=+', text)

        for seg in segments:

            if len(seg.strip()) > 50:
                jobs.append(seg.strip())

    write_json(output_path, jobs)

    return output_path


# -----------------------------------------------------
# Parse ETL Stages
# -----------------------------------------------------

def parse_stages_chunked(job_file, output_path):
    """
    Extract stage metadata from pseudocode jobs.
    """

    jobs = read_json(job_file)

    stages = []

    for job in jobs:

        stage_blocks = re.split(r'// --- \[', job)

        for block in stage_blocks:

            name_match = re.search(r':\s*(.*?)\]', block)

            if name_match:

                stage_name = name_match.group(1)

                inputs = re.findall(r'Input:\s*←\s*(\w+)', block)

                outputs = re.findall(r'Output:\s*→\s*(\w+)', block)

                sql = re.findall(r'SQL:\s*(.*?)Output:', block, re.S)

                stages.append({
                    "stage": stage_name,
                    "type": "TRANSFORM",
                    "inputs": inputs,
                    "outputs": outputs,
                    "sql": sql
                })

    write_json(output_path, stages)

    return output_path


# -----------------------------------------------------
# Dataset Link Extraction
# -----------------------------------------------------

def extract_dataset_links(parsed_stage_file, output_path):
    """
    Build dataset flow relationships between ETL stages.
    """

    stages = read_json(parsed_stage_file)

    edges = []

    for stage in stages:

        for inp in stage.get("inputs", []):

            edges.append({
                "source": inp,
                "target": stage["stage"]
            })

        for out in stage.get("outputs", []):

            edges.append({
                "source": stage["stage"],
                "target": out
            })

    write_json(output_path, edges)

    return output_path


# -----------------------------------------------------
# SQL Metadata Extraction
# -----------------------------------------------------

def extract_sql_metadata(parsed_stage_file, output_path):
    """
    Extract SQL tables using sql-metadata parser.
    """

    stages = read_json(parsed_stage_file)

    tables = []

    for stage in stages:

        for sql in stage.get("sql", []):

            try:

                parser = Parser(sql)

                for table in parser.tables:

                    tables.append({
                        "table": table,
                        "stage": stage["stage"]
                    })

            except Exception:
                continue

    write_json(output_path, tables)

    return output_path


# -----------------------------------------------------
# Normalize Lineage Graph
# -----------------------------------------------------

def normalize_lineage_graph(dataset_file, sql_file, output_path):
    """
    Convert raw dataset links and SQL tables into normalized graph.
    """

    edges = read_json(dataset_file)
    tables = read_json(sql_file)

    nodes = {}

    for e in edges:

        if e["source"] not in nodes:
            nodes[e["source"]] = "DATASET"

        if e["target"] not in nodes:
            nodes[e["target"]] = "TRANSFORM"

    for t in tables:

        nodes[t["table"]] = "SOURCE"

    normalized = {
        "nodes": [{"id": k, "type": v} for k, v in nodes.items()],
        "edges": edges
    }

    write_json(output_path, normalized)

    return output_path


# -----------------------------------------------------
# Build Lineage Graph
# -----------------------------------------------------

def build_lineage_graph_bottom_up(graph_file, output_path):
    """
    Build lineage graph paths from normalized graph.
    """

    graph = read_json(graph_file)

    edges = graph.get("edges", [])

    children = defaultdict(list)
    parents = defaultdict(list)

    for e in edges:

        children[e["source"]].append(e["target"])
        parents[e["target"]].append(e["source"])

    leaves = [n for n in children if n not in parents]

    paths = []

    def trace(node, path):

        if node not in parents:
            paths.append(path)
            return

        for p in parents[node]:
            trace(p, [p] + path)

    for leaf in leaves:
        trace(leaf, [leaf])

    lineage = {
        "paths": paths,
        "edges": edges,
        "nodes": graph.get("nodes", [])
    }

    write_json(output_path, lineage)

    return output_path


# -----------------------------------------------------
# Layout Generation
# -----------------------------------------------------

def generate_layout(graph_file, output_path):
    """
    Generate node layout coordinates for visualization.
    """

    graph = read_json(graph_file)

    nodes = graph.get("nodes", [])

    positions = {}

    layer_map = {
        "SOURCE": 0,
        "TRANSFORM": 1,
        "DATASET": 2,
        "TARGET": 3
    }

    layer_index = defaultdict(int)

    for node in nodes:

        layer = layer_map.get(node["type"], 1)

        x = layer * 300
        y = layer_index[layer] * 120

        positions[node["id"]] = {
            "x": x,
            "y": y
        }

        layer_index[layer] += 1

    layout = {
        "nodes": nodes,
        "positions": positions,
        "edges": graph.get("edges", [])
    }

    write_json(output_path, layout)

    return output_path


# -----------------------------------------------------
# Draw.io XML Generation
# -----------------------------------------------------

def generate_drawio_xml(layout_file):
    """
    Convert lineage layout JSON into draw.io XML format.
    """

    layout = read_json(layout_file)

    nodes = layout["nodes"]
    pos = layout["positions"]
    edges = layout["edges"]

    xml = []

    xml.append('<mxfile><diagram><mxGraphModel><root>')
    xml.append('<mxCell id="0"/><mxCell id="1" parent="0"/>')

    id_map = {}

    for i, node in enumerate(nodes):

        nid = str(i + 2)

        id_map[node["id"]] = nid

        p = pos[node["id"]]

        xml.append(
            f'<mxCell id="{nid}" value="{node["id"]}" vertex="1" parent="1">'
            f'<mxGeometry x="{p["x"]}" y="{p["y"]}" width="160" height="60" as="geometry"/>'
            '</mxCell>'
        )

    edge_id = len(nodes) + 2

    for e in edges:

        xml.append(
            f'<mxCell id="{edge_id}" edge="1" parent="1" source="{id_map.get(e["source"], "")}" '
            f'target="{id_map.get(e["target"], "")}">'
            '<mxGeometry relative="1" as="geometry"/>'
            '</mxCell>'
        )

        edge_id += 1

    xml.append('</root></mxGraphModel></diagram></mxfile>')

    return "\n".join(xml)


# -----------------------------------------------------
# Store XML
# -----------------------------------------------------

def store_lineage_xml(xml, directory, filename):
    """
    Store generated draw.io XML lineage diagram.
    """

    if filename is None:
        filename = f"lineage_{uuid.uuid4().hex}.drawio"

    os.makedirs(directory, exist_ok=True)

    path = os.path.join(directory, filename)

    with open(path, "w", encoding="utf-8") as f:
        f.write(xml)

    return path
