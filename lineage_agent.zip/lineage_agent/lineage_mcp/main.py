from fastapi import FastAPI
import uvicorn
from fastapi.middleware.cors import CORSMiddleware
from routers import lineage
from fastapi_mcp import FastApiMCP
from dotenv import load_dotenv
import os
import logging
from pathlib import Path
from datetime import datetime

load_dotenv()

SERVICE_ROOT = Path(__file__).resolve().parent
DATA_ROOT = str((SERVICE_ROOT / "data").resolve())
LOG_BASE_PATH = str((SERVICE_ROOT / "data" / "logs").resolve())
UPLOAD_BASE_PATH = str((SERVICE_ROOT / "data" / "uploads").resolve())
OUTPUT_BASE_PATH = str((SERVICE_ROOT / "data" / "output").resolve())

# --------------------------------------------------------
# Logging Setup
# --------------------------------------------------------

log_path = LOG_BASE_PATH
Path(log_path).mkdir(parents=True, exist_ok=True)

# Create log files
log_files = {
    "lineage_mcpserver": os.path.join(
        log_path,
        f"lineage_mcpserver_{datetime.now().strftime('%Y%m%d')}.log"
    ),
}


def setup_logger(logger_name, log_file, level=logging.INFO):
    """
    Setup individual logger with file handler and stream handler.
    """

    logger = logging.getLogger(logger_name)
    logger.setLevel(level)

    if logger.handlers:
        return logger

    formatter = logging.Formatter(
        '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
    )

    file_handler = logging.FileHandler(log_file)
    file_handler.setFormatter(formatter)

    stream_handler = logging.StreamHandler()
    stream_handler.setFormatter(formatter)

    logger.addHandler(file_handler)
    logger.addHandler(stream_handler)

    return logger


lineage_logger = setup_logger(
    "lineage_mcpserver",
    log_files["lineage_mcpserver"]
)

lineage_logger.info("Lineage logger initialized.")


# --------------------------------------------------------
# Environment Setup
# --------------------------------------------------------

Path(UPLOAD_BASE_PATH).mkdir(parents=True, exist_ok=True)
Path(OUTPUT_BASE_PATH).mkdir(parents=True, exist_ok=True)

os.makedirs(log_path, exist_ok=True)


# --------------------------------------------------------
# Shared CORS Configuration
# --------------------------------------------------------

def apply_cors(app: FastAPI):

    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )


# --------------------------------------------------------
# Sub-app Creator
# --------------------------------------------------------

def create_sub_app(title: str, description: str, version: str = "0.1.0") -> FastAPI:

    app = FastAPI(
        title=title,
        description=description,
        version=version
    )

    apply_cors(app)

    return app


# --------------------------------------------------------
# Main App
# --------------------------------------------------------

app = FastAPI()

apply_cors(app)


# --------------------------------------------------------
# Lineage Agent Sub App
# --------------------------------------------------------

data_lineage = create_sub_app(
    title="Data Lineage Generator",
    description="Lineage Agent that analyzes ETL pseudocode and generates data lineage diagrams in draw.io format.",
)

data_lineage.include_router(lineage.router)

FastApiMCP(
    data_lineage,
    include_operations=[
        "available_lineage_sources",
        "read_lineage_sources",
        "llm_extract_lineage_graph",
        "validate_lineage_graph",
        "repair_lineage_graph_if_needed",
        "extract_sql_metadata",
        "normalize_lineage_graph",
        "build_lineage_graph",
        "generate_layout",
        "generate_drawio_xml",
        "store_lineage_diagram",
    ]
).mount_http()

app.mount("/api/v1/lineage", data_lineage)

lineage_logger.info("Lineage API mounted at /api/v1/lineage")


# --------------------------------------------------------
# Run Server
# --------------------------------------------------------

if __name__ == "__main__":

    lineage_logger.info("Starting Lineage MCP Server on port 8100")

    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8100
    )
