from fastapi import FastAPI
from lineage_agent import graph
from langgraph.types import Command
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel
import uvicorn
import json


def _message_text(content):
    """
    Flatten LangChain message content into plain text for the chat client.
    """

    if isinstance(content, str):
        return content

    if isinstance(content, list):
        parts = []
        for item in content:
            if isinstance(item, str):
                parts.append(item)
            elif isinstance(item, dict):
                text = item.get("text") or item.get("content") or ""
                if text:
                    parts.append(str(text))
        return "\n".join(part for part in parts if part).strip()

    return str(content or "")


def _serialize_message(msg):
    """
    Return only user-facing message fields instead of raw LangChain metadata.
    """

    message_type = getattr(msg, "type", msg.__class__.__name__.lower())
    data = {
        "type": message_type,
        "content": _message_text(getattr(msg, "content", "")),
    }

    tool_calls = getattr(msg, "tool_calls", None)
    if tool_calls:
        data["tool_calls"] = [
            {
                "name": item.get("name", ""),
                "args": item.get("args", {}),
                "id": item.get("id", ""),
            }
            for item in tool_calls
        ]

    name = getattr(msg, "name", None)
    if name:
        data["name"] = name

    return data


# --------------------------------------------------------
# Stream generator for initial chat
# --------------------------------------------------------

async def stream(message, checkpoint_id):

    config = {
        "configurable": {"thread_id": checkpoint_id},
        "recursion_limit": 200
    }

    async for event in graph.astream(
        {"messages": [{"role": "user", "content": message}]},
        config
    ):
        for value in event.values():
            if isinstance(value, dict) and "messages" in value:
                msg = value["messages"][-1]
                data = {"message": _serialize_message(msg)}

                yield f"data: {json.dumps(data)}\n\n"

                tool_calls = data["message"].get("tool_calls", [])
                for tool_call in tool_calls:
                    if tool_call.get("name") == "human_assistance":
                        interrupt = {
                            "query": tool_call.get("args", {}).get("query", ""),
                            "id": tool_call.get("id", ""),
                            "session": checkpoint_id,
                        }
                        yield f"data: {json.dumps({'interrupt': interrupt})}\n\n"
                continue

            if not value:
                continue

            if isinstance(value, list) and hasattr(value[0], "value"):
                interrupt = {
                    "query": value[0].value["query"],
                    "id": value[0].id,
                    "session": checkpoint_id,
                }
                data = {"interrupt": interrupt}
                yield f"data: {json.dumps(data)}\n\n"


# --------------------------------------------------------
# Stream generator when resuming after interrupt
# --------------------------------------------------------

async def continue_chat_stream(message, checkpoint_id):

    config = {
        "configurable": {"thread_id": checkpoint_id}
    }

    async for event in graph.astream(
        Command(resume=message),
        config
    ):
        for value in event.values():
            if isinstance(value, dict) and "messages" in value:
                msg = value["messages"][-1]
                data = {"message": _serialize_message(msg)}

                yield f"data: {json.dumps(data)}\n\n"

                tool_calls = data["message"].get("tool_calls", [])
                for tool_call in tool_calls:
                    if tool_call.get("name") == "human_assistance":
                        interrupt = {
                            "query": tool_call.get("args", {}).get("query", ""),
                            "id": tool_call.get("id", ""),
                            "session": checkpoint_id,
                        }
                        yield f"data: {json.dumps({'interrupt': interrupt})}\n\n"
                continue

            if not value:
                continue

            if isinstance(value, list) and hasattr(value[0], "value"):
                interrupt = {
                    "query": value[0].value["query"],
                    "id": value[0].id,
                    "session": checkpoint_id,
                }
                data = {"interrupt": interrupt}
                yield f"data: {json.dumps(data)}\n\n"


# --------------------------------------------------------
# FastAPI App
# --------------------------------------------------------

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


# --------------------------------------------------------
# Request Model
# --------------------------------------------------------

class InputData(BaseModel):
    query: str
    thread_id: str


# --------------------------------------------------------
# Chat endpoint
# --------------------------------------------------------

@app.post("/chat")
async def chat_stream(input: InputData):

    return StreamingResponse(
        stream(
            message=input.query,
            checkpoint_id=input.thread_id
        ),
        media_type="text/event-stream"
    )


# --------------------------------------------------------
# Continue chat endpoint
# --------------------------------------------------------

@app.post("/continue_chat")
async def continue_chat(input: InputData):

    return StreamingResponse(
        continue_chat_stream(
            message=input.query,
            checkpoint_id=input.thread_id
        ),
        media_type="text/event-stream"
    )


# --------------------------------------------------------
# Run server
# --------------------------------------------------------

if __name__ == "__main__":

    uvicorn.run(
        app,
        host="0.0.0.0",
        port=8075
    )
