import asyncio
import httpx
import uuid
import json


async def stream_chat(query: str, thread_id: str, url: str):
    payload = {
        "query": query,
        "thread_id": thread_id
    }

    state = {"state": ""}

    async with httpx.AsyncClient(timeout=None) as client:

        async with client.stream("POST", url, json=payload) as response:

            async for line in response.aiter_lines():

                if line.startswith("data: "):
                    raw = line.removeprefix("data: ").strip()

                    try:
                        parsed = json.loads(raw)
                    except Exception:
                        yield raw
                        continue

                    if "interrupt" in parsed:
                        state["state"] = "interrupt"
                        state["content"] = parsed["interrupt"]
                        yield parsed
                        continue

                    if "message" in parsed:
                        yield parsed
                        continue

                    yield parsed

    yield state


async def main():

    session_ID = str(uuid.uuid4())

    state = {"state": ""}

    print("\nLineage Agent Client Started")
    print("Session ID:", session_ID)
    print("Type 'exit' to quit\n")

    while True:

        user_query = input("ask : ")

        if user_query.lower() == "exit":
            break

        # Decide which endpoint to call
        if state["state"] == "":
            url = "http://127.0.0.1:8075/chat"

            # Production examples
            # url = "https://your-lineage-agent/chat"
            # url = "http://your-load-balancer/chat"

        else:
            url = "http://127.0.0.1:8075/continue_chat"

        print("\nCalling:", url)
        print("State:", state["state"])
        print("--------------------------------------------------")

        async for resp in stream_chat(user_query, session_ID, url):
            if isinstance(resp, dict):
                print(json.dumps(resp, indent=2))
            else:
                print(resp)

            # Capture interrupt state
            if isinstance(resp, dict) and "state" in resp:
                state = resp
            elif isinstance(resp, dict) and "interrupt" in resp:
                state = {
                    "state": "interrupt",
                    "content": resp["interrupt"],
                }

        print("--------------------------------------------------\n")


# Run async main
if __name__ == "__main__":
    asyncio.run(main())
