import asyncio
import httpx
import uuid
import json


async def stream_chat(query: str, thread_id: str, url: str):
    payload = {
        "query": query,
        "thread_id": thread_id
    }

    state = {"state": ""}

    async with httpx.AsyncClient(timeout=None) as client:

        async with client.stream("POST", url, json=payload) as response:

            async for line in response.aiter_lines():

                if line.startswith("data: "):

                    message = line.removeprefix("data: ").strip()

                    # Handle normal message
                    if "message" in message:
                        try:
                            parsed = json.loads(message)
                            yield json.dumps(parsed, indent=2)
                        except:
                            yield message

                    # Handle interrupt state
                    if "interrupt" in message:
                        try:
                            parsed = json.loads(message)

                            state["state"] = "interrupt"
                            state["content"] = parsed

                        except:
                            yield message

    yield state


async def main():

    session_ID = str(uuid.uuid4())

    state = {"state": ""}

    print("\nLineage Agent Client Started")
    print("Session ID:", session_ID)
    print("Type 'exit' to quit\n")

    while True:

        user_query = input("ask : ")

        if user_query.lower() == "exit":
            break

        # Decide which endpoint to call
        if state["state"] == "":
            url = "http://127.0.0.1:8075/chat"

            # Production examples
            # url = "https://your-lineage-agent/chat"
            # url = "http://your-load-balancer/chat"

        else:
            url = "http://127.0.0.1:8075/continue_chat"

        print("\nCalling:", url)
        print("State:", state["state"])
        print("--------------------------------------------------")

        async for resp in stream_chat(user_query, session_ID, url):

            print(resp)

            # Capture interrupt state
            if isinstance(resp, dict) and "state" in resp:
                state = resp

        print("--------------------------------------------------\n")


# Run async main
if __name__ == "__main__":
    asyncio.run(main())