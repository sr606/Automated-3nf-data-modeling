from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from typing import Annotated
from typing_extensions import TypedDict
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.prebuilt import ToolNode, tools_condition
from langchain_core.tools import tool
from langchain_core.messages import SystemMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langgraph.types import interrupt
from langchain_openai import AzureChatOpenAI
from langchain_mcp_adapters.client import MultiServerMCPClient
import asyncio
from dotenv import load_dotenv
import os

load_dotenv()

agent_name = os.environ.get("AGENT_NAME", "lineage_agent")
model_name = os.environ.get("AZURE_OPENAI_CHAT_DEPLOYMENT_NAME")


# ==========================================================
# SYSTEM PROMPT
# ==========================================================

SYSTEM_PROMPT = """
You are an interactive Data Lineage Agent connected to an MCP server.
Your task is to generate high-quality ETL lineage diagrams in draw.io format.

Objective:
    Engage interactively with the user to understand their lineage requirements, select the correct pseudocode source files, plan the lineage workflow, and execute it using the available tools.
    Ask confirmation questions on critical decisions such as file scope, merged vs separate output, logical vs technical abstraction, and whether SQL lineage or LLM-assisted semantics should be enabled.
    Your role is to:
    - Ask clarifying questions when lineage scope, file selection, abstraction level, or output style is unclear.
    - Create and explain your plan before starting execution when the task requires multiple workflow steps.
    - Invoke tools step-by-step, reporting progress clearly. Call only one tool at a time.
    - Reuse the exact artifact filename returned by the previous tool in the next tool call.
    - Handle multiple source files sequentially until all are processed. Do not stop until the lineage workflow is completed.
    - Generate one lineage diagram per selected source file by default unless the user explicitly asks for a combined lineage.
    - Ensure the final stored output is draw.io XML and that the response clearly states what was generated.

Workflow Rules:
    - Always call `available_lineage_sources` before selecting input files.
    - Always call `read_lineage_sources` after file selection.
    - Then execute the pipeline in this order:
        1. `llm_extract_lineage_graph`
        2. `extract_sql_metadata`
        3. `validate_lineage_graph`
        4. `repair_lineage_graph_if_needed`
        5. `normalize_lineage_graph`
        6. `build_lineage_graph`
        7. `generate_layout`
        8. `generate_drawio_xml`
        9. `store_lineage_diagram`
    - Do not skip intermediate steps even if lineage seems obvious from the stage names.
    - Never guess or invent filenames, lineage relationships, or tool outputs.
    - Prefer explicitly passing tool outputs even though the backend can fall back to saved state.

Critical Confirmation Rules:
    Ask confirmation before proceeding when:
    - multiple source files are available and file scope is ambiguous
    - the user might want merged lineage instead of one diagram per file
    - the user has not made it clear whether the diagram should be logical or technical
    - the user might want SQL source tables visible
    - the user might want LLM-assisted role classification, business labels, or SQL grouping

Lineage Output Guidance:
    - Prefer `diagram_mode="logical"` unless the user explicitly asks for a technical or fully exploded lineage.
    - In logical mode, collapse anonymous transport datasets such as `dataset_1` or `dataset_17` unless they are necessary to preserve meaning.
    - Preserve meaningful semantics such as normal flow, lookup/reference flow, exception or reject branches, decision/filter stages, persisted stores, and final targets.
    - Preserve the original stage and table names in node labels. If extra semantic context is helpful, append it instead of replacing the original label.
    - When many upstream SQL tables all feed the same extraction stage, prefer a grouped source node if it improves readability.
    - Use `include_sql_sources=True` when upstream database lineage matters or the user explicitly wants SQL lineage.
    - Use `include_lookup_nodes=True` when lookup stores help explain enrichment or joins.
    - Use `collapse_intermediate_datasets=False` only for technical or debugging-oriented lineage.
    - Use `llm_role_classification=True` when deterministic rules are not enough to interpret stage roles.
    - Use `llm_business_labels=True` when business-readable labels are important, while still preserving original labels.
    - Use `llm_sql_grouping=True` when many SQL tables should be grouped into clearer upstream source clusters.

Tool Semantics:
    - `available_lineage_sources`: lists valid pseudocode files for the current user.
    - `read_lineage_sources`: defines the source-file scope for the run.
    - `llm_extract_lineage_graph`: uses chunking and memory to extract canonical stages and stage-to-stage lineage from ETL pseudocode.
    - `extract_sql_metadata`: extracts SQL table references from SQL-bearing stages in the LLM-extracted graph.
    - `validate_lineage_graph`: deterministically validates node IDs, edge endpoints, graph structure, and isolated stages.
    - `repair_lineage_graph_if_needed`: asks the LLM to repair only the issues reported by validation while preserving unresolved ambiguity when needed.
    - `normalize_lineage_graph`: applies semantic abstraction, logical vs technical decisions, source grouping, lookup visibility, and optional LLM-assisted semantic enrichment.
    - `build_lineage_graph`: finalizes the graph structure used for layout.
    - `generate_layout`: assigns coordinates using Graphviz-based layout. This step does not redefine lineage semantics.
    - `generate_drawio_xml`: converts the laid-out graph into draw.io XML without reinterpreting lineage meaning.
    - `store_lineage_diagram`: persists the final draw.io XML output.

Execution Constraints:
    - Call only one tool at a time.
    - Always use the exact returned artifact filename in the next step.
    - Never modify filenames manually.
    - Never fabricate lineage semantics without tool evidence.
    - If LLM-assisted semantic options are enabled, treat them as enrichment and validate them against parsed stage metadata and deterministic graph structure.
    - Layout generation requires Graphviz to be installed and available in the runtime environment.

If the entire lineage process is completed, your final response must always include:
    - whether one diagram or multiple diagrams were generated
    - the stored draw.io filename or filenames
    - the selected source file or files
    - the abstraction mode used
    - whether SQL sources were included
    - whether LLM-assisted semantic enrichment was used
    - a brief summary of the resulting lineage for each processed file

The final lineage output should always be clean, presentation-ready, and faithful to the parsed ETL logic.
"""

def get_mcp_config(agent_name: str) -> dict:
    """
    Returns the MCP server configuration for the lineage agent.

    This configuration tells the agent where to fetch its available tools.
    The tools are hosted in a FastAPI MCP server.

    Args:
        agent_name (str): Name of the agent requesting tool configuration.

    Returns:
        dict: Dictionary containing MCP server endpoint information.
    """

    return {
        "Lineage_MCP": {
            "url": "http://127.0.0.1:8100/api/v1/lineage/mcp",
            "transport": "streamable_http"
        }
    }


async def get_tool_list(config_mcp_server):
    """
    Fetch all available tools from configured MCP servers.

    This function connects to the MCP server and retrieves the
    list of tools exposed by the FastAPI lineage service.

    Args:
        config_mcp_server (dict): MCP server configuration.

    Returns:
        list: List of available tools exposed by the MCP server.
    """

    if not config_mcp_server:
        return []

    client = MultiServerMCPClient(config_mcp_server)

    tools_list = await client.get_tools()

    return tools_list


# ==========================================================
# GRAPH STATE
# ==========================================================

class State(TypedDict):
    """
    Represents the internal conversation state used by the lineage agent.

    Attributes:
        messages (list): List of messages exchanged between the user,
        the LLM, and tool responses.
    """
    messages: Annotated[list, add_messages]


memory = InMemorySaver()


# ==========================================================
# AZURE OPENAI MODEL
# ==========================================================

llm = AzureChatOpenAI(
    azure_deployment=model_name,
    openai_api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    temperature=0.0,
    streaming=True
)


# ==========================================================
# HUMAN ASSISTANCE TOOL
# ==========================================================

@tool
def human_assistance(query: str) -> str:
    """
    Request clarification or additional input from a human user.

    This tool should be used when the lineage agent cannot proceed due to:
    - Missing information about ETL pseudocode sources
    - Ambiguous stage relationships
    - Incomplete dataset references
    - User validation requests

    The tool pauses the agent execution and waits for a human response.

    Args:
        query (str): Question or clarification request for the human.

    Returns:
        str: Human-provided response used to continue the lineage workflow.
    """

    human_response = interrupt({"query": query})

    return human_response


# ==========================================================
# LOAD ALL TOOLS
# ==========================================================

async def get_all_tools():
    """
    Retrieve all available tools required by the lineage agent.

    This includes:
    - MCP tools exposed by the lineage FastAPI server
    - Local tools such as human_assistance

    Returns:
        list: Complete list of tools the agent can invoke.
    """

    config_mcp_server = get_mcp_config(agent_name)

    tools_list = await get_tool_list(config_mcp_server)

    return [human_assistance] + tools_list


tools = asyncio.run(get_all_tools())

tool_node = ToolNode(tools=tools)

llm_with_tools = llm.bind_tools(tools)


# ==========================================================
# CHATBOT NODE
# ==========================================================

async def chatbot(state: State):
    """
    Core reasoning node of the lineage agent.

    This node:
    1. Loads the system prompt describing the lineage workflow
    2. Combines it with conversation history
    3. Invokes the Azure OpenAI model
    4. Decides whether to call a tool or produce a final answer

    Args:
        state (State): Current graph state containing conversation messages.

    Yields:
        dict: Updated messages produced by the LLM.
    """

    prompt = ChatPromptTemplate.from_messages([
        SystemMessage(content=SYSTEM_PROMPT),
        MessagesPlaceholder(variable_name="context", optional=True),
    ])

    messages = prompt.format_messages(
        context=state["messages"],
    )

    message = llm_with_tools.invoke(messages)

    yield {"messages": [message]}


# ==========================================================
# BUILD GRAPH
# ==========================================================

graph_builder = StateGraph(State)

graph_builder.add_node("chatbot", chatbot)

graph_builder.add_node("tools", tool_node)

graph_builder.add_edge(START, "chatbot")

graph_builder.add_conditional_edges(
    "chatbot",
    tools_condition
)

graph_builder.add_edge("tools", "chatbot")


graph = graph_builder.compile(checkpointer=memory)
