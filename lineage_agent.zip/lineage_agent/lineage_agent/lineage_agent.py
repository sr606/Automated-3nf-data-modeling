from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from typing import Annotated
from typing_extensions import TypedDict
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.prebuilt import ToolNode, tools_condition
from langchain_core.tools import tool
from langchain_core.messages import SystemMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langgraph.types import interrupt
from langchain_openai import AzureChatOpenAI
from langchain_mcp_adapters.client import MultiServerMCPClient
import asyncio
from dotenv import load_dotenv
import os

load_dotenv()

agent_name = os.environ.get("AGENT_NAME", "lineage_agent")
model_name = os.environ.get("AZURE_OPENAI_CHAT_DEPLOYMENT_NAME")


# ==========================================================
# SYSTEM PROMPT
# ==========================================================

SYSTEM_PROMPT = """
You are an interactive Data Lineage Agent connected to an MCP server.

Your task is to generate ETL lineage diagrams that match the user's intended level of detail.

Objective:
Understand the user's lineage goal, select the right pseudocode inputs, run the lineage tools in order, and produce clean draw.io XML output.

Core behavior:

- Ask clarifying questions when lineage scope, file selection, or desired diagram style is unclear.
- Call tools one at a time and reuse each returned artifact filename in the next tool call.
- Do not guess or invent artifact filenames.
- Do not infer lineage relationships without tool outputs.
- Maintain progress transparency by stating which workflow step is being executed.
- Prefer backend tool outputs over conversational inference whenever a tool can answer the question.

Preferred output style:

- Prefer a clean logical lineage unless the user explicitly asks for a technical or fully exploded diagram.
- In logical mode, avoid surfacing anonymous transport nodes such as `dataset_1` or `dataset_17` unless they are the only reliable representation of lineage.
- Preserve important semantics such as normal flow, lookup/reference flow, exception/reject branches, and final target writes.
- Include SQL source tables as visible nodes only when the user asks for SQL-heavy or technical lineage, or when they are necessary to explain the flow.
- Treat layout cleanliness as important: the final diagram should look intentional, readable, and presentation-ready.
- When multiple source files are selected, generate a separate lineage diagram for each source file by default.
- Only generate one combined cross-file lineage if the user explicitly asks for a merged or consolidated diagram.

Tool semantics:

- `available_lineage_sources` lists valid pseudocode files for the current user. Always call this before choosing source files.
- `read_lineage_sources` defines the source-file scope for the run. The selected files become the basis for deterministic output naming and per-file diagram generation.
- `detect_job_boundaries` splits selected pseudocode into independent jobs or pipelines.
- `parse_etl_stages` extracts structured metadata such as stage names, types, inputs, outputs, and SQL blocks.
- `extract_dataset_links` resolves producer-consumer relationships between parsed stages. Use this after parsing; do not skip it even if stage names look obvious.
- `extract_sql_metadata` extracts database table references from SQL-bearing stages. Use it whenever SQL exists, even for logical diagrams, because SQL tables may become visible source nodes.
- `normalize_lineage_graph` is the main abstraction step. Use it to choose logical versus technical output and to decide whether transport datasets and lookup nodes should remain visible.
- `build_lineage_graph` produces the final graph structure used for layout. After this step, lineage semantics should already be decided for each selected source file.
- `generate_layout` assigns coordinates for visualization using deterministic graph layout. Do not expect this tool to reinterpret lineage meaning.
- `generate_drawio_xml` converts the laid-out graph into draw.io XML. It should not be treated as the step that decides lineage semantics from scratch.
- `store_lineage_diagram` writes the final XML. If multiple source files were selected, it stores one diagram per source file unless the user explicitly requested a combined result.

Workflow:

1. Discover available lineage sources.
2. Read the user-selected pseudocode files.
3. Detect ETL job boundaries.
4. Parse ETL stages.
5. Extract dataset links.
6. Extract SQL metadata.
7. Normalize the lineage graph using options that match the user's requested output style.
8. Build the lineage graph.
9. Generate the layout.
10. Generate draw.io XML.
11. Store the lineage diagram.

Multi-file behavior:

- If the user selected multiple input files, keep their lineage graphs separate by default.
- Apply parsing, normalization, layout, and rendering independently for each selected file unless the user explicitly requests a merged lineage.
- Expect the final storage step to return multiple diagram filenames when multiple files were selected.

Abstraction guidance:

- When the user wants a neat, clean, or business-readable lineage, prefer `diagram_mode="logical"`.
- In logical mode, prefer collapsing anonymous intermediate datasets.
- Keep lookup nodes visible when they help explain joins or enrichments.
- Keep exception or reject branches visible when they materially affect the pipeline.
- Prefer a single understandable graph over a technically exhaustive but noisy diagram.
- Use `include_sql_sources=True` when the graph would otherwise hide the true upstream origin of the data or when the user explicitly wants database lineage.
- Use `include_lookup_nodes=False` only when lookup stores are clutter and do not help explain the main transformation.
- Use `collapse_intermediate_datasets=False` only for technical or debugging-oriented outputs.
- For multiple files, apply the same abstraction policy consistently to each file unless the user requests different treatment.

Execution rules:

- Always call one tool at a time.
- Always use the previous tool's output as the next tool's input when available.
- Never modify returned filenames.
- Never infer or modify pseudocode filenames manually.
- Only use filenames exactly as returned by `available_lineage_sources`.
- Prefer explicitly passing tool outputs even though the backend can fall back to saved state.

Lineage graph requirements:

- Every meaningful ETL stage must be represented.
- Relationships must show data flow clearly.
- Inputs must point to processing stages.
- Processing stages must point to downstream stages or meaningful output datasets depending on the chosen abstraction level.
- The diagram should maintain left-to-right flow and avoid unnecessary clutter.

Error handling:

- If pseudocode parsing fails, ask the user for clarification.
- If stage relationships remain ambiguous after tool output, explain the ambiguity and request more context.
- If SQL metadata extraction fails, continue the lineage workflow unless SQL visibility is essential to the user's request.
- Do not fabricate lineage relationships.

Human interaction rules:

- Confirm file selection when needed.
- Ask follow-up questions when multiple output styles are possible and the user's preference is not clear.
- If the user asks for regeneration, reuse the same selected files and options unless the user changes scope.
- If only one reasonable source file exists and the user asks to generate lineage, you may proceed after briefly stating the selected file.

Final response requirements:

- Confirm whether one diagram or multiple diagrams were generated.
- Confirm that the draw.io XML output was stored successfully.
- If multiple files were processed, list the stored diagram filenames and summarize results per file.
- Summarize the result with counts of ETL stages, datasets, SQL source tables if included, and lineage relationships.
"""

def get_mcp_config(agent_name: str) -> dict:
    """
    Returns the MCP server configuration for the lineage agent.

    This configuration tells the agent where to fetch its available tools.
    The tools are hosted in a FastAPI MCP server.

    Args:
        agent_name (str): Name of the agent requesting tool configuration.

    Returns:
        dict: Dictionary containing MCP server endpoint information.
    """

    return {
        "Lineage_MCP": {
            "url": "http://0.0.0.0:8100/api/v1/lineage/mcp",
            "transport": "streamable_http"
        }
    }


async def get_tool_list(config_mcp_server):
    """
    Fetch all available tools from configured MCP servers.

    This function connects to the MCP server and retrieves the
    list of tools exposed by the FastAPI lineage service.

    Args:
        config_mcp_server (dict): MCP server configuration.

    Returns:
        list: List of available tools exposed by the MCP server.
    """

    if not config_mcp_server:
        return []

    client = MultiServerMCPClient(config_mcp_server)

    tools_list = await client.get_tools()

    return tools_list


# ==========================================================
# GRAPH STATE
# ==========================================================

class State(TypedDict):
    """
    Represents the internal conversation state used by the lineage agent.

    Attributes:
        messages (list): List of messages exchanged between the user,
        the LLM, and tool responses.
    """
    messages: Annotated[list, add_messages]


memory = InMemorySaver()


# ==========================================================
# AZURE OPENAI MODEL
# ==========================================================

llm = AzureChatOpenAI(
    azure_deployment=model_name,
    openai_api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    temperature=0.0,
    streaming=True
)


# ==========================================================
# HUMAN ASSISTANCE TOOL
# ==========================================================

@tool
def human_assistance(query: str) -> str:
    """
    Request clarification or additional input from a human user.

    This tool should be used when the lineage agent cannot proceed due to:
    - Missing information about ETL pseudocode sources
    - Ambiguous stage relationships
    - Incomplete dataset references
    - User validation requests

    The tool pauses the agent execution and waits for a human response.

    Args:
        query (str): Question or clarification request for the human.

    Returns:
        str: Human-provided response used to continue the lineage workflow.
    """

    human_response = interrupt({"query": query})

    return human_response


# ==========================================================
# LOAD ALL TOOLS
# ==========================================================

async def get_all_tools():
    """
    Retrieve all available tools required by the lineage agent.

    This includes:
    - MCP tools exposed by the lineage FastAPI server
    - Local tools such as human_assistance

    Returns:
        list: Complete list of tools the agent can invoke.
    """

    config_mcp_server = get_mcp_config(agent_name)

    tools_list = await get_tool_list(config_mcp_server)

    return [human_assistance] + tools_list


tools = asyncio.run(get_all_tools())

tool_node = ToolNode(tools=tools)

llm_with_tools = llm.bind_tools(tools)


# ==========================================================
# CHATBOT NODE
# ==========================================================

async def chatbot(state: State):
    """
    Core reasoning node of the lineage agent.

    This node:
    1. Loads the system prompt describing the lineage workflow
    2. Combines it with conversation history
    3. Invokes the Azure OpenAI model
    4. Decides whether to call a tool or produce a final answer

    Args:
        state (State): Current graph state containing conversation messages.

    Yields:
        dict: Updated messages produced by the LLM.
    """

    prompt = ChatPromptTemplate.from_messages([
        SystemMessage(content=SYSTEM_PROMPT),
        MessagesPlaceholder(variable_name="context", optional=True),
    ])

    messages = prompt.format_messages(
        context=state["messages"],
    )

    message = llm_with_tools.invoke(messages)

    yield {"messages": [message]}


# ==========================================================
# BUILD GRAPH
# ==========================================================

graph_builder = StateGraph(State)

graph_builder.add_node("chatbot", chatbot)

graph_builder.add_node("tools", tool_node)

graph_builder.add_edge(START, "chatbot")

graph_builder.add_conditional_edges(
    "chatbot",
    tools_condition
)

graph_builder.add_edge("tools", "chatbot")

graph_builder.add_edge("chatbot", END)


graph = graph_builder.compile(checkpointer=memory)
