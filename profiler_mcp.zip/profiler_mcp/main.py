from fastapi import FastAPI
import uvicorn
from fastapi.middleware.cors import CORSMiddleware
import os
from routers import profiler
from fastapi_mcp import FastApiMCP
from dotenv import load_dotenv
import sqlite3

load_dotenv()

# Shared CORS config
def apply_cors(app: FastAPI):
    app.add_middleware(
        CORSMiddleware,
        allow_origins=["*"],
        allow_methods=["*"],
        allow_headers=["*"],
    )

# Agent-specific sub-apps
def create_sub_app(title: str, description: str, version: str = "0.1.0") -> FastAPI:
    app = FastAPI(title=title, description=description, version=version)
    apply_cors(app)
    return app

# Main app
app = FastAPI()
apply_cors(app)

data_profiler = create_sub_app(
    title="Data Profiler",
    description="Data Profile tool that analyzes database data and creates the data profile report.",
)

data_profiler.include_router(profiler.router)
FastApiMCP(data_profiler, include_operations=["get_database_table_metadata", "get_profiling_table_names_list", "get_table_metadata", "execute_profiling_queries"]).mount_http()
app.mount("/api/v1/profile_data", data_profiler)


if __name__ == "__main__":
    uvicorn.run(app, host="0.0.0.0", port=8031)

