import uuid
import networkx as nx


def layered_layout(G):

    pos = {}

    try:
        layers = list(nx.topological_generations(G))
    except:
        layers = [list(G.nodes)]

    x_gap = 350
    y_gap = 140

    for i, layer in enumerate(layers):

        for j, node in enumerate(layer):

            pos[node] = (i * x_gap, j * y_gap)

    return pos


def node_style(node):

    t = node.get("type")

    if t == "stage":
        return "rounded=1;whiteSpace=wrap;html=1;fillColor=#dae8fc"

    if t == "dataset":
        return "rounded=1;whiteSpace=wrap;html=1;fillColor=#fff2cc"

    return "rounded=1;whiteSpace=wrap;html=1"


def generate_drawio(nodes, edges):

    print("\n[TOOL] generate_drawio running")

    G = nx.DiGraph()

    for n in nodes:
        G.add_node(n["name"])

    for e in edges:
        G.add_edge(e["source"], e["target"])

    pos = layered_layout(G)

    node_ids = {}

    xml = []

    xml.append("<mxfile><diagram><mxGraphModel><root>")
    xml.append('<mxCell id="0"/><mxCell id="1" parent="0"/>')

    for node in nodes:

        nid = str(uuid.uuid4())
        node_ids[node["name"]] = nid

        x, y = pos[node["name"]]

        style = node_style(node)

        xml.append(
            f'<mxCell id="{nid}" value="{node["name"]}" '
            f'style="{style}" vertex="1" parent="1">'
            f'<mxGeometry x="{x}" y="{y}" width="220" height="80" as="geometry"/>'
            '</mxCell>'
        )

    for e in edges:

        xml.append(
            f'<mxCell edge="1" parent="1" '
            f'source="{node_ids[e["source"]]}" '
            f'target="{node_ids[e["target"]]}" '
            f'value="{e["label"]}">'
            '<mxGeometry relative="1" as="geometry"/>'
            '</mxCell>'
        )

    xml.append("</root></mxGraphModel></diagram></mxfile>")

    print("[TOOL] Drawio XML generated")

    return "\n".join(xml)