import os

import re
 
 
# ------------------------------------------------

# Read ETL file

# ------------------------------------------------
 
def read_etl_file(path):
 
    with open(path, "r", encoding="utf-8") as f:

        return f.read()
 
 
# ------------------------------------------------

# List upload files

# ------------------------------------------------
 
def list_upload_files():
 
    folder = "./lineage_mcp/data/upload"
 
    files = [

        f for f in os.listdir(folder)

        if f.endswith(".txt")

    ]
 
    return files
 
 
# ------------------------------------------------

# Stage splitter

# ------------------------------------------------
 
def smart_stage_splitter(text):
 
    print("\n[TOOL] smart_stage_splitter")
 
    pattern = r"--- \[.*?\]"

    matches = list(re.finditer(pattern, text))
 
    blocks = []
 
    for i, m in enumerate(matches):
 
        start = m.start()

        end = matches[i + 1].start() if i + 1 < len(matches) else len(text)
 
        blocks.append(text[start:end])
 
    print(f"[TOOL] Total stage blocks detected: {len(blocks)}")
 
    return blocks
 
 
# ------------------------------------------------

# Logical chunking (LLM safe)

# ------------------------------------------------
 
def logical_chunk_stage(block, max_chars=3000):
 
    sections = re.split(

        r"(SQL:|Stage Variables:|Transformations:|Constraint)",

        block

    )
 
    chunks = []

    current = ""
 
    for part in sections:
 
        if len(current) + len(part) < max_chars:

            current += part

        else:

            chunks.append(current)

            current = part
 
    if current:

        chunks.append(current)
 
    return chunks
 
 
# ------------------------------------------------

# Deterministic graph builder

# ------------------------------------------------
 
def lineage_graph_builder(metadata):
 
    print("\n[TOOL] lineage_graph_builder")
 
    nodes = []

    edges = []

    seen = set()
 
    for item in metadata:
 
        stage = item["stage"]

        inputs = item["inputs"]

        outputs = item["outputs"]
 
        if stage not in seen:

            nodes.append({"name": stage, "type": "stage"})

            seen.add(stage)
 
        for inp in inputs:
 
            if inp not in seen:

                nodes.append({"name": inp, "type": "dataset"})

                seen.add(inp)
 
            edges.append({

                "source": inp,

                "target": stage,

                "label": "input"

            })
 
        for out in outputs:
 
            if out not in seen:

                nodes.append({"name": out, "type": "dataset"})

                seen.add(out)
 
            edges.append({

                "source": stage,

                "target": out,

                "label": "output"

            })
 
    print("[TOOL] Nodes:", nodes)

    print("[TOOL] Edges:", edges)
 
    return nodes, edges

import networkx as nx
 
 
def correct_lineage_graph(nodes, edges):
 
    print("\n[GRAPH] Running graph correction layer")
 
    G = nx.DiGraph()
 
    for n in nodes:
        G.add_node(n["name"])
 
    for e in edges:
 
        src = e["source"]
        tgt = e["target"]
 
        if src == tgt:
            continue
 
        G.add_edge(src, tgt)
 
    # Remove cycles
    try:
 
        cycles = list(nx.simple_cycles(G))
 
        for cycle in cycles:
 
            print("[GRAPH] Cycle detected:", cycle)
 
            G.remove_edge(cycle[-1], cycle[0])
 
    except:
        pass
 
    corrected_edges = []
 
    for u, v in G.edges():
 
        corrected_edges.append({
            "source": u,
            "target": v,
            "label": "flow"
        })
 
    corrected_nodes = [{"name": n} for n in G.nodes()]
 
    print("[GRAPH] Graph correction complete")
 
    return corrected_nodes, corrected_edges