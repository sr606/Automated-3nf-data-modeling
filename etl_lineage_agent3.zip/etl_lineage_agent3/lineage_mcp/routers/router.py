from fastapi import APIRouter
from pydantic import BaseModel, Field
from lineage_mcp.tools import helpers
from lineage_mcp.tools import diagram_generator
import os
 
router = APIRouter()
 
 
class ReadETLFile(BaseModel):
 
    file_name: str = Field(..., description="ETL pseudocode file name")
 
 
@router.post("/read_etl_file")
 
async def read_etl_file(p_body: ReadETLFile):
 
    path = f"./lineage_mcp/data/upload/{p_body.file_name}"
 
    text = helpers.read_etl_file(path)
 
    return {"etl_code": text}
 
 
class ExtractSemantics(BaseModel):
 
    block_text: str = Field(..., description="ETL stage block text")
 
 
@router.post("/extract_lineage_semantics")
 
async def extract_lineage_semantics(p_body: ExtractSemantics):
 
    semantics = helpers.extract_lineage_semantics(p_body.block_text)
 
    return semantics
 
 
class GenerateDiagram(BaseModel):
 
    nodes: list
    edges: list
 
 
@router.post("/generate_drawio")
 
async def generate_drawio(p_body: GenerateDiagram):
 
    xml = diagram_generator.generate_drawio(
        p_body.nodes,
        p_body.edges
    )
 
    output_file = "./lineage_mcp/data/feature/lineage.drawio"
 
    with open(output_file, "w", encoding="utf-8") as f:
        f.write(xml)
 
    return {"diagram_file": output_file}