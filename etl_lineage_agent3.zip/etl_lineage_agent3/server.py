from mcp.server.fastmcp import FastMCP
 
from lineage_mcp.tools.helpers import (
    read_etl_file,
    smart_stage_splitter,
    lineage_graph_builder,
    correct_lineage_graph
)
 
from lineage_mcp.tools.diagram_generator import generate_drawio
 
 
mcp = FastMCP("etl-lineage-server")
 
 
# ------------------------------------------------
# Read ETL file
# ------------------------------------------------
 
@mcp.tool()
def read_etl_file_tool(file_name: str):
 
    print("\n[TOOL] read_etl_file_tool:", file_name)
 
    path = f"./lineage_mcp/data/upload/{file_name}"
 
    text = read_etl_file(path)
 
    print("[TOOL] File loaded")
 
    return text
 
 
# ------------------------------------------------
# Split stages
# ------------------------------------------------
 
@mcp.tool()
def smart_stage_splitter_tool(text: str):
 
    blocks = smart_stage_splitter(text)
 
    return blocks
 
 
# ------------------------------------------------
# Build graph
# ------------------------------------------------
 
@mcp.tool()
def lineage_graph_builder_tool(metadata: list):
 
    nodes, edges = lineage_graph_builder(metadata)

    nodes, edges = correct_lineage_graph(nodes, edges)
 
    return {
        "nodes": nodes,
        "edges": edges
    }
 
 
# ------------------------------------------------
# Generate drawio
# ------------------------------------------------
 
@mcp.tool()
def generate_drawio_tool(nodes: list, edges: list, file_name: str):
 
    xml = generate_drawio(nodes, edges)
 
    path = f"./lineage_mcp/data/feature/{file_name}.drawio"
 
    with open(path, "w") as f:
        f.write(xml)
 
    print("[TOOL] Diagram saved:", path)
 
    return {"diagram": path}
 
 
# ------------------------------------------------
# Streamable HTTP MCP
# ------------------------------------------------
 
app = mcp.streamable_http_app()