import asyncio
from agent_template.lineage_engine import build_agent


async def run():

    graph = await build_agent()

    config = {
        "configurable": {"thread_id": "etl-session"}
    }

    print("ETL Lineage Agent Ready")

    while True:

        user = input("Enter command: ")

        events = graph.astream(
            {"messages": [("user", user)]},
            config=config
        )

        async for event in events:

            for v in event.values():

                if "messages" in v:
                    print("\nAgent:", v["messages"][-1].content)


if __name__ == "__main__":
    asyncio.run(run())