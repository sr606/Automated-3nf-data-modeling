import os

import re

import json
 
from dotenv import load_dotenv
 
from typing import Annotated

from typing_extensions import TypedDict
 
from langgraph.graph import StateGraph, START, END

from langgraph.graph.message import add_messages

from langgraph.checkpoint.memory import InMemorySaver
 
from langchain_openai import AzureChatOpenAI

from langchain_core.messages import SystemMessage, HumanMessage
 
from langchain_mcp_adapters.client import MultiServerMCPClient
 
from lineage_mcp.tools.helpers import (

    logical_chunk_stage,

    list_upload_files

)
 
 
load_dotenv()
 
 
# ------------------------------------------------

# LLM

# ------------------------------------------------
 
llm = AzureChatOpenAI(

    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),

    api_key=os.getenv("AZURE_OPENAI_API_KEY"),

    azure_deployment=os.getenv("AZURE_DEPLOYMENT"),

    api_version=os.getenv("AZURE_OPENAI_API_VERSION"),

    temperature=0

)
 
 
# ------------------------------------------------

# Graph state

# ------------------------------------------------
 
class State(TypedDict):

    messages: Annotated[list, add_messages]
 
 
memory = InMemorySaver()
 
 
# ------------------------------------------------

# MCP tools

# ------------------------------------------------
 
async def get_tools():
 
    client = MultiServerMCPClient(

        {

            "lineage_server": {

                "transport": "streamable_http",

                "url": "http://localhost:8002/mcp"

            }

        }

    )
 
    tools = await client.get_tools()
 
    return tools
 
 
# ------------------------------------------------

# Safe tool output parser

# ------------------------------------------------
 
def unwrap_tool_output(result):
 
    if isinstance(result, list):
 
        if len(result) > 0 and isinstance(result[0], dict):
 
            if "text" in result[0]:
 
                return result[0]["text"]
 
    return result
 
 
# ------------------------------------------------

# Safe JSON parser

# ------------------------------------------------
 
def safe_json_parse(text):
 
    text = text.strip()
 
    if text.startswith("```"):

        text = text.split("```")[1]
 
    return json.loads(text)
 
 
# ------------------------------------------------

# LLM prompt

# ------------------------------------------------
 
SYSTEM_PROMPT = """

You are an ETL lineage metadata extraction agent.
 
Your task is to extract stage metadata from ETL pseudocode blocks.
 
The input will be a single ETL stage block.
 
Extract the following fields:
 
• stage name
• stage type
• input datasets
• output datasets
 
--------------------------------------------------
 
Extraction Rules
 
1. Only extract information that explicitly exists in the text.
2. Never hallucinate datasets.
3. Do not infer lineage relationships.
4. Ignore link names.
5. Extract dataset names inside parentheses.
6. If no inputs or outputs exist return empty arrays.
7. If multiple inputs or outputs exist return them as arrays.
 
--------------------------------------------------
 
Stage Name
 
Extract the stage name from patterns such as:
 
[CUSTOMSTAGE : StageName]
[TRANSFORMERSTAGE : StageName]
[HASHEDFILESTAGE : StageName]
[SEQFILESTAGE : StageName]
 
Example:
 
[CUSTOMSTAGE : ORA_Ext_Vehicle_Off_Road_Data]
 
stage = ORA_Ext_Vehicle_Off_Road_Data
 
--------------------------------------------------
 
Stage Type
 
If a line contains:
 
StageType: OracleConnector
 
Then:
 
stage_type = OracleConnector
 
--------------------------------------------------
 
Inputs
 
Look for lines beginning with:
 
Input:
Source:
From:
 
Extract dataset names inside parentheses.
 
Example:
 
Input: ← dataset_5 (HF_SMR_VEHICLE_DIM)
 
Extract:
 
HF_SMR_VEHICLE_DIM
 
--------------------------------------------------
 
Outputs
 
Look for lines beginning with:
 
Output:
Target:
Write:
 
Extract dataset names inside parentheses.
 
Example:
 
Output: → dataset_4 (Tfm_LoadRecords)
 
Extract:
 
Tfm_LoadRecords
 
--------------------------------------------------
 
Return raw JSON only.
 
Do not include explanations or markdown.
 
JSON Schema
 
{
"stage": "",
"stage_type": "",
"inputs": [],
"outputs": []
}
"""
 
 
# ------------------------------------------------

# Build agent

# ------------------------------------------------
 
async def build_agent():
 
    tools = await get_tools()
    tool_map = {t.name: t for t in tools}
    read_tool = tool_map["read_etl_file_tool"]
    split_tool = tool_map["smart_stage_splitter_tool"]
    graph_tool = tool_map["lineage_graph_builder_tool"]
    draw_tool = tool_map["generate_drawio_tool"]
 
 
    async def workflow(state: State):
 
        user_input = state["messages"][-1].content
        print("\n[AGENT] Request:", user_input)
 
 
        # ------------------------------------------------

        # Detect files

        # ------------------------------------------------
 
        if "upload folder" in user_input.lower():
            files = list_upload_files()
 
        else:
 
            match = re.search(r'for\s+(.+\.txt)', user_input)
            if not match:
                raise ValueError("File name not detected")
            files = [match.group(1)]
        print("[AGENT] Files:", files)
 
 
        # ------------------------------------------------

        # Process files

        # ------------------------------------------------
 
        for file_name in files:
            print("\n[AGENT] Processing:", file_name)
            file_resp = await read_tool.ainvoke({
                "file_name": file_name
            })
 
            text = unwrap_tool_output(file_resp)
            split_resp = await split_tool.ainvoke({
                "text": text
            })
 
            blocks = unwrap_tool_output(split_resp)
            metadata = []
 
 
            # ------------------------------------------------

            # Process blocks

            # ------------------------------------------------
 
            for block in blocks:
                chunks = logical_chunk_stage(block)
                stage_header = block.split("\n")[0]
                combined = None
                for chunk in chunks:
                    chunk_input = stage_header + "\n" + chunk
                    messages = [
                    SystemMessage(content=SYSTEM_PROMPT),
                    HumanMessage(content=chunk_input)
                    ]
 
                    response = await llm.ainvoke(messages)
 
                    data = safe_json_parse(response.content)
 
                    print("[LLM]", data)
 
                    if not data["stage"]:
                        continue
 
                    if not combined:
                        combined = data
                    else:
                        combined["inputs"].extend(data["inputs"])
                        combined["outputs"].extend(data["outputs"])
 
                if combined:
                    metadata.append(combined)
 
 
            graph = await graph_tool.ainvoke({
                "metadata": metadata
            })
 
            graph = unwrap_tool_output(graph)
            nodes = graph["nodes"]
            edges = graph["edges"]
 
 
            await draw_tool.ainvoke({
                "nodes": nodes,
                "edges": edges,
                "file_name": file_name.replace(".txt", "")

            })
 
 
        return {
            "messages": [
                HumanMessage(content="Lineage generation complete.")
            ]

        }
 
 
    builder = StateGraph(State)
    builder.add_node("workflow", workflow)
    builder.add_edge(START, "workflow")
    builder.add_edge("workflow", END)
    graph = builder.compile(checkpointer=memory)
    
    return graph
 
 