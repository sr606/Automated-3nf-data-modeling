import uuid
import os
from typing import Dict
from pydantic import BaseModel

OUTPUT_DIR = "data/feature"


class DrawIORequest(BaseModel):
    nodes: list
    edges: list
    file_name: str


def create_drawio_diagram(nodes, edges, file_name):

    node_ids = {}
    xml = []

    xml.append("<mxfile>")
    xml.append("<diagram>")
    xml.append("<mxGraphModel>")
    xml.append("<root>")
    xml.append('<mxCell id="0"/>')
    xml.append('<mxCell id="1" parent="0"/>')

    for node in nodes:

        node_id = str(uuid.uuid4())
        node_ids[node["id"]] = node_id

        cell = f"""
        <mxCell id="{node_id}" value="{node['id']}"
        style="rounded=1;whiteSpace=wrap;html=1;"
        vertex="1" parent="1">
        <mxGeometry x="{node['x']}" y="{node['y']}"
        width="140" height="60" as="geometry"/>
        </mxCell>
        """

        xml.append(cell)

    for src, dst in edges:

        edge_id = str(uuid.uuid4())

        edge = f"""
        <mxCell id="{edge_id}" edge="1" parent="1"
        source="{node_ids[src]}" target="{node_ids[dst]}">
        <mxGeometry relative="1" as="geometry"/>
        </mxCell>
        """

        xml.append(edge)

    xml.append("</root>")
    xml.append("</mxGraphModel>")
    xml.append("</diagram>")
    xml.append("</mxfile>")

    output_path = os.path.join(OUTPUT_DIR, file_name)

    with open(output_path, "w") as f:
        f.write("\n".join(xml))

    return output_path