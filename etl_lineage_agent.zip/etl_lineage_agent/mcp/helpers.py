import os
import re
from typing import List, Tuple
from pydantic import BaseModel
 
UPLOAD_DIR = os.getenv("UPLOAD_DIR", "data/upload")
 
 
# ----------------------------
# Models
# ----------------------------
 
class LineageGraph(BaseModel):
    nodes: List[str]
    edges: List[Tuple[str, str]]
 
 
class LayoutNode(BaseModel):
    id: str
    x: int
    y: int
 
 
class LayoutGraph(BaseModel):
    nodes: List[LayoutNode]
    edges: List[Tuple[str, str]]
 
 
# ----------------------------
# File Operations
# ----------------------------
 
def list_files():
 
    return os.listdir(UPLOAD_DIR)
 
 
def read_file(file_name: str):
 
    path = os.path.join(UPLOAD_DIR, file_name)
 
    with open(path, "r") as f:
        return f.read()
 
 
# ----------------------------
# Chunking
# ----------------------------
 
def chunk_text(text: str, chunk_size: int = 2000, overlap: int = 200):
 
    chunks = []
    start = 0
 
    while start < len(text):
 
        end = start + chunk_size
 
        chunks.append(text[start:end])
 
        start = end - overlap
 
    return chunks
 
 
# ----------------------------
# Parsing pseudocode
# (basic deterministic version)
# ----------------------------
 
def parse_chunks(chunks: List[str]):
 
    nodes = set()
    edges = []
 
    stage_pattern = r"Stage:\s*(\w+)"
    output_pattern = r"Output:\s*(\w+)"
 
    for chunk in chunks:
 
        stages = re.findall(stage_pattern, chunk)
        outputs = re.findall(output_pattern, chunk)
 
        for s in stages:
            nodes.add(s)
 
        for o in outputs:
            nodes.add(o)
 
        for i in range(min(len(stages), len(outputs))):
 
            edges.append((stages[i], outputs[i]))
 
    return LineageGraph(
        nodes=list(nodes),
        edges=edges
    )
 
 
# ----------------------------
# Layout generation
# ----------------------------
 
def generate_layout(graph: LineageGraph):
 
    layout_nodes = []
 
    x = 100
    y = 100
 
    for node in graph.nodes:
 
        layout_nodes.append(
            LayoutNode(
                id=node,
                x=x,
                y=y
            )
        )
 
        y += 120
 
    return LayoutGraph(
        nodes=layout_nodes,
        edges=graph.edges
    )