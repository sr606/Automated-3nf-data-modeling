from mcp.server.fastmcp import FastMCP
from .helpers import read_file, chunk_text, parse_chunks, generate_layout
from .drawio_mcp import create_drawio_diagram
 
mcp = FastMCP("lineage-tools")
 
 
@mcp.tool()
def read_file_tool(file_name: str):
    return read_file(file_name)
 
 
@mcp.tool()
def chunk_tool(file_name: str):
    content = read_file(file_name)
    return chunk_text(content)
 
 
@mcp.tool()
def parse_tool(chunks: list):
    return parse_chunks(chunks)
 
 
@mcp.tool()
def layout_tool(graph: dict):
    return generate_layout(graph)
 
 
@mcp.tool()
def drawio_tool(nodes: list, edges: list, file_name: str):
    return create_drawio_diagram(nodes, edges, file_name)