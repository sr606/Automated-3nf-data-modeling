# from fastapi import APIRouter

# from agent_template.lineage_engine import LineageEngine
# from lineage_mcp.tools.helpers import (
#     read_file,
#     chunk_text,
#     parse_chunks,
#     generate_layout
# )

# from lineage_mcp.tools.diagram_generator import create_drawio_diagram

# router = APIRouter()

# engine = LineageEngine()


# @router.post("/generate")
# async def generate_lineage(file_name: str):

#     text = read_file(file_name)

#     chunks = chunk_text(text)

#     graph = parse_chunks(chunks)

#     layout = generate_layout(graph)

#     diagram = create_drawio_diagram(
#         layout["nodes"],
#         layout["edges"],
#         "lineage.drawio"
#     )

#     return {
#         "diagram": diagram
#     }

from fastapi import APIRouter

from agent_template.lineage_engine import run_lineage_agent

router = APIRouter()


@router.post("/generate")

async def generate_lineage(file_name: str):

    result = await run_lineage_agent(file_name)

    return result