# import os
# import re

# BASE_DIR = "lineage_mcp/data/upload"


# def read_file(file_name):

#     path = os.path.join(BASE_DIR, file_name)

#     with open(path) as f:
#         return f.read()


# def chunk_text(text, size=2000):

#     chunks = []

#     for i in range(0, len(text), size):

#         chunks.append(text[i:i + size])

#     return chunks


# def parse_chunks(chunks):

#     nodes = set()
#     edges = []

#     stage_pattern = r"Stage:\s*(\w+)"
#     output_pattern = r"Output:\s*(\w+)"

#     for chunk in chunks:

#         stages = re.findall(stage_pattern, chunk)
#         outputs = re.findall(output_pattern, chunk)

#         for s in stages:
#             nodes.add(s)

#         for o in outputs:
#             nodes.add(o)

#         for i in range(min(len(stages), len(outputs))):

#             edges.append((stages[i], outputs[i]))

#     return {
#         "nodes": list(nodes),
#         "edges": edges
#     }


# def generate_layout(graph):

#     nodes = []
#     x = 100
#     y = 100

#     for node in graph["nodes"]:

#         nodes.append({
#             "id": node,
#             "x": x,
#             "y": y
#         })

#         y += 120

#     return {
#         "nodes": nodes,
#         "edges": graph["edges"]
#     }

import os
import re

BASE_PATH = "lineage_mcp/data/upload"


def read_file(file_name):

    path = os.path.join(BASE_PATH, file_name)

    with open(path) as f:
        return f.read()


def chunk_text(text, size=2000):

    return [text[i:i+size] for i in range(0, len(text), size)]


def parse_chunks(chunks):

    nodes = set()
    edges = []

    stage_pattern = r"Stage:\s*(\w+)"
    output_pattern = r"Output:\s*(\w+)"

    for chunk in chunks:

        stages = re.findall(stage_pattern, chunk)
        outputs = re.findall(output_pattern, chunk)

        for s in stages:
            nodes.add(s)

        for o in outputs:
            nodes.add(o)

        for i in range(min(len(stages), len(outputs))):

            edges.append((stages[i], outputs[i]))

    return {
        "nodes": list(nodes),
        "edges": edges
    }