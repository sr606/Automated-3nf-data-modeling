# import os
# import uuid

# OUTPUT_DIR = "lineage_mcp/data/feature"


# def create_drawio_diagram(nodes, edges, file_name):

#     node_ids = {}
#     xml = []

#     xml.append("<mxfile><diagram><mxGraphModel><root>")
#     xml.append('<mxCell id="0"/><mxCell id="1" parent="0"/>')

#     for node in nodes:

#         nid = str(uuid.uuid4())
#         node_ids[node["id"]] = nid

#         xml.append(
#             f'<mxCell id="{nid}" value="{node["id"]}" vertex="1" parent="1">'
#             f'<mxGeometry x="{node["x"]}" y="{node["y"]}" width="140" height="60" as="geometry"/>'
#             '</mxCell>'
#         )

#     for src, dst in edges:

#         xml.append(
#             f'<mxCell edge="1" parent="1" source="{node_ids[src]}" target="{node_ids[dst]}">'
#             '<mxGeometry relative="1" as="geometry"/>'
#             '</mxCell>'
#         )

#     xml.append("</root></mxGraphModel></diagram></mxfile>")

#     path = os.path.join(OUTPUT_DIR, file_name)

#     with open(path, "w") as f:
#         f.write("\n".join(xml))

#     return path

import os
import uuid

OUTPUT_PATH = "lineage_mcp/data/feature"


def create_diagram(nodes, edges, name):

    xml = []
    node_map = {}

    xml.append("<mxfile><diagram><mxGraphModel><root>")
    xml.append('<mxCell id="0"/><mxCell id="1" parent="0"/>')

    x = 100
    y = 100
    
    for node in nodes:

        nid = str(uuid.uuid4())

        node_map[node] = nid

        xml.append(
            f'<mxCell id="{nid}" value="{node}" vertex="1" parent="1">'
            f'<mxGeometry x="100" y="100" width="140" height="60" as="geometry"/>'
            '</mxCell>'
        )

        x+=220

    for src, dst in edges:

        xml.append(
            f'<mxCell edge="1" parent="1" source="{node_map[src]}" target="{node_map[dst]}">'
            '<mxGeometry relative="1" as="geometry"/>'
            '</mxCell>'
        )

    xml.append("</root></mxGraphModel></diagram></mxfile>")

    path = os.path.join(OUTPUT_PATH, name)

    with open(path, "w") as f:
        f.write("\n".join(xml))

    return path