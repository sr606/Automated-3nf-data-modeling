import os
import asyncio
from dotenv import load_dotenv
 
from langchain_openai import AzureChatOpenAI
from langgraph.prebuilt import create_react_agent
from langchain_mcp_adapters.client import MultiServerMCPClient
 
load_dotenv()
 
# ----------------------------
# Azure LLM
# ----------------------------
 
llm = AzureChatOpenAI(
    azure_deployment=os.getenv("AZURE_OPENAI_DEPLOYMENT"),
    api_version=os.getenv("AZURE_OPENAI_API_VERSION"),
    azure_endpoint=os.getenv("AZURE_OPENAI_ENDPOINT"),
    api_key=os.getenv("AZURE_OPENAI_API_KEY"),
    temperature=0
)
 
# ----------------------------
# MCP Config
# ----------------------------
 
config_mcp_server = {
    "lineage_tools": {
        "transport": "http",
        "url": "http://127.0.0.1:8001/mcp"
    }
}
 
# ----------------------------
# SYSTEM PROMPT
# ----------------------------
 
SYSTEM_PROMPT = """
You are an AI lineage engineer.
 
Your task is to generate lineage diagrams from ETL pseudocode.
 
You have access to tools that can:
 
• read pseudocode files
• chunk large files
• parse lineage nodes and edges
• generate graph layouts
• create draw.io diagrams
 
Workflow:
 
1. Read pseudocode file
2. Chunk the file
3. Parse lineage nodes and edges
4. Generate graph layout
5. Create draw.io diagram
 
Always produce the final draw.io diagram file.
"""
 
# ----------------------------
# Build Agent
# ----------------------------
 
async def build_agent():
 
    client = MultiServerMCPClient(config_mcp_server)
 
    tools = await client.get_tools()
 
    agent = create_react_agent(
        llm,
        tools,
        prompt=SYSTEM_PROMPT
    )
 
    return agent
 
# ----------------------------
# Run Agent
# ----------------------------
 
async def run_agent(file_name):
 
    agent = await build_agent()
 
    result = await agent.ainvoke(
        {
            "messages": [
                ("user", f"Generate lineage diagram for file {file_name}")
            ]
        }
    )
 
    return result