import uvicorn
from mcp.mcp_server import mcp
 
app = mcp.app
 
if __name__ == "__main__":
    uvicorn.run(
        "agent.server:app",
        host="0.0.0.0",
        port=8001,
        reload=True
    )