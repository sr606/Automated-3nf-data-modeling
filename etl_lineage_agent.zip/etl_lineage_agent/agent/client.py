import asyncio
from lineage_agent import run_agent
 
 
async def main():
 
    file_name = "job1.txt"
 
    print("Running lineage agent...")
 
    result = await run_agent(file_name)
 
    print("\nAgent result:\n")
    print(result)
 
 
if __name__ == "__main__":
    asyncio.run(main())