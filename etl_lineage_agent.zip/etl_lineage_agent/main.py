# # from fastapi import FastAPI
# # import uvicorn

# # from lineage_mcp.routers.router import router as lineage_router

# # app = FastAPI(title="ETL Lineage System")

# # app.include_router(lineage_router, prefix="/lineage")


# # if __name__ == "__main__":

# #     uvicorn.run(
# #         "main:app",
# #         host="0.0.0.0",
# #         port=8001,
# #         reload=True
# #     )


# # import asyncio
# # from agent_template.lineage_engine import run_lineage_agent
 
# # async def main():
# #     result = await run_lineage_agent("job1.txt")
# #     print(result)
 
# # asyncio.run(main())

# import os
 
# from lineage_mcp.tools.helpers import (
#     read_file,
#     chunk_text,
#     parse_chunks,
#     generate_layout
# )
 
# from lineage_mcp.tools.diagram_generator import create_drawio_diagram
 
 
# def main():
 
#     file_name = "job1.txt"
 
#     print("Reading file...")
 
#     text = read_file(file_name)
 
#     print("Chunking...")
 
#     chunks = chunk_text(text)
 
#     print("Parsing lineage...")
 
#     graph = parse_chunks(chunks)
 
#     print("Generating layout...")
 
#     layout = generate_layout(graph)
 
#     print("Creating diagram...")
 
#     diagram_path = create_drawio_diagram(
#         layout["nodes"],
#         layout["edges"],
#         "lineage.drawio"
#     )
 
#     print("Diagram generated at:")
#     print(diagram_path)
 
 
# if __name__ == "__main__":
#     main()



import uvicorn
from fastapi import FastAPI
 
from lineage_mcp.routers.router import router
 
from lineage_mcp.tools.helpers import (
    read_file,
    chunk_text,
    parse_chunks
)
 
from lineage_mcp.tools.diagram_generator import create_diagram
 
 
# ----------------------------
# FastAPI Application
# ----------------------------
 
app = FastAPI(title="ETL Lineage System")
 
app.include_router(router, prefix="/lineage")
 
 
# ----------------------------
# Local Test Mode
# ----------------------------
 
def run_local_pipeline():
 
    file_name = "job1.txt"
 
    print("Reading file...")
    text = read_file(file_name)
 
    print("Chunking...")
    chunks = chunk_text(text)
 
    print("Parsing lineage...")
    graph = parse_chunks(chunks)
 
    nodes = graph["nodes"]
    edges = graph["edges"]
 
    print("Creating diagram...")
 
    diagram_path = create_diagram(
        nodes,
        edges,
        "lineage.drawio"
    )
 
    print("Diagram generated at:")
    print(diagram_path)
 
 
# ----------------------------
# Entry Point
# ----------------------------
 
if __name__ == "__main__":
 
    MODE = "local"   # change to "api" if you want FastAPI
 
    if MODE == "api":
 
        uvicorn.run(
            "main:app",
            host="0.0.0.0",
            port=8001,
            reload=True
        )
 
    else:
 
        run_local_pipeline()