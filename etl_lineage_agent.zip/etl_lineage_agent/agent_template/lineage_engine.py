# import os
# from dotenv import load_dotenv

# from langchain_openai import AzureChatOpenAI

# load_dotenv()


# class LineageEngine:

#     def __init__(self):

#         self.llm = AzureChatOpenAI(
#             azure_deployment=os.environ["AZURE_OPENAI_CHAT_DEPLOYMENT_NAME"],
#             openai_api_version=os.environ["AZURE_OPENAI_API_VERSION"],
#             azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
#             api_key=os.environ["AZURE_OPENAI_API_KEY"],
#             temperature=0.0,
#         )

#     async def generate_lineage(self, pseudocode):

#         prompt = f"""
# You are an ETL lineage engineer.

# Extract nodes and edges from the following pseudocode.

# Return JSON:

# nodes: []
# edges: []

# Pseudocode:
# {pseudocode}
# """

#         response = await self.llm.ainvoke(prompt)

#         return response.content

import os
from dotenv import load_dotenv
from typing_extensions import TypedDict

from langchain_openai import AzureChatOpenAI
from langchain_mcp_adapters.client import MultiServerMCPClient

from langgraph.graph import StateGraph, END

load_dotenv()


# -----------------------------
# State
# -----------------------------

class LineageState(TypedDict):

    file_name: str
    messages: list


# -----------------------------
# MCP CONFIG
# -----------------------------

def get_mcp_config():

    return {
        "lineage_tools": {
            "url": "http://127.0.0.1:8001/mcp",
            "transport": "streamable_http"
        }
    }


# -----------------------------
# LLM
# -----------------------------

def get_llm():

    llm = AzureChatOpenAI(
        azure_deployment=os.environ["AZURE_OPENAI_CHAT_DEPLOYMENT_NAME"],
        openai_api_version=os.environ["AZURE_OPENAI_API_VERSION"],
        azure_endpoint=os.environ["AZURE_OPENAI_ENDPOINT"],
        api_key=os.environ["AZURE_OPENAI_API_KEY"],
        temperature=0.0
    )

    return llm


# -----------------------------
# Tool Discovery
# -----------------------------

async def discover_tools():

    client = MultiServerMCPClient(get_mcp_config())

    tools = await client.get_tools()

    return tools


# -----------------------------
# Workflow Nodes
# -----------------------------

async def lineage_node(state: LineageState):

    llm = get_llm()

    prompt = f"""
Generate ETL lineage diagram from file:

{state["file_name"]}

Use available tools when needed.
"""

    response = await llm.ainvoke(prompt)

    return {
        "messages": [response]
    }


# -----------------------------
# Graph Builder
# -----------------------------

async def build_graph():

    graph = StateGraph(LineageState)

    graph.add_node("lineage_node", lineage_node)

    graph.set_entry_point("lineage_node")

    graph.add_edge("lineage_node", END)

    return graph.compile()


# -----------------------------
# Run Agent
# -----------------------------

async def run_lineage_agent(file_name):

    graph = await build_graph()

    result = await graph.ainvoke(
        {
            "file_name": file_name,
            "messages": []
        }
    )

    return result