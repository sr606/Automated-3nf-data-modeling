from langgraph.graph import StateGraph, START, END
from langgraph.graph.message import add_messages
from typing import Annotated
from typing_extensions import TypedDict
from langgraph.checkpoint.memory import InMemorySaver
from langgraph.prebuilt import ToolNode, tools_condition
from langchain_core.tools import tool
from langchain_core.messages import SystemMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langgraph.types import Command, interrupt
from langchain_tavily import TavilySearch
# from langchain_azure_ai.chat_models import AzureAIChatCompletionsModel
from langchain_aws.chat_models import ChatBedrock
import asyncio
import json
from dotenv import load_dotenv
from phoenix.client import Client
import requests
import logging
from langchain_mcp_adapters.client import MultiServerMCPClient
import boto3

import os

load_dotenv()
# logging.basicConfig(level=logging.INFO)
# logger = logging.getLogger(__name__)

agent_name = os.environ.get("AGENT_NAME")
#general_agent_name = os.environ.get("GENERAL_AGENT_NAME", "data-general")
config_url = os.environ.get("AGENT_CONFIG_ENDPOINT")
model_name = os.environ.get("AZURE_OPENAI_CHAT_DEPLOYMENT_NAME")
inference_profile_arn = os.environ.get("AWS_INFERENCE_PROFILE_ARN")

def get_system_prompt(agent_name: str) -> str:
    client = Client()
    prompt_name = agent_name.lower().strip()
    prompt = client.prompts.get(prompt_identifier=prompt_name)
    prompt_set = prompt._template["messages"]

    prompt_msg = next(
        (item["content"][0]["text"] for item in prompt_set if item.get("role") == "system"),
        None
    )
    
    if prompt_msg and isinstance(prompt_msg, str) and len(prompt_msg) > 0:
        system_msg = prompt_msg
    else:
        raise ValueError(f"Error: 'prompt_msg' is empty or improperly structured:{prompt_msg}, {agent_name}")
    # print("System Prompt Loaded:",system_msg)
    return system_msg

def get_mcp_config(agent_name: str, config_url: str) -> dict:
    """
    Get MCP server configuration for the given agent.
    
    Args:
        agent_name: Name of the agent
        config_url: Base URL of the configuration service
        
    Returns:
        dict: MCP configuration with server URLs and transport settings
    """

    
    result = {
        "Catalog_MCP": {
            "url": "http://0.0.0.0:8020/api/v1/catalog_data/mcp",
            "transport": "streamable_http"
        }
    }
    return result


async def get_tool_list(config_mcp_server):
    """
    Fetch tools from MCP servers.

    Args:
        config_mcp_server: MCP server configuration dictionary

    Returns:
        list: List of tools fetched from MCP servers
    """
    if not config_mcp_server:
        return []

    client = MultiServerMCPClient(config_mcp_server)
    tools_list = await client.get_tools()
    return tools_list


class State(TypedDict):
    messages: Annotated[list, add_messages]
    
memory = InMemorySaver()


# llm = AzureAIChatCompletionsModel(
#     endpoint=os.getenv("AZURE_INFERENCE_ENDPOINT"),
#     credential=os.getenv("AZURE_INFERENCE_CREDENTIAL"),
#     model=model_name,
#     temperature=0.0,
#     max_tokens=None,
#     disable_streaming=False
# )

llm = ChatBedrock(
    # model_id="us.anthropic.claude-sonnet-4-5-20250929-v1:0",
    # model_id = "global.anthropic.claude-haiku-4-5-20251001-v1:0",
    model_id = "us.anthropic.claude-sonnet-4-20250514-v1:0",
    # model_id = "us.anthropic.claude-3-5-sonnet-20240620-v1:0",
    # model_id="us.anthropic.claude-3-5-haiku-20241022-v1:0",
    # model_id="us.amazon.nova-premier-v1:0",
    # inference_profile_arn="arn:aws:bedrock:us-east-1:610997664029:inference-profile/us.anthropic.claude-3-haiku-20240307-v1:0",
    region=os.getenv("AWS_REGION", "us-east-2"),
    streaming=True,
    model_kwargs={"temperature": 0.0, "max_tokens":65536}
)

@tool
def human_assistance(query: str) -> str:
    """Request input from a human."""
    human_response =  interrupt({"query": query})
    return human_response


async def get_all_tools():
    """Fetch and return all tools including MCP tools from both agent sources."""
    config_mcp_server = get_mcp_config(agent_name, config_url)
    #general_config = get_mcp_config(general_agent_name, config_url)

    tools_list = await get_tool_list(config_mcp_server) if config_mcp_server else []
    # print('this is tool list', tools_list)

    return [human_assistance] + tools_list #+ general_tools_list



# Get all tools
tools = asyncio.run(get_all_tools())
# Print all tool names (fall back to __name__ if needed)
# print("=" * 60)
# print(f"ALL AVAILABLE TOOLS ({len(tools)}):")
# for i, tool in enumerate(tools, 1):
#     tool_name = getattr(tool, "name", getattr(tool, "__name__", type(tool).__name__))
#     print(f"  {i}. {tool_name}")

# search_tool = TavilySearch(max_results=2)
# tools=[human_assistance,calculator]

tool_node = ToolNode(tools=tools)
llm_with_tools = llm.bind_tools(tools)

async def chatbot(state: State):

    system_msg = get_system_prompt(agent_name)

    prompt = ChatPromptTemplate.from_messages([
                SystemMessage(content=system_msg),
                MessagesPlaceholder(variable_name="context", optional=True, n_messages=None),
            ])
    messages = prompt.format_messages(
        context=state["messages"],
    )

    message = llm_with_tools.invoke(messages)

    yield {"messages": [message]}


graph_builder = StateGraph(State)
graph_builder.add_node("chatbot", chatbot)
graph_builder.add_node("tools", tool_node)

graph_builder.add_edge(START, "chatbot")
graph_builder.add_conditional_edges(
    "chatbot",
    tools_condition,
)
graph_builder.add_edge("tools", "chatbot")
graph_builder.add_edge("chatbot", END)

graph = graph_builder.compile(checkpointer=memory)

