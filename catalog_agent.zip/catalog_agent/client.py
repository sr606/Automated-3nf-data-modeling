import asyncio
import httpx
import uuid
import json

async def stream_chat(query: str, thread_id: str, url: str):
    payload = {
        "query": query,
        "thread_id": thread_id
    }
    state = {"state":""}
    async with httpx.AsyncClient(timeout=None) as client:
        # Use a streaming POST request
        async with client.stream("POST", url, json=payload) as response:
            async for line in response.aiter_lines():
                if line.startswith("data: "):
                    message = line.removeprefix("data: ").strip()
                    if 'message' in message:
                        try:
                            parsed = json.loads(message)
                            yield json.dumps(parsed, indent=2)
                        except:
                            yield message
                    if 'interrupt' in message:
                        try:
                            parsed = json.loads(message)
                            state['state'] = "interrupt"
                            state['content'] = parsed
                        except:
                            yield message   
    yield state

async def main():
    session_ID = str(uuid.uuid4())
    state = {"state":""}

    while True:
        uq = input('ask : ')
        if uq == 'exit':
            break

        if state['state'] == "":
            url = "http://127.0.0.1:8075/chat"
            #url = "https://dq-amaze-azcontainer.centralus.azurecontainer.io/chat"
            #url = "http://Omnico-Omnic-256sUDUgVbxg-1065779802.us-east-2.elb.amazonaws.com/kb-pipe/chat"
            

        else:
            url = "http://127.0.0.1:8075/continue_chat"
            #url = "https://dq-amaze-azcontainer.centralus.azurecontainer.io/continue_chat"
            #url = "http://Omnico-Omnic-256sUDUgVbxg-1065779802.us-east-2.elb.amazonaws.com/kb-pipe/continue_chat"


        print(url)
        print(state["state"])
        async for resp in stream_chat(uq, session_ID, url):
            print(resp)
            if isinstance(resp, dict) and "state" in resp:
                state = resp

# Run the async main function
if __name__ == "__main__":
    asyncio.run(main())
