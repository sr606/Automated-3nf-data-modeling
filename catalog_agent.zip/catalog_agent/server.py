from fastapi import FastAPI
from catalog_agent import graph
from langgraph.types import Command
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import StreamingResponse
from pydantic import BaseModel, Field
import uvicorn
import json
from phoenix.otel import register
import os 

os.environ["PHOENIX_CLIENT_HEADERS"] = f"api_key={os.getenv('PHOENIX_API_KEY')}"
trace_url = os.environ["PHOENIX_COLLECTOR_ENDPOINT"]+"v1/traces"
agent_name = os.environ["AGENT_NAME"]

async def stream(message,checkpoint_id):
    config = {"configurable": {"thread_id": checkpoint_id}, "recursion_limit": 200}
    async for event in graph.astream({"messages": [{"role": "user", "content": message}]},config):
        for value in event.values():
            if 'messages' in value:
                msg = value["messages"][-1]
                # Assuming msg is a Pydantic model or dict-like
                if hasattr(msg, "model_dump"):
                    data = {"message": msg.model_dump()}
                elif hasattr(msg, "dict"):
                    data = {"message": msg.dict()}
                else:
                    data = {"message": str(msg)}
                yield f"data: {json.dumps(data)}\n\n"
            else:
                # print("\n",value)
                interrupt={}
                interrupt['query']=value[0].value['query']
                interrupt['id']=value[0].id
                interrupt['session']=checkpoint_id
                data = {"interrupt": interrupt}
                yield f"data: {json.dumps(data)}\n\n"

async def continue_chat_stream(message,checkpoint_id):
    config = {"configurable": {"thread_id": checkpoint_id}}
    async for event in graph.astream(Command(resume = {"messages": [{"role": "user", "content": message}]}),config):
        for value in event.values():
            if 'messages' in value:
                msg = value["messages"][-1]
                # Assuming msg is a Pydantic model or dict-like
                if hasattr(msg, "model_dump"):
                    data = {"message": msg.model_dump()}
                elif hasattr(msg, "dict"):
                    data = {"message": msg.dict()}
                else:
                    data = {"message": str(msg)}
                yield f"data: {json.dumps(data)}\n\n"
            else:
                # print("\n",value)
                interrupt={}
                interrupt['query']=value[0].value['query']
                interrupt['id']=value[0].id
                interrupt['session']=checkpoint_id
                data = {"interrupt": interrupt}
                yield f"data: {json.dumps(data)}\n\n"

app = FastAPI()
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class InputData(BaseModel):
    query: str
    thread_id: str


tracer_provider = register(
    project_name=agent_name,
    auto_instrument=True,
    batch=True,
    endpoint=trace_url,
)

@app.post("/chat")
async def chat_stream(input: InputData):
    return StreamingResponse(
        stream(
            message=input.query,
            checkpoint_id=input.thread_id
        ),
        media_type="text/event-stream"
    )

@app.post("/continue_chat")
async def continue_chat(input: InputData):
    return StreamingResponse(
        continue_chat_stream(
            message=input.query,
            checkpoint_id=input.thread_id
        ),
        media_type="text/event-stream"
    )


if __name__ == "__main__":
    uvicorn.run(app,host="0.0.0.0",port=8075)
