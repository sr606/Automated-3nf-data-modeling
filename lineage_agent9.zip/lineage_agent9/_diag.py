"""Diagnostic: PATCH split_structured_blocks to bypass is_low_value_block."""
from pathlib import Path
import re

from lineage_agent.brain import preprocessing

LOW_VALUE_STAGE_TOKENS = (
    "peek", "rowgenerator", "row_generator", "columngenerator", "column_generator",
    "debug", "copy", "sort", "head", "tail", "sample", "reject_handler",
    "log", "audit",
)

# Monkey-patch to see ALL blocks before filtering
_original_is_low = preprocessing.is_low_value_block
preprocessing.is_low_value_block = lambda text: False

uploads_dir = Path("data") / "uploads"
input_files = sorted(
    [
        path
        for pattern in ("*.txt", "*.xml", "*.json")
        for path in uploads_dir.glob(pattern)
    ]
)
if not input_files:
    raise FileNotFoundError(f"No input files found in {uploads_dir.resolve()}")

input_path = input_files[0]
text = input_path.read_text(encoding="utf-8", errors="ignore")
blocks = preprocessing.split_structured_blocks(text)
print(f"Using input file: {input_path}\n")
print(f"Total blocks WITHOUT low-value filter: {len(blocks)}\n")

for b in blocks:
    name = b["name"]
    btype = b["block_type"]
    tlen = len(b["text"].split())
    lowered = b["text"].lower()
    matched_tokens = [t for t in LOW_VALUE_STAGE_TOKENS if t in lowered]
    is_low = _original_is_low(b["text"])
    status = "DROPPED" if is_low else "OK     "
    print(f"  [{status}] {name:50s} type={btype:10s} tokens={tlen:5d} matched={matched_tokens}")

# Restore
preprocessing.is_low_value_block = _original_is_low
