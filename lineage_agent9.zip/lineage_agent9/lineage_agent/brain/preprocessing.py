import re
from typing import Any

LOW_VALUE_STAGE_TOKENS = (
    "peek",
    "rowgenerator",
    "row_generator",
    "columngenerator",
    "column_generator",
    "debug",
    "copy",
    "sort",
    "head",
    "tail",
    "sample",
    "reject_handler",
    "log",
    "audit",
)

GENERIC_STAGE_PATTERNS = (
    "SOURCE_DATA",
    "TARGET_OUTPUT",
    "MAIN_DATA_OUTPUT",
    "NEXT_PROCESSING_STAGE",
    "OUTPUT_TRANSFORMER",
    "TARGET_CONNECTOR",
    "SOURCE_CONNECTOR",
    "JOB_COMPLETION_HANDLER",
    "ERROR_HANDLING",
)


def canonicalize_name(name: str) -> str:
    if not name:
        return name
    normalized = str(name).strip().upper()
    normalized = re.sub(r"STAGE_", "", normalized)
    normalized = re.sub(r"_SOURCE|_INPUT|_OUTPUT", "", normalized)
    return normalized


def build_entity_map(text: str) -> dict[str, str]:
    mapping = {}
    for table in re.findall(r"[A-Za-z0-9_]+\.[A-Za-z0-9_]+", text):
        canonical = canonicalize_name(table)
        mapping[canonical] = table
    return mapping


def build_preprocessed_context(text: str, max_chunk_chars: int) -> dict[str, Any]:
    structured_blocks = split_structured_blocks(text)
    chunk_payload = build_phase1_chunks(structured_blocks, max_chunk_chars)
    return {
        "job_name_hints": job_name_hints(text),
        "stage_name_hints": _dedupe_strings(stage_name_hints(text)),
        "target_table_hints": target_table_hints(text),
        "annotation_hints": annotation_hints(text),
        "entity_map": build_entity_map(text),
        "dominant_table_hints": dominant_table_hints(text),
        "document_sql_profile": build_document_sql_profile(text),
        "stage_primacy_hints": build_stage_primacy_hints(text),
        "stage_sql_hints": build_stage_sql_hints(text),
        "chunks": chunk_payload,
    }


def split_structured_blocks(text: str) -> list[dict[str, Any]]:
    lines = text.splitlines()
    blocks: list[dict[str, Any]] = []
    current = []
    current_name = "DOCUMENT_PREAMBLE"
    current_type = "section"

    def flush_current() -> None:
        nonlocal current, current_name, current_type
        if not current:
            return
        block_text = "\n".join(current).strip()
        current = []
        if not block_text or is_low_value_block(block_text):
            return
        blocks.append(
            {
                "name": current_name,
                "block_type": current_type,
                "text": block_text,
            }
        )

    for line in lines:
        stripped = line.strip()
        stage_match = re.match(r"^\s{0,2}(STAGE_[A-Z0-9_]+):\s*$", stripped)
        link_match = re.match(r"^\s{0,2}(LINK_[A-Z0-9_]+):\s*$", stripped)
        job_match = re.match(r"^\s{0,2}(JOB_[A-Z0-9_]+):\s*$", stripped)
        begin_end_match = re.match(r"^\s{0,2}(BEGIN_[A-Z0-9_]+|END_[A-Z0-9_]+):\s*$", stripped)
        alt_job_match = re.match(r"^\s{0,2}JOB:\s*(.+?)\s*$", stripped, re.I)
        alt_stage_match = re.match(r"^\s{0,2}STAGE:\s*(.+?)\s*$", stripped, re.I)
        record_match = re.match(
            r"^\s{0,2}Child\s+Tag:\s+Record\s+\(Identifier:\s*([^,]+),\s*Type:\s*([^)]+)\)\s*$",
            stripped,
            re.I,
        )
        if stage_match:
            flush_current()
            current_name = stage_match.group(1)
            current_type = "stage"
        elif link_match:
            flush_current()
            current_name = link_match.group(1)
            current_type = "link"
        elif job_match:
            flush_current()
            current_name = job_match.group(1)
            current_type = "job"
        elif begin_end_match:
            flush_current()
            current_name = begin_end_match.group(1)
            current_type = "section"
        elif alt_job_match:
            flush_current()
            current_name = alt_job_match.group(1).strip()
            current_type = "job"
        elif alt_stage_match:
            flush_current()
            current_name = alt_stage_match.group(1).strip()
            current_type = "stage"
        elif record_match and current_type != "stage":
            flush_current()
            identifier = record_match.group(1).strip()
            record_type = record_match.group(2).strip()
            current_name = identifier
            current_type = "record"
        if stripped:
            current.append(line)
    flush_current()
    return blocks


def build_phase1_chunks(blocks: list[dict[str, Any]], max_chunk_chars: int) -> list[dict[str, Any]]:
    token_budget = _chunk_token_budget(max_chunk_chars)
    chunk_payload: list[dict[str, Any]] = []
    for block in blocks:
        block_text = str(block.get("text") or "")
        block_name = str(block.get("name") or "unnamed_block")
        if not _should_emit_block_for_phase1(block):
            continue
        semantic_chunks = chunk_block_semantic(block_text, max_tokens=token_budget, overlap=0.2)
        total_chunks = len(semantic_chunks)
        block_type = str(block.get("block_type") or "section")
        object_type = detect_object_type(block_name, block_text, block_type)
        target_tables = _dedupe_strings(
            [value.strip().strip('"') for value in re.findall(r"(?mi)^\s{0,4}(?:TARGET_TABLE|Target Table|TableName)\s*[:=]\s*([^\n]+)$", block_text)]
        )
        input_links = _dedupe_strings(re.findall(r"(?mi)^\s{0,4}Input Link:\s*([^\n]+)$", block_text))
        output_links = _dedupe_strings(re.findall(r"(?mi)^\s{0,4}Output Link:\s*([^\n]+)$", block_text))
        connector_direction = detect_connector_direction(block_name, block_text, target_tables, input_links, output_links)
        wrapper_hint = detect_wrapper_hint(block_name, block_text, block_type, object_type, connector_direction)
        kind = chunk_kind(block_name, block_text, block_type, object_type, connector_direction, wrapper_hint)
        stage_names = _dedupe_strings(stage_name_hints(block_text))
        tables = _dedupe_strings(re.findall(r"[A-Za-z0-9_]+\.[A-Za-z0-9_]+", block_text))
        has_sql = bool(re.search(r"\bSELECT\b", block_text, re.I))
        sql_complexity = detect_sql_complexity(block_text)
        is_structural = block_type == "link"
        signal_strength = round(
            (3 if has_sql else 0)
            + (sql_complexity * 0.5)
            + (1 if kind == "transform" else 0)
            - (1.5 if is_structural else 0),
            2,
        )
        for index, chunk in enumerate(semantic_chunks, start=1):
            chunk_payload.append(
                {
                    "chunk_id": f"{_chunk_safe_name(block_name)}_chunk_{index}",
                    "stage_name": block_name if block.get("block_type") == "stage" else "",
                    "block_name": block_name,
                    "block_type": block_type,
                    "object_type": object_type,
                    "connector_direction": connector_direction,
                    "wrapper_hint": wrapper_hint,
                    "target_tables": target_tables[:12],
                    "input_links": input_links[:10],
                    "output_links": output_links[:10],
                    "chunk_index": index,
                    "total_chunks_in_stage": total_chunks,
                    "kind": kind,
                    "is_structural": is_structural,
                    "tables": tables[:12],
                    "has_sql": has_sql,
                    "sql_complexity": sql_complexity,
                    "signal_strength": signal_strength,
                    "stage_names": stage_names,
                    "start_token": chunk["start_token"],
                    "end_token": chunk["end_token"],
                    "text": chunk["text"],
                }
            )
    return chunk_payload


def chunk_block_semantic(block: str, max_tokens: int = 400, overlap: float = 0.2) -> list[dict[str, Any]]:
    tokens = str(block or "").split()
    if not tokens:
        return [{"chunk_id": "chunk_1", "text": "", "start_token": 0, "end_token": 0}]
    chunk_size = max(200, min(max_tokens, 500))
    step = max(1, int(chunk_size * (1 - overlap)))
    chunks: list[dict[str, Any]] = []
    start = 0
    chunk_id = 1
    while start < len(tokens):
        chunk_tokens = tokens[start : start + chunk_size]
        chunks.append(
            {
                "chunk_id": f"chunk_{chunk_id}",
                "text": " ".join(chunk_tokens),
                "start_token": start,
                "end_token": start + len(chunk_tokens),
            }
        )
        if start + chunk_size >= len(tokens):
            break
        start += step
        chunk_id += 1
    return chunks


def _chunk_token_budget(max_chunk_chars: int) -> int:
    estimated_tokens = max_chunk_chars // 4 if max_chunk_chars else 400
    return max(300, min(estimated_tokens, 400))


def _should_emit_block_for_phase1(block: dict[str, Any]) -> bool:
    block_text = str(block.get("text") or "")
    block_type = str(block.get("block_type") or "")
    token_count = len(block_text.split())
    if block_type == "stage":
        return True
    if block_type == "link":
        return token_count >= 15
    if re.search(r"\bSELECT\b", block_text, re.I):
        return True
    if stage_name_hints(block_text):
        return True
    if block_type in {"job", "section"} and token_count < 25:
        return False
    return token_count >= 40


def _chunk_safe_name(value: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9_]+", "_", str(value or "").strip())
    cleaned = re.sub(r"_+", "_", cleaned).strip("_")
    return cleaned.lower() or "chunk"


def job_name_hints(text: str) -> list[str]:
    patterns = (
        r'Job_Name\s*=\s*"([^"]+)"',
        r'JOB_NAME\s*=\s*"([^"]+)"',
        r"JOB_START:\s*([^\n]+)",
        r"(?m)^\s{0,2}JOB:\s*([^\n]+?)\s*$",
    )
    hints = []
    for pattern in patterns:
        for match in re.findall(pattern, text):
            value = str(match).strip()
            if value and value not in hints:
                hints.append(value)
    return hints


def stage_name_hints(text: str) -> list[str]:
    names = re.findall(r"(?m)^\s{0,2}(STAGE_[A-Z0-9_]+):\s*$", text)
    names.extend(re.findall(r"(?m)^\s{0,2}STAGE:\s*([^\n]+?)\s*$", text, re.I))
    names.extend(
        re.findall(
            r"(?mi)^\s{0,2}Child\s+Tag:\s+Record\s+\(Identifier:\s*([^,]+),\s*Type:\s*([^)]+)\)\s*$",
            text,
        )
    )
    flattened = []
    for item in names:
        if isinstance(item, tuple):
            flattened.append(str(item[0]).strip())
        else:
            flattened.append(str(item).strip())
    return [name for name in _dedupe_strings(flattened) if not is_low_value_stage_name(name)]


def target_table_hints(text: str) -> list[str]:
    hints = []
    patterns = (
        r'(?m)^\s{2,}(?:TARGET_TABLE|Target_Table|TableName)\s*:\s*([^\n]+)$',
        r"TRUNCATE TABLE\s+([A-Za-z0-9_.]+)",
    )
    for pattern in patterns:
        for match in re.findall(pattern, text, re.I):
            value = str(match).strip().strip('"')
            if value and value not in hints:
                hints.append(value)
    return hints


def annotation_hints(text: str) -> list[str]:
    hints = []
    patterns = (
        r'annotation_name\s*=\s*"([^"]+)"',
        r'description\s*=\s*"([^"]+)"',
        r'target_table\s*=\s*"([^"]+)"',
    )
    for pattern in patterns:
        for match in re.findall(pattern, text, re.I):
            value = str(match).strip()
            if value and value not in hints:
                hints.append(value)
    return hints


def build_stage_primacy_hints(text: str) -> dict[str, dict[str, Any]]:
    hints: dict[str, dict[str, Any]] = {}
    target_hints = [item.upper() for item in target_table_hints(text)]
    annotation_items = [item.upper() for item in annotation_hints(text)]
    for stage_name in stage_name_hints(text):
        upper_stage = stage_name.upper()
        stage_block = _extract_stage_block(text, stage_name)
        score = 0
        reasons: list[str] = []
        if any(target in stage_block.upper() for target in target_hints):
            score += 3
            reasons.append("target_table_alignment")
        if any(item in stage_block.upper() or item in upper_stage for item in annotation_items):
            score += 2
            reasons.append("annotation_alignment")
        if "COLUMN_DEFINITIONS" in stage_block.upper() or "COLUMN_MAPPINGS" in stage_block.upper():
            score += 1
            reasons.append("detailed_schema")
        if any(pattern in upper_stage for pattern in GENERIC_STAGE_PATTERNS):
            score -= 2
            reasons.append("generic_stage_name")
        if any(token in upper_stage for token in LOW_VALUE_STAGE_TOKENS):
            score -= 3
            reasons.append("low_value_stage")
        hints[stage_name] = {"score": score, "reasons": reasons}
    return hints


def detect_sql_complexity(text: str) -> int:
    sample = str(text or "")
    joins = len(re.findall(r"\bJOIN\b", sample, re.I))
    cases = len(re.findall(r"\bCASE\b", sample, re.I))
    selects = len(re.findall(r"\bSELECT\b", sample, re.I))
    return joins + cases + selects


def build_stage_sql_hints(text: str) -> dict[str, dict[str, Any]]:
    hints: dict[str, dict[str, Any]] = {}
    for stage_name in stage_name_hints(text):
        stage_block = _extract_stage_block(text, stage_name)
        join_count = len(re.findall(r"\bJOIN\b", stage_block, re.I))
        left_join_count = len(re.findall(r"\bLEFT(?:\s+OUTER)?\s+JOIN\b", stage_block, re.I))
        case_count = len(re.findall(r"\bCASE\b", stage_block, re.I))
        select_count = len(re.findall(r"\bSELECT\b", stage_block, re.I))
        complexity = detect_sql_complexity(stage_block)
        tables = _dedupe_strings(re.findall(r"[A-Za-z0-9_]+\.[A-Za-z0-9_]+", stage_block))
        hints[stage_name] = {
            "sql_complexity": complexity,
            "join_count": join_count,
            "left_join_count": left_join_count,
            "case_count": case_count,
            "select_count": select_count,
            "tables": tables[:12],
            "is_preintegrated_source_candidate": join_count >= 3 and (case_count > 0 or len(tables) >= 3),
        }
    return hints


def build_document_sql_profile(text: str) -> dict[str, Any]:
    return {
        "sql_complexity": detect_sql_complexity(text),
        "join_count": len(re.findall(r"\bJOIN\b", text, re.I)),
        "left_join_count": len(re.findall(r"\bLEFT(?:\s+OUTER)?\s+JOIN\b", text, re.I)),
        "case_count": len(re.findall(r"\bCASE\b", text, re.I)),
        "select_count": len(re.findall(r"\bSELECT\b", text, re.I)),
    }


def dominant_table_hints(text: str, limit: int = 20) -> list[str]:
    counts: dict[str, int] = {}
    for table in re.findall(r"[A-Za-z0-9_]+\.[A-Za-z0-9_]+", text):
        counts[table] = counts.get(table, 0) + 1
    ranked = sorted(counts.items(), key=lambda item: (-item[1], item[0]))
    return [table for table, _ in ranked[:limit]]


def chunk_kind_with_metadata(
    stage: str,
    lowered: str,
    block_type: str,
    object_type: str,
    connector_direction: str,
    wrapper_hint: str,
) -> str:
    if block_type == "link":
        return "structural"
    if wrapper_hint in {"wrapper", "passthrough"} and connector_direction != "target":
        return "source"
    if connector_direction == "source":
        return "source"
    if connector_direction == "target":
        return "target"
    if connector_direction == "store":
        return "store"
    if stage.startswith("STAGE_SEQUENTIAL_FILE") or "csequentialfilestage" in lowered or "cseqfilestage" in lowered:
        return "source"
    if stage.startswith("STAGE_LOOKUP_") or "clookupstage" in lowered:
        return "lookup"
    if stage.startswith("STAGE_HF_") or "hashedfile" in lowered:
        if any(token in lowered for token in ("write_mode", "write_record", "store_processed_data", "load_vor_data_to_hashed_file")):
            return "store"
        return "lookup"
    if stage.startswith("STAGE_TARGET_") or stage.startswith("STAGE_MAIN_DATA_OUTPUT"):
        return "target"
    if "EXCEPTION" in stage:
        return "exception"
    if stage.startswith("STAGE_TRANSFORMER_") or stage.endswith("_TRANSFORMER") or "ctransformerstage" in lowered:
        return "transform"
    if "target_table" in lowered or ("connector" in lowered and "write" in lowered) or "load_to_staging_table" in lowered:
        return "store"
    if "transformer" in lowered or "join" in lowered or "aggreg" in lowered:
        return "transform"
    if "sequentialfile" in lowered or "oracleconnector" in lowered:
        return "source"
    return "source"


def chunk_kind(
    stage_name: str,
    text: str,
    block_type: str = "",
    object_type: str = "",
    connector_direction: str = "",
    wrapper_hint: str = "",
) -> str:
    stage = str(stage_name or "").upper()
    lowered = str(text or "").lower()
    block_type = str(block_type or "").lower()
    return chunk_kind_with_metadata(
        stage,
        lowered,
        block_type,
        str(object_type or "").lower(),
        str(connector_direction or "").lower(),
        str(wrapper_hint or "").lower(),
    )


def detect_object_type(stage_name: str, text: str, block_type: str = "") -> str:
    sample = " ".join([str(stage_name or ""), str(text or ""), str(block_type or "")])
    patterns = (
        r"(?i)\bType:\s*([A-Za-z0-9_]+(?:\s*\([^)]+\))?)",
        r"(?i)\bConnector\s+Type:\s*([A-Za-z0-9_]+)",
        r"(?i)\bChild\s+Tag:\s+Record\s+\(Identifier:\s*[^,]+,\s*Type:\s*([^)]+)\)",
    )
    for pattern in patterns:
        match = re.search(pattern, sample)
        if match:
            return str(match.group(1)).strip()
    return ""


def detect_connector_direction(
    stage_name: str,
    text: str,
    target_tables: list[str],
    input_links: list[str],
    output_links: list[str],
) -> str:
    stage = str(stage_name or "").upper()
    sample = str(text or "")
    lowered = sample.lower()
    if re.search(r"\bSELECT\b", sample, re.I) and "oracleconnector" in lowered and not target_tables:
        return "source"
    if target_tables and re.search(r"\b(TRUNCATE|INSERT|LOAD|WRITE_MODE|TableAction=3|GenerateTruncateStatement=true)\b", sample, re.I):
        return "target"
    if "hashedoutput" in lowered:
        return "store"
    if "customoutput" in lowered and target_tables:
        return "target"
    if "oracleconnector" in lowered and target_tables:
        return "target"
    if output_links and not input_links and "oracleconnector" in lowered:
        return "source"
    if input_links and not output_links and target_tables:
        return "target"
    if stage.endswith("OUTPUT") and target_tables:
        return "target"
    return ""


def detect_wrapper_hint(stage_name: str, text: str, block_type: str, object_type: str, connector_direction: str) -> str:
    stage = str(stage_name or "").upper()
    lowered = str(text or "").lower()
    object_type = str(object_type or "").lower()
    connector_direction = str(connector_direction or "").lower()
    if block_type == "record":
        return "wrapper"
    if "transactionmanager" in stage or "transactionmanager" in lowered:
        return "wrapper"
    if "customstage" in object_type and connector_direction in {"source", "target"}:
        return "wrapper"
    if "customoutput" in object_type:
        return "wrapper"
    return ""


def is_low_value_stage_name(name: str) -> bool:
    lowered = str(name or "").strip().lower()
    return any(token in lowered for token in LOW_VALUE_STAGE_TOKENS)


def is_low_value_block(text: str) -> bool:
    lowered = str(text or "").lower()
    return any(token in lowered for token in LOW_VALUE_STAGE_TOKENS)


def _dedupe_strings(values: list[str]) -> list[str]:
    results = []
    for value in values:
        item = str(value or "").strip()
        if item and item not in results:
            results.append(item)
    return results


def _extract_stage_block(text: str, stage_name: str) -> str:
    patterns = [
        re.compile(
            rf"(?ms)^\s{{0,2}}{re.escape(stage_name)}:\s*$.*?(?=^\s{{0,2}}STAGE_[A-Z0-9_]+:\s*$|^\s{{0,2}}LINK_[A-Z0-9_]+:|\Z)"
        ),
        re.compile(
            rf"(?ms)^\s{{0,2}}STAGE:\s*{re.escape(stage_name)}\s*$.*?(?=^\s{{0,2}}STAGE:\s*[^\n]+$|^\s{{0,2}}JOB:\s*[^\n]+$|\Z)",
            re.I,
        ),
        re.compile(
            rf"(?ms)^\s{{0,2}}Child\s+Tag:\s+Record\s+\(Identifier:\s*{re.escape(stage_name)}\s*,.*?$.*?(?=^\s{{0,2}}Child\s+Tag:\s+Record\s+\(Identifier:|^\s{{0,2}}STAGE:\s*[^\n]+$|\Z)",
            re.I,
        ),
    ]
    for pattern in patterns:
        match = pattern.search(text)
        if match:
            return match.group(0)
    return ""
