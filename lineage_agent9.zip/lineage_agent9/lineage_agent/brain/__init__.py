"""
Lineage Agent Brain - Core Processing Engine

This module contains the unified brain of the lineage agent:
- Pipeline: 8-phase ETL lineage analysis engine
- Preprocessing: Input document parsing and chunking
- Methods: Orchestration and pipeline execution
- Utils: Utility functions and helpers
- Prompts: LLM prompt templates
"""

from lineage_agent.brain.methods import (
    build_prompt_preview,
    ensure_data_layout,
    healthcheck,
    preprocess_pseudocode,
    read_pseudocode_text,
    run_lineage_pipeline,
)
from lineage_agent.brain.pipeline import LayeredLineageAgent
from lineage_agent.brain.preprocessing import build_preprocessed_context
from lineage_agent.brain.utils import (
    DEFAULT_MAX_CHUNK_CHARS,
    extract_json,
    read_text,
    safe_name,
    timestamp,
    write_json,
    write_text,
)

__all__ = [
    # Main entry points
    "run_lineage_pipeline",
    "build_prompt_preview",
    "preprocess_pseudocode",
    "read_pseudocode_text",
    "ensure_data_layout",
    "healthcheck",
    # Core engine
    "LayeredLineageAgent",
    # Utilities
    "build_preprocessed_context",
    "DEFAULT_MAX_CHUNK_CHARS",
    "extract_json",
    "read_text",
    "safe_name",
    "timestamp",
    "write_json",
    "write_text",
]
