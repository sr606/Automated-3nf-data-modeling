from pathlib import Path
from typing import Any

from dotenv import load_dotenv

from lineage_agent.brain.prompts import (
    prompt_phase1,
    prompt_phase15,
    prompt_phase2,
    prompt_phase3,
    prompt_phase4,
    prompt_phase5,
    prompt_phase6,
    prompt_phase7,
)
from lineage_agent.brain.pipeline import run_pipeline
from lineage_agent.brain.preprocessing import build_preprocessed_context
from lineage_agent.brain.utils import DEFAULT_MAX_CHUNK_CHARS, read_text, safe_name


load_dotenv()


def ensure_data_layout() -> None:
    (Path("data") / "uploads").mkdir(parents=True, exist_ok=True)
    (Path("data") / "output").mkdir(parents=True, exist_ok=True)


def healthcheck() -> dict[str, Any]:
    ensure_data_layout()
    return {
        "status": "ok",
        "service": "lineage_mcp",
        "uploads_dir": str((Path("data") / "uploads").resolve()),
        "output_dir": str((Path("data") / "output").resolve()),
    }


def read_pseudocode_text(input_path: str) -> dict[str, Any]:
    ensure_data_layout()
    path = Path(input_path)
    text = read_text(path)
    return {
        "input_path": str(path),
        "file_name": path.name,
        "file_stem": safe_name(path.stem),
        "text": text,
        "char_count": len(text),
        "line_count": len(text.splitlines()),
    }


def preprocess_pseudocode(input_path: str, max_chunk_chars: int = DEFAULT_MAX_CHUNK_CHARS) -> dict[str, Any]:
    payload = read_pseudocode_text(input_path)
    preprocessed = build_preprocessed_context(payload["text"], max_chunk_chars)
    return {
        "input_path": payload["input_path"],
        "file_name": payload["file_name"],
        "max_chunk_chars": max_chunk_chars,
        "preprocessed_context": preprocessed,
        "chunk_count": len(preprocessed.get("chunks", [])),
    }


def build_prompt_preview(input_path: str, max_chunk_chars: int = DEFAULT_MAX_CHUNK_CHARS) -> dict[str, Any]:
    payload = preprocess_pseudocode(input_path=input_path, max_chunk_chars=max_chunk_chars)
    context = payload["preprocessed_context"]
    chunks = context.get("chunks", [])
    if not chunks:
        return {
            "input_path": payload["input_path"],
            "chunk_count": 0,
            "prompts": {},
            "warning": "No chunks were generated from the input pseudocode.",
        }

    first_chunk = chunks[0]
    phase1_stub = {
        "chunk_id": first_chunk.get("chunk_id"),
        "signals": [],
    }
    phase15_stub = {
        "dominant_pipeline": [],
        "strongest_source": "",
        "core_transform": "",
        "store_node": "",
        "target_node": "",
        "side_flows": [],
    }
    phase2_stub = {
        "anchor_chain": {},
        "nodes": [],
        "edges": [],
    }
    phase3_stub = {
        "anchor_chain_confirmed": {},
        "node_roles": {},
        "chains": [],
    }
    phase4_stub = {
        "normalized_components": [],
        "isolated_sub_flows": [],
    }
    phase5_stub = {
        "high_level_model": {"nodes": [], "lookup_edges": [], "exception_edges": [], "notes": [], "spine": []},
        "technical_model": {"nodes": [], "lookup_edges": [], "exception_edges": [], "secondary_edges": [], "notes": [], "spine": []},
    }
    phase6_stub = {"transform_semantics": []}
    document_text = context.get("document_text", "")

    return {
        "input_path": payload["input_path"],
        "chunk_count": payload["chunk_count"],
        "preview_chunk_id": first_chunk.get("chunk_id"),
        "prompts": {
            "phase1": prompt_phase1(context, first_chunk),
            "phase15": prompt_phase15(document_text, phase1_stub, context),
            "phase2": prompt_phase2(document_text, phase1_stub, phase15_stub),
            "phase3": prompt_phase3(phase2_stub, context),
            "phase4": prompt_phase4(phase2_stub, phase3_stub),
            "phase5": prompt_phase5(phase3_stub, phase4_stub),
            "phase6": prompt_phase6(document_text, phase3_stub, phase5_stub),
            "phase7": prompt_phase7(phase2_stub, phase3_stub, phase4_stub, phase5_stub, phase6_stub),
        },
    }


def run_lineage_pipeline(input_path: str, output_dir: str, model_override: str = "") -> dict[str, Any]:
    ensure_data_layout()
    return run_pipeline(input_path=input_path, output_dir=output_dir, model_override=model_override)
