import json
import re
import subprocess
from datetime import datetime
from pathlib import Path
from typing import Any


DEFAULT_MAX_CHUNK_CHARS = 6000


def timestamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def safe_name(value: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "_", str(value or "").strip())
    return cleaned.strip("._") or "lineage"


def read_text(path: Path) -> str:
    return Path(path).read_text(encoding="utf-8", errors="ignore")


def extract_json(text: str) -> Any:
    raw = str(text or "").strip()
    try:
        return json.loads(raw)
    except Exception:
        start = raw.find("{")
        end = raw.rfind("}")
        if start != -1 and end != -1 and end > start:
            try:
                return json.loads(raw[start : end + 1])
            except Exception:
                return {}
    return {}


def write_json(path: Path, payload: dict[str, Any]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(str(text or ""), encoding="utf-8")


def render_dot(dot_path: Path) -> dict[str, Any]:
    pdf_path = dot_path.with_suffix(".pdf")
    try:
        subprocess.run(
            ["dot", "-Tpdf", str(dot_path), "-o", str(pdf_path)],
            check=True,
            capture_output=True,
            text=True,
        )
        return {"pdf_generated": True, "pdf_path": str(pdf_path), "warning": ""}
    except Exception as exc:
        return {"pdf_generated": False, "pdf_path": "", "warning": str(exc)}
