import re
from collections import defaultdict


HEADER_PREFIXES = {
    "SOURCE_DEFINITION": "SOURCE_DEFINITION",
    "SOURCE_QUALIFIER": "SOURCE_QUALIFIER",
    "XML_SOURCE_QUALIFIER_TRANSFORMATION": "XML_SOURCE_QUALIFIER",
    "EXPRESSION": "EXPRESSION",
    "EXPRESSION_TRANSFORMATION": "EXPRESSION",
    "JOINER": "JOINER",
    "JOINER_TRANSFORMATION": "JOINER",
    "SORTER": "SORTER",
    "SORTER_TRANSFORMATION": "SORTER",
    "FILTER": "FILTER",
    "FILTER_TRANSFORMATION": "FILTER",
    "ROUTER": "ROUTER",
    "LOOKUP": "LOOKUP",
    "AGGREGATOR": "AGGREGATOR",
    "UNION": "UNION",
    "TARGET_DEFINITION": "TARGET_DEFINITION",
    "TRANSFORMATION": "TRANSFORMATION",
}

INPUT_REF_PATTERNS = (
    r"\bINPUT_LINK(?:_[A-Z0-9#]+|_\d+)?\s*:\s*([^\r\n]+)",
    r"\bInput_Link(?:_[A-Za-z0-9#]+|_\d+)?\s*:\s*([^\r\n]+)",
    r"\bInput Link(?: [A-Za-z0-9#]+| \d+)?\s*:\s*([^\r\n]+)",
)

OUTPUT_REF_PATTERNS = (
    r"\bOUTPUT_LINK(?:_[A-Z0-9#]+|_\d+)?\s*:\s*([^\r\n]+)",
    r"\bOutput_Link(?:_[A-Za-z0-9#]+|_\d+)?\s*:\s*([^\r\n]+)",
    r"\bOutput Link(?: [A-Za-z0-9#]+| \d+)?\s*:\s*([^\r\n]+)",
)

EXPLICIT_FLOW_LINE = re.compile(r"->")


def _scan_blocks(text):
    block_starts = []
    lines = text.splitlines()

    for index, line in enumerate(lines):
        stripped = line.strip()
        for prefix in HEADER_PREFIXES:
            if (stripped.startswith(f"{prefix}:") or stripped.startswith(f"{prefix} ")) and stripped.endswith(":"):
                block_starts.append((index, prefix))
                break

    blocks = []
    for pos, (start, prefix) in enumerate(block_starts):
        end = block_starts[pos + 1][0] if pos + 1 < len(block_starts) else len(lines)
        header_line = lines[start].strip()
        header_body = header_line[:-1].strip()
        if header_body.startswith(f"{prefix}:"):
            name = header_body.split(":", 1)[1].strip()
        else:
            name = header_body[len(prefix) :].strip()
        block_text = "\n".join(lines[start:end]).strip()
        blocks.append((prefix, name, block_text, start + 1, end))

    return blocks


def _resolve_block_name(prefix, header_name, block_text, line_start):
    name = str(header_name or "").strip()

    if name:
        return name

    field_patterns = {
        "SOURCE_DEFINITION": r"\bSource_Name:\s*([^\r\n]+)",
        "TARGET_DEFINITION": r"\bTarget_Name:\s*([^\r\n]+)",
    }

    pattern = field_patterns.get(prefix, r"\bTransformation_Name:\s*([^\r\n]+)")
    match = re.search(pattern, block_text)
    if match:
        extracted = match.group(1).strip()
        if extracted:
            return extracted

    return f"{prefix}_{line_start}"


def _stage_type_from_prefix(prefix):
    if prefix == "SOURCE_DEFINITION":
        return "SOURCE"
    if prefix == "TARGET_DEFINITION":
        return "TARGET"
    if "QUALIFIER" in prefix:
        return "SOURCE_QUALIFIER"
    return prefix


def _constraints_from_block(block_text):
    constraints = []
    patterns = (
        r"JOIN_CONDITION:\s*([^\r\n]+)",
        r"FILTER_CONDITION:\s*([^\r\n]+)",
        r"SOURCE_FILTER:\s*([^\r\n]+)",
        r"CRITERIA:\s*([^\r\n]+)",
        r"CONDITION:\s*([^\r\n]+)",
    )

    for pattern in patterns:
        for expression in re.findall(pattern, block_text):
            constraints.append({"link_name": "", "expression": expression.strip()})

    return constraints


def _sql_from_block(block_text):
    sql_matches = re.findall(
        r"(?:SQL STATEMENT|SQL|EXPRESSION_LOGIC):\s*([^\r\n].*?)(?=\n[A-Z_]+:|\Z)",
        block_text,
        re.S,
    )
    return [item.strip() for item in sql_matches if item.strip()]


def _split_refs(raw_value):
    if not raw_value:
        return []

    parts = re.split(r"\s*,\s*|\s*;\s*", raw_value.strip())
    return [part.strip() for part in parts if part.strip()]


def _normalize_ref_name(value):
    if not value:
        return ""

    cleaned = str(value).strip()
    cleaned = cleaned.strip('"')
    cleaned = re.sub(r"\s*\(.*?\)\s*", "", cleaned)
    cleaned = cleaned.rstrip(":")
    cleaned = cleaned.strip()

    prefix_match = re.match(r"^(?:From|To)_(.+)$", cleaned, re.I)
    if prefix_match:
        return prefix_match.group(1).strip()

    if cleaned.endswith("_OUTPUT"):
        return cleaned[:-7].strip()

    return cleaned


def _extract_input_output_refs(block_text):
    input_refs = []
    output_refs = []

    for pattern in INPUT_REF_PATTERNS:
        for raw in re.findall(pattern, block_text):
            input_refs.extend(_split_refs(raw))

    for pattern in OUTPUT_REF_PATTERNS:
        for raw in re.findall(pattern, block_text):
            output_refs.extend(_split_refs(raw))

    return input_refs, output_refs


def _extract_explicit_edges(text, known_nodes):
    edges = set()

    for line in text.splitlines():
        stripped = line.strip()
        if not EXPLICIT_FLOW_LINE.search(stripped):
            continue

        arrow_free = re.sub(r"^[A-Z0-9_]+:\s*", "", stripped)
        segments = [item.strip() for item in arrow_free.split("->") if item.strip()]
        if len(segments) < 2:
            continue

        normalized = [_normalize_ref_name(item) for item in segments]
        for source, target in zip(normalized, normalized[1:]):
            if source in known_nodes and target in known_nodes:
                edges.add((source, target))

    return edges


def _resolve_direct_refs(node_map):
    edges = set()
    known_nodes = set(node_map)

    for name, meta in node_map.items():
        for ref in meta["input_refs"]:
            source = _normalize_ref_name(ref)
            if source in known_nodes and source != name:
                edges.add((source, name))

        for ref in meta["output_refs"]:
            target = _normalize_ref_name(ref)
            if target in known_nodes and target != name:
                edges.add((name, target))

    return edges


def _resolve_link_refs(node_map):
    producers = defaultdict(set)
    consumers = defaultdict(set)

    for name, meta in node_map.items():
        for ref in meta["output_refs"]:
            normalized = _normalize_ref_name(ref)
            if normalized and normalized not in node_map:
                producers[normalized].add(name)

        for ref in meta["input_refs"]:
            normalized = _normalize_ref_name(ref)
            if normalized and normalized not in node_map:
                consumers[normalized].add(name)

    edges = set()
    for link_name, source_names in producers.items():
        for source_name in source_names:
            for target_name in consumers.get(link_name, set()):
                if source_name != target_name:
                    edges.add((source_name, target_name))

    return edges


def parse_informatica_jobs(jobs):
    stages = []

    for job in jobs:
        source_file = job.get("source_file", "lineage")
        text = job.get("content", "")
        blocks = _scan_blocks(text)
        node_map = {}

        for prefix, name, block_text, line_start, line_end in blocks:
            resolved_name = _resolve_block_name(prefix, name, block_text, line_start)
            input_refs, output_refs = _extract_input_output_refs(block_text)
            node_map[resolved_name] = {
                "source_file": source_file,
                "parser_type": "informatica",
                "stage": resolved_name,
                "type": "TRANSFORM",
                "stage_kind": prefix,
                "stage_type": _stage_type_from_prefix(prefix),
                "line_start": line_start,
                "line_end": line_end,
                "inputs": [],
                "outputs": [],
                "sql": _sql_from_block(block_text),
                "constraints": _constraints_from_block(block_text),
                "input_refs": input_refs,
                "output_refs": output_refs,
            }

        edges = set()
        edges.update(_resolve_direct_refs(node_map))
        edges.update(_resolve_link_refs(node_map))
        edges.update(_extract_explicit_edges(text, set(node_map)))

        inbound = defaultdict(list)
        outbound = defaultdict(list)

        for index, (source, target) in enumerate(sorted(edges), start=1):
            dataset_id = f"dataset_inf_{index}"
            outbound[source].append({"dataset_id": dataset_id, "alias": target, "link_name": ""})
            inbound[target].append({"dataset_id": dataset_id, "alias": source, "link_name": ""})

        for name, stage in node_map.items():
            stage["inputs"] = inbound.get(name, [])
            stage["outputs"] = outbound.get(name, [])
            stage.pop("input_refs", None)
            stage.pop("output_refs", None)
            stages.append(stage)

    return stages
