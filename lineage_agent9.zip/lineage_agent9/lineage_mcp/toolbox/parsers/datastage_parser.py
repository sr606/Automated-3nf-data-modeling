import re


def _normalize_arrow_text(text):
    if not text:
        return ""

    return (
        text.replace("ÃƒÂ¢Ã¢â‚¬Â Ã‚Â", "\u2190")
        .replace("ÃƒÂ¢Ã¢â‚¬Â Ã¢â‚¬â„¢", "\u2192")
        .replace("Ã¢â€ Â", "\u2190")
        .replace("Ã¢â€ â€™", "\u2192")
    )


def _extract_stage_header(block):
    match = re.search(
        r"//\s*---\s*\[(.*?)\s*:\s*(.*?)\](?:\s*\[Lines\s*(\d+)-(\d+)\])?",
        block,
    )

    if not match:
        return None

    return {
        "kind": match.group(1).strip(),
        "stage": match.group(2).strip(),
        "line_start": int(match.group(3)) if match.group(3) else 0,
        "line_end": int(match.group(4)) if match.group(4) else 0,
    }


def _extract_link_entries(block, direction):
    pattern = (
        rf"{direction}:\s*[←→]\s*(dataset_\d+)"
        rf"(?:\s*\(([^)]+)\))?"
        rf"(?:\s*\(Link:\s*([^)]+)\))?"
    )

    entries = []
    for dataset_id, alias, link_name in re.findall(pattern, block):
        entries.append(
            {
                "dataset_id": dataset_id.strip(),
                "alias": (alias or "").strip(),
                "link_name": (link_name or "").strip(),
            }
        )

    return entries


def _extract_stage_type(block):
    match = re.search(r"StageType:\s*([^\r\n]+)", block)
    return match.group(1).strip() if match else ""


def _extract_sql_block(block):
    match = re.search(
        r"SQL:\s*(.*?)(?=\n\s*(?:Input|Output|StageType|Transformations|Constraint|Link File|UnixFormat|PipeStage|UnicodeBOM|UnicodeSwapped|WithFilter):|\Z)",
        block,
        re.S,
    )
    return match.group(1).strip() if match else ""


def _extract_constraints(block):
    constraints = []

    for link_name, expression in re.findall(r"Constraint\s*\(([^)]+)\):\s*([^\r\n]+)", block):
        constraints.append(
            {
                "link_name": link_name.strip(),
                "expression": expression.strip(),
            }
        )

    return constraints


def parse_datastage_jobs(jobs):
    stages = []

    for job in jobs:
        source_file = job.get("source_file", "lineage")
        job_text = _normalize_arrow_text(job.get("content", ""))

        stage_blocks = re.findall(
            r"(//\s*---\s*\[.*?\](?:.*?))(?=//\s*---\s*\[|\Z)",
            job_text,
            re.S,
        )

        for block in stage_blocks:
            header = _extract_stage_header(block)
            if not header:
                continue

            sql = _extract_sql_block(block)
            stages.append(
                {
                    "source_file": source_file,
                    "parser_type": "datastage",
                    "stage": header["stage"],
                    "type": "TRANSFORM",
                    "stage_kind": header["kind"],
                    "stage_type": _extract_stage_type(block),
                    "line_start": header["line_start"],
                    "line_end": header["line_end"],
                    "inputs": _extract_link_entries(block, "Input"),
                    "outputs": _extract_link_entries(block, "Output"),
                    "sql": [sql] if sql else [],
                    "constraints": _extract_constraints(block),
                }
            )

    return stages
