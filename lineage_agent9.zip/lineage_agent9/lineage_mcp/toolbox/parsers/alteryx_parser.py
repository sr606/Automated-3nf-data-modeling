import re
from collections import defaultdict


HEADER_PATTERN = re.compile(
    r"//\s*---\s*(.*?)\s*\(ID:\s*(\d+),\s*([^)]+)\)\s*\[Lines\s*(\d+)-(\d+)\]\s*---(.*?)(?=//\s*---|\Z)",
    re.S,
)

SOURCE_KINDS = {"DbFileInput", "TextInput", "InputData", "DynamicInput"}
SINK_KINDS = {"DbFileOutput", "BrowseV2", "OutputData", "Render"}
MERGE_KINDS = {"Join", "Union", "JoinMultiple"}


def _collect_constraints(block):
    constraints = []

    for label in ("CRITERIA", "FILTER_CONDITION", "CONDITION"):
        for expression in re.findall(rf"{label}:\s*([^\r\n]+)", block):
            constraints.append({"link_name": "", "expression": expression.strip()})

    return constraints


def _collect_sql(block):
    sql = []
    for statement in re.findall(r"\[SQL STATEMENT\]:\s*([^\r\n]+)", block):
        sql.append(statement.strip())
    return sql


def _group_key(stage_name):
    tokens = re.findall(r"[A-Za-z]+", stage_name)
    if not tokens:
        return "default"

    stop_words = {
        "browse",
        "data",
        "db",
        "xls",
        "csv",
        "sp",
        "summary",
        "analytics",
        "calculate",
        "clean",
        "sort",
        "filter",
        "join",
        "value",
        "score",
        "profit",
        "margin",
        "field",
        "high",
        "performance",
        "stock",
        "status",
        "segment",
        "category",
    }
    for token in tokens:
        lower = token.lower()
        if lower not in stop_words:
            return lower

    return None


def _add_edge(node_map, edges, source, target):
    if source not in node_map or target not in node_map or source == target:
        return
    edges.add((source, target))


def _explicit_edges(text, node_map):
    edges = set()

    for line in text.splitlines():
        stripped = line.strip()
        if "->" not in stripped:
            continue

        arrow_free = re.sub(r"^[A-Z0-9_]+:\s*", "", stripped)
        segments = [item.strip() for item in arrow_free.split("->") if item.strip()]
        if len(segments) < 2:
            continue

        for source, target in zip(segments, segments[1:]):
            _add_edge(node_map, edges, source, target)

    return edges


def _fallback_edges(grouped_names, node_map):
    edges = set()

    for names in grouped_names.values():
        ordered = sorted(names, key=lambda item: node_map[item]["_sort_key"])
        if len(ordered) < 2:
            continue

        merge_index = next(
            (index for index, name in enumerate(ordered) if node_map[name]["stage_kind"] in MERGE_KINDS),
            None,
        )

        if merge_index is not None:
            merge_name = ordered[merge_index]
            upstream = ordered[:merge_index]
            downstream = ordered[merge_index + 1 :]

            source_like = [name for name in upstream if node_map[name]["stage_kind"] in SOURCE_KINDS]
            if source_like:
                for source_name in source_like:
                    _add_edge(node_map, edges, source_name, merge_name)

                non_sources = [name for name in upstream if name not in source_like]
                for source_name, target_name in zip(non_sources, non_sources[1:]):
                    _add_edge(node_map, edges, source_name, target_name)
                if non_sources:
                    _add_edge(node_map, edges, non_sources[-1], merge_name)
            else:
                for source_name, target_name in zip(upstream, upstream[1:]):
                    _add_edge(node_map, edges, source_name, target_name)
                if upstream:
                    _add_edge(node_map, edges, upstream[-1], merge_name)

            current = merge_name
            tail_non_sinks = [name for name in downstream if node_map[name]["stage_kind"] not in SINK_KINDS]
            tail_sinks = [name for name in downstream if node_map[name]["stage_kind"] in SINK_KINDS]

            for name in tail_non_sinks:
                _add_edge(node_map, edges, current, name)
                current = name

            for sink_name in tail_sinks:
                _add_edge(node_map, edges, current, sink_name)

            continue

        non_sinks = [name for name in ordered if node_map[name]["stage_kind"] not in SINK_KINDS]
        sinks = [name for name in ordered if node_map[name]["stage_kind"] in SINK_KINDS]

        for source_name, target_name in zip(non_sinks, non_sinks[1:]):
            _add_edge(node_map, edges, source_name, target_name)

        if non_sinks:
            current = non_sinks[-1]
            for sink_name in sinks:
                _add_edge(node_map, edges, current, sink_name)
        else:
            for source_name, target_name in zip(ordered, ordered[1:]):
                _add_edge(node_map, edges, source_name, target_name)

    return edges


def _bridge_orphan_steps(edges, ordered_stage_names, node_map):
    """
    Insert orphan transforms between an existing direct source-to-sink edge when line order strongly suggests it.
    """

    incoming = defaultdict(set)
    outgoing = defaultdict(set)

    for source, target in edges:
        outgoing[source].add(target)
        incoming[target].add(source)

    orphans = [
        name
        for name in ordered_stage_names
        if not incoming.get(name) and not outgoing.get(name) and node_map[name]["stage_kind"] not in SOURCE_KINDS | SINK_KINDS
    ]

    mutable_edges = set(edges)

    for orphan in orphans:
        orphan_line = node_map[orphan]["_sort_key"][0]
        source_candidates = [
            name
            for name in ordered_stage_names
            if node_map[name]["stage_kind"] in SOURCE_KINDS and node_map[name]["_sort_key"][0] < orphan_line
        ]
        sink_candidates = [
            name
            for name in ordered_stage_names
            if node_map[name]["stage_kind"] in SINK_KINDS and node_map[name]["_sort_key"][0] > orphan_line
        ]

        if not source_candidates or not sink_candidates:
            continue

        source_name = source_candidates[-1]
        sink_name = sink_candidates[0]

        if (source_name, sink_name) not in mutable_edges:
            continue

        mutable_edges.remove((source_name, sink_name))
        mutable_edges.add((source_name, orphan))
        mutable_edges.add((orphan, sink_name))

    return mutable_edges


def parse_alteryx_jobs(jobs):
    stages = []

    for job in jobs:
        source_file = job.get("source_file", "lineage")
        text = job.get("content", "")
        matches = list(HEADER_PATTERN.finditer(text))

        if not matches:
            continue

        node_map = {}
        ordered_stage_names = []

        for match in matches:
            stage_name = match.group(1).strip()
            stage_id = match.group(2).strip()
            stage_kind = match.group(3).strip()
            line_start = int(match.group(4))
            line_end = int(match.group(5))
            block = match.group(0)

            node_map[stage_name] = {
                "source_file": source_file,
                "parser_type": "alteryx",
                "stage": stage_name,
                "type": "TRANSFORM",
                "stage_kind": stage_kind,
                "stage_type": stage_kind,
                "line_start": line_start,
                "line_end": line_end,
                "inputs": [],
                "outputs": [],
                "sql": _collect_sql(block),
                "constraints": _collect_constraints(block),
                "_sort_key": (line_start, int(stage_id)),
                "_group_key": _group_key(stage_name),
            }
            ordered_stage_names.append(stage_name)

        ordered_stage_names.sort(key=lambda item: node_map[item]["_sort_key"])

        active_group = None
        for stage_name in ordered_stage_names:
            if node_map[stage_name]["_group_key"]:
                active_group = node_map[stage_name]["_group_key"]
            elif active_group:
                node_map[stage_name]["_group_key"] = active_group

        active_group = None
        for stage_name in reversed(ordered_stage_names):
            if node_map[stage_name]["_group_key"]:
                active_group = node_map[stage_name]["_group_key"]
            elif active_group:
                node_map[stage_name]["_group_key"] = active_group

        grouped = defaultdict(list)
        for stage_name in ordered_stage_names:
            grouped[node_map[stage_name]["_group_key"] or "default"].append(stage_name)

        edges = _explicit_edges(text, node_map)
        if not edges:
            edges = _fallback_edges(grouped, node_map)
            edges = _bridge_orphan_steps(edges, ordered_stage_names, node_map)

        inbound = defaultdict(list)
        outbound = defaultdict(list)

        for index, (source, target) in enumerate(sorted(edges), start=1):
            dataset_id = f"dataset_alt_{index}"
            outbound[source].append({"dataset_id": dataset_id, "alias": target, "link_name": ""})
            inbound[target].append({"dataset_id": dataset_id, "alias": source, "link_name": ""})

        for stage_name, stage in sorted(node_map.items(), key=lambda item: item[1]["_sort_key"]):
            stage["inputs"] = inbound.get(stage_name, [])
            stage["outputs"] = outbound.get(stage_name, [])
            stage.pop("_sort_key", None)
            stage.pop("_group_key", None)
            stages.append(stage)

    return stages
