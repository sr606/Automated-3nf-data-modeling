import re
import subprocess
from dataclasses import dataclass
from datetime import datetime
from pathlib import Path
from typing import Any

from lineage_mcp.toolbox.methods import (
    build_chunks_dict,
    build_node_chunk_map,
    generate_batch_graphviz_code,
    generate_full_graphviz_hierarchical,
    generate_graphviz_code_one_by_one_chunk,
    generate_high_level_graph,
    generate_technical_graph,
)


DEFAULT_MAX_CHUNK_CHARS = 100


def timestamp() -> str:
    return datetime.now().strftime("%Y%m%d_%H%M%S")


def safe_name(value: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "_", str(value or "").strip())
    return cleaned.strip("._") or "lineage"


def read_text(path: Path) -> str:
    return Path(path).read_text(encoding="utf-8", errors="ignore")


def write_text(path: Path, text: str) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(str(text or ""), encoding="utf-8")


def _strip_code_fences(text: str) -> str:
    raw = str(text or "").strip()
    if not raw.startswith("```"):
        return raw

    lines = raw.splitlines()
    if lines and lines[0].strip().startswith("```"):
        lines = lines[1:]
    if lines and lines[-1].strip() == "```":
        lines = lines[:-1]
    return "\n".join(lines).strip()


def render_dot(dot_path: Path) -> dict[str, Any]:
    pdf_path = dot_path.with_suffix(".pdf")
    try:
        original_text = Path(dot_path).read_text(encoding="utf-8", errors="ignore")
        sanitized_text = _strip_code_fences(original_text)
        if sanitized_text != original_text.strip():
            Path(dot_path).write_text(sanitized_text, encoding="utf-8")
        subprocess.run(
            ["dot", "-Tpdf", str(dot_path), "-o", str(pdf_path)],
            check=True,
            capture_output=True,
            text=True,
        )
        return {"pdf_generated": True, "pdf_path": str(pdf_path), "warning": ""}
    except Exception as exc:
        return {"pdf_generated": False, "pdf_path": "", "warning": str(exc)}


@dataclass
class AgentConfig:
    input_path: str
    output_dir: str
    model_override: str = ""
    max_chunk_chars: int = DEFAULT_MAX_CHUNK_CHARS


@dataclass
class AgentContext:
    input_file: str
    document_text: str
    preprocessed_context: dict[str, Any]
    run_id: str
    run_dir: str


class LayeredLineageAgent:
    def __init__(self, config: AgentConfig):
        self.config = config

    def run(self) -> dict[str, Any]:
        context = self._build_agent_context()
        run_dir = Path(context.run_dir)

        chunks_dict = build_chunks_dict(context.preprocessed_context)

        per_chunk_graphviz = generate_graphviz_code_one_by_one_chunk(chunks_dict, model_override=self.config.model_override)
        batch_graphviz = generate_batch_graphviz_code(per_chunk_graphviz, model_override=self.config.model_override)
        final_graphviz = generate_full_graphviz_hierarchical(batch_graphviz, model_override=self.config.model_override)
        final_graphviz = self._ensure_dot_wrapper(final_graphviz)
        node_chunk_map = build_node_chunk_map(chunks_dict, per_chunk_graphviz)
        high_level_graphviz = generate_high_level_graph(final_graphviz, model_override=self.config.model_override)
        high_level_graphviz = self._ensure_dot_wrapper(high_level_graphviz)
        technical_graphviz = generate_technical_graph(
            high_level_graphviz,
            node_chunk_map,
            model_override=self.config.model_override,
        )
        technical_graphviz = self._ensure_dot_wrapper(technical_graphviz)

        technical_dot_path = run_dir / "technical.dot"
        high_level_dot_path = run_dir / "high_level.dot"

        write_text(technical_dot_path, technical_graphviz)
        write_text(high_level_dot_path, high_level_graphviz)

        pdf_outputs = {
            "high_level": render_dot(high_level_dot_path),
            "technical": render_dot(technical_dot_path),
        }
        return self._build_result(
            context=context,
            dot_files=[
                str(high_level_dot_path),
                str(technical_dot_path),
            ],
            pdf_outputs=pdf_outputs,
        )

    def _build_agent_context(self) -> AgentContext:
        input_file = Path(self.config.input_path)
        document_text = read_text(input_file)
        preprocessed_context = build_preprocessed_context(document_text, self.config.max_chunk_chars)
        run_id = f"{safe_name(input_file.stem)}_{timestamp()}"
        run_dir = Path(self.config.output_dir) / run_id
        return AgentContext(
            input_file=str(input_file),
            document_text=document_text,
            preprocessed_context=preprocessed_context,
            run_id=run_id,
            run_dir=str(run_dir),
        )

    def _ensure_dot_wrapper(self, dot_text: str) -> str:
        text = _strip_code_fences(str(dot_text or ""))
        if not text:
            return "digraph G {\n  rankdir=LR;\n}"
        normalized = text.lstrip()
        if not normalized.lower().startswith("digraph") or "{" not in normalized or "}" not in normalized:
            return "digraph G {\n  rankdir=LR;\n" + text + "\n}"
        return text

    def _build_result(
        self,
        context: AgentContext,
        dot_files: list[str],
        pdf_outputs: dict[str, dict[str, Any]],
    ) -> dict[str, Any]:
        warnings = [
            warning
            for warning in [
                str(details.get("warning") or "").strip()
                for details in pdf_outputs.values()
                if isinstance(details, dict)
            ]
            if warning
        ]
        pdf_files = [
            str(details.get("pdf_path") or "").strip()
            for details in pdf_outputs.values()
            if isinstance(details, dict) and str(details.get("pdf_path") or "").strip()
        ]

        return {
            "agent_name": "LayeredLineageAgent",
            "run_id": context.run_id,
            "input_file": context.input_file,
            "run_dir": context.run_dir,
            "output_dir": context.run_dir,
            "chunk_count": len(context.preprocessed_context.get("chunks", [])),
            "dot_files": dot_files,
            "pdf_files": pdf_files,
            "pdf_generated": any(bool(details.get("pdf_generated")) for details in pdf_outputs.values()),
            "warnings": warnings,
        }


def run_pipeline(input_path: str, output_dir: str, model_override: str = "") -> dict[str, Any]:
    config = AgentConfig(input_path=input_path, output_dir=output_dir, model_override=model_override)
    return LayeredLineageAgent(config).run()


DEFAULT_MAX_CHARS = 7000
SAFE_SQL_SPLITS = [
    r"\nFROM ",
    r"\nLEFT OUTER JOIN ",
    r"\nINNER JOIN ",
    r"\nWHERE ",
    r"\nGROUP BY ",
    r"\nORDER BY ",
]


def split_into_stages(text: str) -> list[dict[str, str]]:
    """Split the full ETL export into stage and flow-oriented blocks."""
    normalized = str(text or "")
    if not normalized.strip():
        return []

    blocks: list[dict[str, str]] = []
    current_lines: list[str] = []
    current_block_type = "metadata"

    def flush() -> None:
        nonlocal current_lines, current_block_type
        text_block = "\n".join(current_lines).strip()
        current_lines = []
        if not text_block:
            return
        stage_name = (
            extract_stage_name(text_block)
            if current_block_type == "stage"
            else _extract_non_stage_name(text_block, current_block_type)
        )
        blocks.append(
            {
                "block_type": current_block_type,
                "stage_name": stage_name,
                "text": text_block,
            }
        )

    for raw_line in normalized.splitlines():
        line = str(raw_line or "")
        stripped = line.strip()
        if re.match(r"^STAGE:\s*", stripped, re.I):
            flush()
            current_block_type = "stage"
        elif re.match(r"^EXECUTION_FLOW:\s*$", stripped, re.I):
            flush()
            current_block_type = "execution_flow"
        elif re.match(r"^DATA_FLOW_SUMMARY:\s*$", stripped, re.I):
            flush()
            current_block_type = "data_flow"
        elif re.match(r"^(STAGES_SUMMARY|LINKS_SUMMARY|PARENT_CHILD_HIERARCHY):\s*$", stripped, re.I):
            flush()
            current_block_type = "metadata"
        current_lines.append(line)

    flush()
    return blocks


def extract_stage_name(stage_text: str) -> str:
    """Extract a stage name from a stage block."""
    match = re.search(r"(?mi)^\s*STAGE:\s*([^\n]+)", str(stage_text or ""))
    return match.group(1).strip() if match else "DOCUMENT_PREAMBLE"


def semantic_split(stage_text: str, max_chars: int = DEFAULT_MAX_CHARS) -> list[str]:
    """Split large stages using safe SQL boundaries and protected regions."""
    sample = str(stage_text or "").strip()
    if not sample:
        return []
    if len(sample) <= max_chars:
        return [sample]

    boundaries = _find_safe_sql_boundaries(sample)
    if not boundaries:
        return _fallback_hard_split(sample, max_chars)

    chunks: list[str] = []
    start = 0
    index = 0

    while start < len(sample):
        if len(sample) - start <= max_chars:
            chunks.append(sample[start:].strip())
            break

        candidate_end = None
        while index < len(boundaries) and boundaries[index] - start <= max_chars:
            candidate_end = boundaries[index]
            index += 1

        if candidate_end is None or candidate_end <= start:
            fallback_end = _nearest_newline(sample, start + max_chars)
            if fallback_end <= start:
                fallback_end = min(len(sample), start + max_chars)
            chunks.append(sample[start:fallback_end].strip())
            start = fallback_end
            continue

        chunks.append(sample[start:candidate_end].strip())
        start = candidate_end

    return [chunk for chunk in chunks if chunk]


def chunk_stage(block: dict[str, str], max_chars: int = DEFAULT_MAX_CHARS) -> list[dict[str, str]]:
    """Chunk one block and label the resulting chunk type."""
    sample = str(block.get("text") or "").strip()
    if not sample:
        return []

    block_type = str(block.get("block_type") or "metadata")
    chunk_type = _chunk_type_for_block(block_type, sample)

    if block_type != "stage":
        return [{"text": sample, "chunk_type": chunk_type, "block_type": block_type}]

    if len(sample) <= max_chars:
        return [{"text": sample, "chunk_type": chunk_type, "block_type": block_type}]

    return [
        {"text": chunk, "chunk_type": chunk_type, "block_type": block_type}
        for chunk in semantic_split(sample, max_chars=max_chars)
    ]


def generate_chunks(text: str, max_chars: int = DEFAULT_MAX_CHARS) -> list[dict[str, Any]]:
    """Generate validated stage-aware chunks from the input document."""
    stages = split_into_stages(text)
    all_chunks: list[dict[str, Any]] = []

    for block in stages:
        stage_name = str(block.get("stage_name") or "DOCUMENT_PREAMBLE")
        stage_chunks = chunk_stage(block, max_chars=max_chars)
        total_chunks = len(stage_chunks)

        for idx, chunk in enumerate(stage_chunks, start=1):
            all_chunks.append(
                {
                    "chunk_id": f"{_safe_name(stage_name).lower()}_chunk_{idx}",
                    "stage_name": stage_name,
                    "block_type": str(chunk.get("block_type") or block.get("block_type") or "metadata"),
                    "chunk_type": str(chunk.get("chunk_type") or "metadata"),
                    "chunk_index": idx,
                    "total_chunks_in_stage": total_chunks,
                    "text": str(chunk.get("text") or ""),
                }
            )

        if len(stage_chunks) != total_chunks:
            raise ValueError(f"Chunk mismatch in {stage_name}")

    validate_chunks(all_chunks)
    return all_chunks


def validate_chunks(chunks: list[dict[str, Any]]) -> None:
    """Ensure every stage has the expected number of generated chunks."""
    stage_map: dict[str, list[dict[str, Any]]] = {}
    for chunk in chunks:
        stage_name = str(chunk.get("stage_name") or "UNKNOWN")
        stage_map.setdefault(stage_name, []).append(chunk)

    for stage_name, items in stage_map.items():
        expected = int(items[0].get("total_chunks_in_stage") or 0)
        actual = len(items)
        if expected != actual:
            raise ValueError(f"Missing chunks in {stage_name}: expected {expected}, got {actual}")


def build_preprocessed_context(text: str, max_chunk_chars: int) -> dict[str, Any]:
    """Build the preprocessing artifact consumed by the pipeline and prompt layer."""
    document_text = str(text or "")
    chunk_limit = max(500, int(max_chunk_chars or DEFAULT_MAX_CHARS))
    chunks = generate_chunks(document_text, max_chars=chunk_limit)
    blocks = split_into_stages(document_text)
    stage_names = _dedupe_strings(
        [str(block.get("stage_name") or "") for block in blocks if str(block.get("block_type") or "") == "stage"]
    )

    return {
        "job_name_hints": job_name_hints(document_text),
        "stage_name_hints": stage_names,
        "stage_catalog": [{"name": name, "stage_type": ""} for name in stage_names if name != "DOCUMENT_PREAMBLE"],
        "link_flow_hints": parse_link_flow_hints(document_text),
        "execution_flow_hints": parse_execution_flow_hints(document_text),
        "target_table_hints": target_table_hints(document_text),
        "annotation_hints": annotation_hints(document_text),
        "chunks": chunks,
        "stage_splits": [
            {
                "stage_name": str(chunk.get("stage_name") or ""),
                "chunk_id": str(chunk.get("chunk_id") or ""),
                "block_type": str(chunk.get("block_type") or ""),
                "chunk_type": str(chunk.get("chunk_type") or ""),
                "chunk_index": int(chunk.get("chunk_index") or 0),
                "total_chunks_in_stage": int(chunk.get("total_chunks_in_stage") or 0),
                "char_count": len(str(chunk.get("text") or "")),
            }
            for chunk in chunks
        ],
        "blocks": blocks,
        "document_stats": {
            "char_count": len(document_text),
            "line_count": len(document_text.splitlines()),
            "stage_count": len([block for block in blocks if str(block.get("block_type") or "") == "stage"]),
            "block_count": len(blocks),
            "chunk_count": len(chunks),
            "max_chunk_chars": chunk_limit,
        },
    }


def parse_link_flow_hints(text: str) -> list[dict[str, Any]]:
    hints: list[dict[str, Any]] = []
    for raw_line in str(text or "").splitlines():
        line = str(raw_line or "").strip().rstrip(",")
        if "->" not in line:
            continue
        parts = [part.strip() for part in re.split(r"\s*->\s*", line) if part.strip()]
        if len(parts) < 2:
            continue
        hints.append(
            {
                "path": parts,
                "from": parts[0],
                "to": parts[-1],
                "intermediate": parts[1:-1],
                "raw": line,
            }
        )
    return hints


def parse_execution_flow_hints(text: str) -> dict[str, list[dict[str, Any]]]:
    hints: dict[str, list[dict[str, Any]]] = {}
    current_section = ""
    for raw_line in str(text or "").splitlines():
        line = str(raw_line or "").strip()
        if not line:
            continue
        section_match = re.match(r"^\d+\.\s*([A-Z_]+)\s*:\s*$", line)
        if section_match:
            current_section = section_match.group(1).lower()
            hints.setdefault(current_section, [])
            continue
        if current_section and line.startswith("-"):
            item_text = line.lstrip("-").strip()
            hints[current_section].append(
                {
                    "text": item_text,
                    "stages": re.findall(r"\b[A-Za-z][A-Za-z0-9_]*\b", item_text)[:10],
                }
            )
    return hints


def job_name_hints(text: str) -> list[str]:
    patterns = (
        r'Job_Name\s*=\s*"([^"]+)"',
        r'JOB_NAME\s*=\s*"([^"]+)"',
        r"JOB_START:\s*([^\n]+)",
        r"(?m)^\s*JOB:\s*([^\n]+?)\s*$",
    )
    hints: list[str] = []
    for pattern in patterns:
        for match in re.findall(pattern, str(text or ""), re.I):
            value = str(match).strip()
            if value and value not in hints:
                hints.append(value)
    return hints


def target_table_hints(text: str) -> list[str]:
    hints: list[str] = []
    patterns = (
        r'(?m)^\s*(?:TARGET_TABLE|Target_Table|TableName)\s*[:=]\s*([^\n]+)$',
        r"TRUNCATE TABLE\s+([A-Za-z0-9_.]+)",
    )
    for pattern in patterns:
        for match in re.findall(pattern, str(text or ""), re.I):
            value = str(match).strip().strip('"')
            if value and value not in hints:
                hints.append(value)
    return hints


def annotation_hints(text: str) -> list[str]:
    hints: list[str] = []
    patterns = (
        r'annotation_name\s*=\s*"([^"]+)"',
        r'description\s*=\s*"([^"]+)"',
        r'target_table\s*=\s*"([^"]+)"',
    )
    for pattern in patterns:
        for match in re.findall(pattern, str(text or ""), re.I):
            value = str(match).strip()
            if value and value not in hints:
                hints.append(value)
    return hints


def _dedupe_strings(values: list[str]) -> list[str]:
    results: list[str] = []
    for value in values:
        item = str(value or "").strip()
        if item and item not in results:
            results.append(item)
    return results


def _safe_name(value: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9_]+", "_", str(value or "").strip())
    cleaned = re.sub(r"_+", "_", cleaned).strip("_")
    return cleaned or "chunk"


def _extract_non_stage_name(text: str, block_type: str) -> str:
    first_line = str(text or "").splitlines()[0].strip() if str(text or "").splitlines() else ""
    if first_line.endswith(":"):
        return first_line[:-1].strip() or block_type.upper()
    return block_type.upper()


def _chunk_type_for_block(block_type: str, text: str) -> str:
    normalized = str(block_type or "").strip().lower()
    sample = str(text or "")
    if normalized == "execution_flow":
        return "flow"
    if normalized == "data_flow":
        return "flow"
    if normalized == "metadata":
        return "metadata"
    if re.search(r"\bSELECT\b", sample, re.I):
        return "sql"
    if re.search(r"\b(MAP|DERIVATION|TRANSFORMATION_LOGIC|STAGE_VARIABLES|CASE WHEN)\b", sample, re.I):
        return "transformation"
    return "stage"


def _find_safe_sql_boundaries(text: str) -> list[int]:
    boundaries: list[int] = []
    upper_text = text.upper()
    for pattern in SAFE_SQL_SPLITS:
        regex = re.compile(pattern, re.I)
        for match in regex.finditer(text):
            index = match.start()
            if _is_inside_case_when(upper_text, index):
                continue
            if _is_inside_join_on(upper_text, index):
                continue
            boundaries.append(index)
    return sorted(set(boundaries))


def _is_inside_case_when(upper_text: str, index: int) -> bool:
    before = upper_text[:index]
    case_count = len(re.findall(r"\bCASE\b", before))
    end_count = len(re.findall(r"\bEND\b", before))
    return case_count > end_count


def _is_inside_join_on(upper_text: str, index: int) -> bool:
    join_pos = upper_text.rfind(" JOIN ", 0, index)
    outer_join_pos = upper_text.rfind("LEFT OUTER JOIN ", 0, index)
    inner_join_pos = upper_text.rfind("INNER JOIN ", 0, index)
    join_pos = max(join_pos, outer_join_pos, inner_join_pos)
    if join_pos == -1:
        return False
    on_pos = upper_text.find(" ON ", join_pos, index)
    if on_pos == -1:
        return False
    next_join_candidates = [
        pos for pos in (
            upper_text.find(" LEFT OUTER JOIN ", on_pos + 1, index),
            upper_text.find(" INNER JOIN ", on_pos + 1, index),
            upper_text.find(" JOIN ", on_pos + 1, index),
            upper_text.find("\nWHERE ", on_pos + 1, index),
            upper_text.find("\nGROUP BY ", on_pos + 1, index),
            upper_text.find("\nORDER BY ", on_pos + 1, index),
        )
        if pos != -1
    ]
    return not next_join_candidates


def _nearest_newline(text: str, index: int) -> int:
    if index >= len(text):
        return len(text)
    forward = text.find("\n", index)
    return forward if forward != -1 else len(text)


def _fallback_hard_split(text: str, max_chars: int) -> list[str]:
    chunks: list[str] = []
    start = 0
    while start < len(text):
        end = _nearest_newline(text, start + max_chars)
        if end <= start:
            end = min(len(text), start + max_chars)
        chunks.append(text[start:end].strip())
        start = end
    return [chunk for chunk in chunks if chunk]
