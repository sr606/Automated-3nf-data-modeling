import os
from pathlib import Path
from typing import Any
import re

import httpx
from dotenv import load_dotenv

DEFAULT_MAX_CHUNK_CHARS = 100


def safe_name(value: str) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "_", str(value or "").strip())
    return cleaned.strip("._") or "lineage"


def read_text(path: Path) -> str:
    return Path(path).read_text(encoding="utf-8", errors="ignore")

try:
    from langchain_openai import AzureChatOpenAI
except ImportError:
    AzureChatOpenAI = None


load_dotenv()

DATA_DIR = Path(__file__).resolve().parents[1] / "data"


def ensure_data_layout() -> None:
    (DATA_DIR / "uploads").mkdir(parents=True, exist_ok=True)
    (DATA_DIR / "output").mkdir(parents=True, exist_ok=True)


def healthcheck() -> dict[str, Any]:
    ensure_data_layout()
    return {
        "status": "ok",
        "service": "lineage_mcp",
        "uploads_dir": str((DATA_DIR / "uploads").resolve()),
        "output_dir": str((DATA_DIR / "output").resolve()),
    }


def read_pseudocode_text(input_path: str) -> dict[str, Any]:
    ensure_data_layout()
    path = Path(input_path)
    text = read_text(path)
    return {
        "input_path": str(path),
        "file_name": path.name,
        "file_stem": safe_name(path.stem),
        "text": text,
        "char_count": len(text),
        "line_count": len(text.splitlines()),
    }


def preprocess_pseudocode(input_path: str, max_chunk_chars: int = DEFAULT_MAX_CHUNK_CHARS) -> dict[str, Any]:
    from lineage_mcp.toolbox.pipeline import build_preprocessed_context

    payload = read_pseudocode_text(input_path)
    preprocessed = build_preprocessed_context(payload["text"], max_chunk_chars)
    return {
        "input_path": payload["input_path"],
        "file_name": payload["file_name"],
        "max_chunk_chars": max_chunk_chars,
        "preprocessed_context": preprocessed,
        "chunk_count": len(preprocessed.get("chunks", [])),
    }


def build_chunks_dict(preprocessed_context: dict[str, Any]) -> dict[str, str]:
    chunks_dict: dict[str, str] = {}
    for chunk in preprocessed_context.get("chunks", []) or []:
        if not isinstance(chunk, dict):
            continue
        chunk_id = str(chunk.get("chunk_id") or "").strip()
        if not chunk_id:
            continue
        stage_name = str(chunk.get("stage_name") or "").strip()
        block_type = str(chunk.get("block_type") or "").strip()
        chunk_type = str(chunk.get("chunk_type") or "").strip()
        body = str(chunk.get("text") or "")
        chunks_dict[chunk_id] = (
            f"chunk_id: {chunk_id}\n"
            f"stage_name: {stage_name}\n"
            f"block_type: {block_type}\n"
            f"chunk_type: {chunk_type}\n\n"
            f"{body}"
        ).strip()
    return chunks_dict


def generate_graphviz_code_one_by_one_chunk(
    chunks_dict: dict[str, str],
    model_override: str = "",
) -> dict[str, str]:
    """
    STRICT deterministic extraction of nodes + edges.
    ZERO inference allowed.
    """

    llm = _get_llm(model_override=model_override)
    final_results: dict[str, str] = {}

    for chunk_id, pseudo_code in chunks_dict.items():
        prompt = f"""You are a DataStage lineage graph builder.

TASK: Extract stage nodes and data-flow edges from this ETL chunk.

VALID NODE SOURCES — only read these sections for stage names:
  - STAGE: blocks
  - STAGE_LIST entries
  - LINK_FLOW entries (source and target stage names only)

IGNORE COMPLETELY:
  - EXECUTION_FLOW section — it contains narrative prose, NOT node definitions
  - Any text after "->" that contains spaces or reads like a sentence
  - Link connector names: any token starting with lk_, lnk_, or matching pattern lk[A-Za-z]
  - Internal wiring nodes: tokens ending in _In, _Out, _original
  - Numeric-only tokens

NODE TYPE — assign exactly one:
  Source        : OracleConnector reading raw data
  Transformer   : Transformer performing transformation
  Lookup        : HashedFile used as a reference / lookup
  BusinessLogic : Transformer deriving flags or rules
  Target        : Final write destination (Oracle write / HashedOutput)

NODE ID RULE (CRITICAL):
  - Must be a single Graphviz identifier: letters, digits, underscore only.
  - NO spaces. NO dashes. NO descriptions. NO phrases.
  - If a name contains spaces → SKIP it entirely, do not emit it.

LABEL FORMAT — exactly this, nothing more:
  node_id [label="StageName\\n[Type]"]

EDGE FORMAT — only from explicit LINK_FLOW or DATA_FLOW_SUMMARY:
  source_node -> target_node [label="main"]
  Edge labels: main | lookup | exception 
  NEVER emit an edge where source or target is a phrase or contains spaces.

FORBIDDEN:
  - Do NOT emit: lk_* nodes, _In / _Out nodes, link-name nodes, hash
  - Do NOT create aggregate nodes (SOURCE_EXTRACTION, LOOKUP_PROCESSING, etc.)
  - No markdown. No explanation. No extra text.

INPUT:
{pseudo_code}
"""

        result = str(llm.invoke(prompt).content).strip()
        final_results[chunk_id] = result

    return final_results

def generate_batch_graphviz_code(
    chunks_graphviz_dict: dict[str, str],
    batch_size: int = 10,
    model_override: str = "",
) -> dict[str, str]:

    """
    Merge WITHOUT altering meaning.
    This stage enforces STABILITY + NO NEW INFORMATION.
    """

    llm = _get_llm(model_override=model_override)
    chunk_keys = list(chunks_graphviz_dict.keys())
    final_merged_output: dict[str, str] = {}

    for batch_start in range(0, len(chunk_keys), batch_size):
        batch_end = min(batch_start + batch_size, len(chunk_keys))
        output_key = f"chunk_{batch_start}_to_{batch_end - 1}"

        combined_chunks = ""
        for i in range(batch_start, batch_end):
            chunk_id = chunk_keys[i]
            combined_chunks += f"\n--- {chunk_id} ---\n{chunks_graphviz_dict[chunk_id]}\n"

        prompt = f"""You are a DataStage lineage graph merger.

TASK: Merge these Graphviz snippets into one consistent intermediate graph.

MERGING RULES (apply in order):
  1. NODES : Keep ONE definition per node_id — prefer the most descriptive label.
  2. DEDUP : Remove duplicate node definitions and duplicate edges.
  3. REMOVE: Delete annotation/placeholder nodes (SRC, TEMP, numeric IDs).
             Delete any node whose node_id contains spaces or reads like a phrase.
             Delete these internal wiring nodes: any node_id starting with lk_, lnk_,
             or ending with _In, _Out, _original.
  4. KEEP  : All real stage nodes — Source, Transformer, Lookup, BusinessLogic,
            Target — including exception branch nodes.
  5. EDGES : Preserve valid edges; keep labels (main/lookup/exception).
             Remove any edge whose source or target node_id was deleted.
             Remove any edge where source or target contains spaces.
             Remove self-loop edges (A -> A).
  6. SAFETY: Never remove a node that connects two valid stages (A->B->C, keep B).
GRAPH CLEANUP RULE:

Remove:
1. Nodes with NO edges (isolated nodes)

2. Subgraphs that:
   - contain only 1 edge (A -> B)
   AND
   - are NOT connected to any Source node
   AND
   - do NOT lead to any Target node

KEEP:
- Any node that is part of a path:
  Source → ... → Target
- Even if it is intermediate
- Even if it has only one incoming or outgoing edge

NEVER invent aggregate phase nodes:
  SOURCE_EXTRACTION, LOOKUP_PROCESSING, TRANSFORMATION_PROCESSING, TARGET_LOADING.

LABEL FORMAT:
  node_id [label="StageName\\n[Type]"]

OUTPUT FORMAT — raw DOT only, no markdown, no explanation:
digraph G {{
    rankdir=LR;
    node [shape=box];
    // nodes
    // edges
}}

INPUT:
{combined_chunks}
"""

        final_merged_output[output_key] = str(llm.invoke(prompt).content).strip()

    return final_merged_output


def generate_full_graphviz_hierarchical(
    chunks_dict: dict[str, str],
    group_size: int = 2,
    model_override: str = "",
) -> str:

    """
    Final graph builder with STRICT lineage preservation.
    """

    llm = _get_llm(model_override=model_override)
    current_level = list(chunks_dict.values())

    while len(current_level) > 1:
        next_level = []

        for i in range(0, len(current_level), group_size):
            group = current_level[i:i + group_size]

            if len(group) == 1:
                next_level.append(group[0])
                continue

            combined_input = "\n\n--- GRAPH PART ---\n".join(group)

            prompt = f"""You are a DataStage lineage graph merger.

TASK: Merge these graph parts into one clean final lineage graph.

NODE DECLARATION ORDER (left to right):
  1. Source        — DB connectors reading raw data
  2. Lookup        — HashedFile / lookup reference stages
  3. Transformer   — Transformation / BusinessLogic stages
  4. Exception    - Exception handler stages branching off transformers
  5. Target        — Final write destinations

MERGE RULES:
  - One node per stage — keep the most descriptive label.
  - Preserve ALL edges with labels (main / lookup / exception).
  - Preserve ALL branch nodes: exception handlers.
  - Remove ONLY: annotation nodes, SRC/TEMP placeholders, numeric-only IDs.
  - Remove: nodes whose node_id contains spaces or reads like a prose phrase.
  - Remove: internal wiring nodes (lk_*, lnk_*, *_In, *_Out, *_original).
  - Remove self-loop edges (node -> same node).
  - Never remove a node that connects two valid stages.
  - Do NOT infer new edges or add new nodes.
  - Remove nodes/ flow not connected to ANY source-target path

NEVER invent aggregate phase nodes:
  SOURCE_EXTRACTION, LOOKUP_PROCESSING, TRANSFORMATION_PROCESSING, TARGET_LOADING.

LABEL FORMAT:
  node_id [label="StageName\\n[Type]"]

OUTPUT FORMAT — raw DOT only, no markdown, no explanation:
digraph G {{
    rankdir=LR;
    node [shape=box];
    // nodes
    // edges
}}

INPUT:
{combined_input}
"""
            next_level.append(str(llm.invoke(prompt).content).strip())

        current_level = next_level

    return current_level[0]

def generate_high_level_graph(
    structural_graph: str,
    model_override: str = "",
) -> str:
    """
    Generate high-level lineage WITHOUT breaking structure.
    Only removes clearly non-business nodes.
    """
    

    llm = _get_llm(model_override=model_override)

    prompt = f"""You are a DataStage business lineage simplifier.

HARD BUSINESS TARGET RULE:
- If one node is the final business destination table/file and other nodes are staging/load/write/intermediate targets before it, keep ONLY the final business destination.
- Remove intermediate staging, load, write, hashed, and connector-side target nodes from the high-level graph.
- Prefer the final business table over technical landing or staging targets.

TASK: Produce a clean, simple high-level lineage diagram showing Source → Transformation → Target flow.

NODE LABEL FORMAT — single line only:
  node_id [label="StageName [Type]"];

  Type values: Source | Transform | Lookup | BusinessLogic | HashedFile | Store | Target

NODE GROUPING — declare nodes in these four sections (use these exact comments):
    // Sources
    // Lookup 
    // Transform
    // Exception
    // Targets / Storage

WHAT TO INCLUDE:
  - All Sources (OracleConnectors reading data)
  - Only meaningful Transformer / BusinessLogic stages in the main business flow
  - Lookup stages only when they directly explain a kept transform
  - Exception path only when it is a meaningful business-visible exception flow
  - Only one final Target / write stage for each business flow

WHAT TO REMOVE (mandatory cleanup before output):
  - Any node whose node_id contains spaces → SKIP completely
  - Internal wiring nodes: any node_id starting with lk_, lnk_, or ending in _In, _Out, _original
  - HashedFile / hash output / hash storage technical nodes unless absolutely required to explain a kept transform
  - Intermediate pass-through connections with no transformation meaning
  - Intermediate staging targets and temporary write targets
  - Metadata, annotation, SRC/TEMP placeholder nodes
  - Self-loop edges (node -> same node)
  - Aggregate phase nodes: SOURCE_EXTRACTION, LOOKUP_PROCESSING, etc.
  - Remove nodes / flow not connected to ANY source-target path

EDGE RULES:
  - Main data flow: no label  →  source_node -> target_node;
  - Lookup feed:              →  lookup_node -> transform_node [label="lookup"];
  - Exception path:           →  transform_node -> exception_node [label="exception"];

MEANINGFUL CHAIN RULE:
- Preserve only the meaningful transform/business-logic chain.
- Remove technical pass-through, hashed storage, transaction-manager, connector-management, and temporary movement steps unless they are the only visible representation of exception handling.

DO NOT add fillcolor, style, or any attributes beyond label.

OUTPUT FORMAT — ONLY valid Graphviz DOT syntax, nothing else:
digraph G {{
    rankdir=LR;
    node [shape=box];

    // Sources
    ...

    // Lookup
    ...

    // Transform
    ...

    // Exception
    ...

    // Targets / Storage
    ...

    // Flow
    ...
}}
--- ADVANCED SIMPLIFICATION RULES ---

A. FINAL TARGET RESOLUTION:
   - If multiple target-like nodes exist in the same flow, keep ONLY the last real business target.
       → Identify the FINAL business table/file name
       → Use that as the Target node
   - Do NOT treat intermediate technical write stages as targets

B. TARGET DEDUPLICATION:
   - If multiple flows write to the same table/file:
       → Create ONLY ONE target node
       → Merge all incoming edges into that node
   - Do NOT create duplicate nodes for same target
TARGET OVERRIDE:
   - Prefer one final business target only.
   - Remove intermediate staging loads, temporary loads, hashed outputs, and connector-side technical targets.
   - If several target-like nodes appear, keep the last non-intermediate destination where transformed data finally lands.
   - Do not keep both staging and final destination targets in the same simplified flow unless the staging node itself is the true final business destination.

C. CHAIN COLLAPSING (CONTROLLED):
   - Preserve only the meaningful transform chain.
   - Remove technical pass-through, hashed storage, and connector-management steps.
   - Collapse technical-only steps between meaningful business stages.
   - If older rules below conflict, prefer preserving meaningful business transforms and removing technical plumbing.
   - If a sequence of stages performs ONLY technical operations:
       → collapse the chain

   Example:
       A → B → C → D → E
       becomes:
       A → E

   ONLY collapse if ALL conditions are met:
       - No transformation logic
       - No branching
       - No lookup dependency
       - No exception/hash flow involvement

   DO NOT collapse:
       - Transformer stages
       - Lookup stages
       - Business logic stages
       - Nodes involved in branching
No markdown. No explanation. No comments beyond the four section headers.

INPUT:
{structural_graph}
"""

    return str(llm.invoke(prompt).content).strip()


def build_node_chunk_map(
    chunks_dict: dict[str, str],
    chunks_graphviz_dict: dict[str, str],
) -> dict[str, list[str]]:
    """
    Robust mapping of node_id → relevant pseudo code chunks
    """

    node_map: dict[str, list[str]] = {}

    for chunk_id, graph_text in chunks_graphviz_dict.items():
        lines = str(graph_text or "").splitlines()
        source_chunk = str(chunks_dict.get(chunk_id) or "")

        for line in lines:
            line = line.strip()

            # safer extraction of node_id
            if "label=" in line and "[" in line:
                node_id = line.split()[0].strip()
                if node_id:
                    entry = node_map.setdefault(node_id, [])
                    if source_chunk and source_chunk not in entry:
                        entry.append(source_chunk)

    return node_map


def generate_technical_graph(
    structural_graph: str,
    node_chunk_map: dict[str, list[str]],
    model_override: str = "",
) -> str:
    """
    Enrich the high-level lineage graph with concise technical metadata only.
    """
    
    llm = _get_llm(model_override=model_override)

    prompt = f"""You are a DataStage technical lineage enricher.

TASK:
Take the provided HIGH-LEVEL lineage graph and return the SAME lineage graph structure,
but enrich node labels with short technical metadata from the provided context.

HARD SAME-GRAPH RULE:
- The technical graph must remain exactly the same as the input high-level graph.
- Keep exactly the same nodes, edges, and edge labels.
- Do NOT add any new technical nodes.
- Do NOT add any new target nodes.
- Do NOT add any new lookup nodes.
- Do NOT add any new exception nodes.
- Do NOT remove or replace the final business target chosen by the high-level graph.
- Only enrich labels.

IMPORTANT OVERRIDE:
- Treat the input graph as the final structure to preserve.
- This is NOT a graph rebuilding task.
- This is NOT a graph cleanup task.
- This is NOT a graph simplification task.
- Do NOT change nodes, edges, edge labels, ordering, or layout intent.
- Only enrich labels with short metadata.
- The output technical graph should look like the high-level graph with concise notes.

PREFERRED ENRICHMENT:
- Transformer / BusinessLogic: short simplified transformation rule or mapping.
- Lookup: short lookup dataset and/or key used.
- Exception: short reject/exception handling rule.
- Source: source table/schema only if clearly visible.
- Target: target table/output only if clearly visible.

REJECT / IF-ELSE RULES:
- If the context contains if/else, case, filter, validation, or reject conditions, summarize them in 1 short line on the relevant transform or exception label.
- If records are rejected, explain why in short form, for example:
  Reject: invalid status
  Reject: missing vehicle key
  Rule: if offroad_flag = Y then keep
- Prefer short business-readable summaries over raw expressions.

LABEL STYLE:
- Keep the first line as `StageName [Type]` when already present.
- Add only 1-2 short extra lines.
- If context is weak, keep the original label unchanged.
- Never paste raw pseudo code into labels.
- Do not use `StageName\n[Type]` format when the input graph already uses `StageName [Type]`.
- If any lower instruction conflicts with this label style, follow this label style.

STEP 1 — CLEANUP (apply before anything else):
  - Remove any node whose node_id contains spaces.
  - Remove internal wiring nodes: node_ids starting with lk_, lnk_, or ending in _In, _Out, _original.
  - Remove self-loop edges (node -> same node).
  - Remove edges whose source or target was removed above.
  - Remove aggregate phase nodes: SOURCE_EXTRACTION, LOOKUP_PROCESSING, etc.
  - Remove nodes / flow not connected to ANY source-target path

STEP 2 — PRESERVE remaining graph structure exactly:
  - Keep every surviving node and edge with its label (main / lookup / exception ).
  - Do NOT collapse, simplify, or remove any branch.

STEP 3 — ENRICH node labels from technical context:
  Source        : Add source table / schema name (1 line).
  Transformer   : Add 1-2 key field derivations or column mappings.
  Lookup        : Add lookup key field and reference dataset (1 line).
  BusinessLogic : Add the specific flag or rule being derived (max 2 lines).
  Exception     : Add exception handling details (1 line).
  Target        : Add target table and write operation (1 line).
  If no context is available for a node → keep its existing label unchanged.

LABEL FORMAT — max 4 lines total:
  node_id [label="StageName\\n[Type]\\nBusinessRuleOrDetail"]

OUTPUT FORMAT — ONLY valid Graphviz DOT syntax, nothing else:
digraph G {{
    rankdir=LR;
    node [shape=box];
    // nodes with enriched labels
    // edges with labels
}}

No markdown. No explanation.

INPUT GRAPH:
{structural_graph}

TECHNICAL CONTEXT:
{node_chunk_map}
"""

    return str(llm.invoke(prompt).content).strip()



def run_lineage_pipeline(input_path: str, output_dir: str, model_override: str = "") -> dict[str, Any]:
    ensure_data_layout()
    from lineage_mcp.toolbox.pipeline import run_pipeline

    return run_pipeline(input_path=input_path, output_dir=output_dir, model_override=model_override)


def _get_llm(model_override: str = ""):
    if AzureChatOpenAI is None:
        raise RuntimeError("langchain-openai is not installed.")

    endpoint = os.getenv("AZURE_OPENAI_ENDPOINT")
    api_key = os.getenv("AZURE_OPENAI_API_KEY")
    api_version = os.getenv("AZURE_OPENAI_API_VERSION")
    deployment = (
        model_override
        or os.getenv("AZURE_OPENAI_DEPLOYMENT_NAME")
        or os.getenv("AZURE_OPENAI_CHAT_DEPLOYMENT_NAME")
        or os.getenv("AZURE_OPENAI_MODEL_DEPLOYMENT")
    )
    if not all([endpoint, api_key, api_version, deployment]):
        raise RuntimeError("Missing Azure OpenAI configuration in .env.")

    custom_timeout = httpx.Timeout(connect=30000.0, read=6000.0, write=6000.0, pool=6000.0)
    return AzureChatOpenAI(
        azure_endpoint=endpoint,
        azure_deployment=deployment,
        api_key=api_key,
        api_version=api_version,
        streaming=True,
        temperature=0.0,
        http_client=httpx.Client(timeout=custom_timeout),
    )
