from fastapi import APIRouter
from pydantic import BaseModel, Field
from typing import Dict, Any, List
from lineage_mcp.toolbox import methods

router = APIRouter()


# =========================
# REQUEST MODELS
# =========================

class InputPath(BaseModel):
    input_path: str = Field(..., description="Path to pseudocode input file.")


class PreprocessRequest(BaseModel):
    input_path: str = Field(..., description="Path to pseudocode input file.")
    max_chunk_chars: int = Field(100, description="Maximum characters per chunk.")


class GraphRequest(BaseModel):
    chunks_dict: Dict[str, str] = Field(..., description="Chunk dictionary generated from preprocessing.")


class BatchGraphRequest(BaseModel):
    chunks_graphviz_dict: Dict[str, str] = Field(..., description="Graphviz outputs from chunk-level processing.")
    batch_size: int = Field(10, description="Batch size for merging graph chunks.")


class HierarchicalRequest(BaseModel):
    chunks_dict: Dict[str, str] = Field(..., description="Merged batch graph dictionary.")
    group_size: int = Field(2, description="Group size for hierarchical merging.")


class HighLevelRequest(BaseModel):
    structural_graph: str = Field(..., description="Full structural graphviz DOT string.")


class NodeMapRequest(BaseModel):
    chunks_dict: Dict[str, str]
    chunks_graphviz_dict: Dict[str, str]


class TechnicalGraphRequest(BaseModel):
    structural_graph: str
    node_chunk_map: Dict[str, List[str]]


class FullPipelineRequest(BaseModel):
    input_path: str
    output_dir: str


# =========================
# ROUTES
# =========================


@router.post(
    "/healthcheck",
    operation_id="healthcheck",
    summary="Check lineage service health",
    description="Verifies that the lineage service is running and required directories are available."
)
async def healthcheck():
    """
    Perform a health check of the lineage service.

    Returns:
        dict:
            - status: Service status
            - uploads_dir: Upload directory path
            - output_dir: Output directory path
    """
    return methods.healthcheck()


@router.post(
    "/read_pseudocode",
    operation_id="read_pseudocode",
    summary="Read pseudocode file",
    description="Reads ETL pseudocode file and returns raw text along with metadata like line count and character count."
)
async def read_pseudocode(p_body: InputPath):
    """
    Reads pseudocode input file.

    Args:
        input_path (str): File path of pseudocode.

    Returns:
        dict:
            - text
            - file_name
            - char_count
            - line_count
    """
    return methods.read_pseudocode_text(p_body.input_path)


@router.post(
    "/preprocess",
    operation_id="preprocess_pseudocode",
    summary="Preprocess pseudocode into chunks",
    description="Splits ETL pseudocode into structured chunks and builds preprocessing context for lineage extraction."
)
async def preprocess(p_body: PreprocessRequest):
    """
    Preprocess pseudocode into structured chunks.

    Args:
        input_path (str)
        max_chunk_chars (int)

    Returns:
        dict:
            - preprocessed_context
            - chunk_count
    """
    return methods.preprocess_pseudocode(
        p_body.input_path,
        p_body.max_chunk_chars
    )


@router.post(
    "/build_chunks",
    operation_id="build_chunks_dict",
    summary="Build chunk dictionary",
    description="Transforms preprocessed chunks into a dictionary format used for lineage extraction."
)
async def build_chunks(preprocessed_context: Dict[str, Any]):
    """
    Convert preprocessing output into chunk dictionary.

    Returns:
        dict: chunk_id → chunk text mapping
    """
    return methods.build_chunks_dict(preprocessed_context)


@router.post(
    "/generate_graph_chunk",
    operation_id="generate_graph_chunk",
    summary="Generate Graphviz per chunk",
    description="Generates Graphviz DOT code for each chunk independently using deterministic extraction rules."
)
async def generate_graph_chunk(p_body: GraphRequest):
    """
    Generate Graphviz code for each chunk.

    Returns:
        dict: chunk_id → graphviz DOT snippet
    """
    return methods.generate_graphviz_code_one_by_one_chunk(
        p_body.chunks_dict
    )


@router.post(
    "/merge_graph_batch",
    operation_id="merge_graph_batch",
    summary="Merge graph chunks in batches",
    description="Merges chunk-level Graphviz outputs into batch-level graphs while deduplicating nodes and edges."
)
async def merge_graph_batch(p_body: BatchGraphRequest):
    """
    Merge Graphviz chunks into batch graphs.

    Returns:
        dict: merged graph batches
    """
    return methods.generate_batch_graphviz_code(
        p_body.chunks_graphviz_dict,
        p_body.batch_size
    )


@router.post(
    "/merge_graph_final",
    operation_id="merge_graph_final",
    summary="Generate final lineage graph",
    description="Performs hierarchical merging of batch graphs to produce the final structural lineage graph."
)
async def merge_graph_final(p_body: HierarchicalRequest):
    """
    Generate final merged lineage graph.

    Returns:
        str: Final Graphviz DOT graph
    """
    return methods.generate_full_graphviz_hierarchical(
        p_body.chunks_dict,
        p_body.group_size
    )


@router.post(
    "/high_level_graph",
    operation_id="generate_high_level_graph",
    summary="Generate high-level lineage graph",
    description="Simplifies structural graph into business-level lineage view by removing technical nodes and retaining core flow."
)
async def high_level_graph(p_body: HighLevelRequest):
    """
    Generate simplified business lineage graph.

    Returns:
        str: High-level Graphviz DOT graph
    """
    return methods.generate_high_level_graph(
        p_body.structural_graph
    )


@router.post(
    "/build_node_map",
    operation_id="build_node_chunk_map",
    summary="Map nodes to source chunks",
    description="Builds mapping between graph nodes and corresponding pseudocode chunks for enrichment."
)
async def build_node_map(p_body: NodeMapRequest):
    """
    Build node-to-chunk mapping.

    Returns:
        dict: node_id → list of related chunks
    """
    return methods.build_node_chunk_map(
        p_body.chunks_dict,
        p_body.chunks_graphviz_dict
    )


@router.post(
    "/technical_graph",
    operation_id="generate_technical_graph",
    summary="Generate technical lineage graph",
    description="Enriches high-level lineage graph with technical metadata such as transformations, lookups, and rules."
)
async def technical_graph(p_body: TechnicalGraphRequest):
    """
    Generate enriched technical lineage graph.

    Returns:
        str: Technical Graphviz DOT graph
    """
    return methods.generate_technical_graph(
        p_body.structural_graph,
        p_body.node_chunk_map
    )


@router.post(
    "/run_pipeline",
    operation_id="run_lineage_pipeline",
    summary="Run full lineage pipeline",
    description="Executes the complete lineage pipeline from pseudocode input to final technical and high-level graph outputs including PDF generation."
)
async def run_pipeline(p_body: FullPipelineRequest):
    """
    Run full lineage pipeline end-to-end.

    Steps:
        1. Preprocess pseudocode
        2. Generate chunk graphs
        3. Merge graphs
        4. Create high-level graph
        5. Enrich technical graph
        6. Generate DOT + PDF outputs

    Returns:
        dict:
            - run_id
            - output_dir
            - dot_files
            - pdf_files
            - warnings
    """
    return methods.run_lineage_pipeline(
        p_body.input_path,
        p_body.output_dir
    )
