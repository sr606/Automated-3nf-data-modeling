from fastapi import APIRouter
from pydantic import BaseModel, Field
from typing import Any, Dict, List
from pathlib import Path

from lineage_mcp.toolbox import pipeline as helper

router = APIRouter()


# =========================
# REQUEST MODELS
# =========================

class FilePathRequest(BaseModel):
    path: str = Field(..., description="File path")


class WriteFileRequest(BaseModel):
    path: str = Field(..., description="Output file path")
    text: str = Field(..., description="Text content to write")


class TextRequest(BaseModel):
    text: str = Field(..., description="Input text")


class ChunkRequest(BaseModel):
    text: str
    max_chars: int = 7000


class PreprocessContextRequest(BaseModel):
    text: str
    max_chunk_chars: int = 100


# =========================
# ROUTES
# =========================


@router.post(
    "/timestamp",
    operation_id="generate_timestamp",
    summary="Generate timestamp",
    description="Generates a formatted timestamp string used for run IDs and file naming."
)
async def generate_timestamp():
    """
    Returns:
        str: Current timestamp in YYYYMMDD_HHMMSS format
    """
    return {"timestamp": helper.timestamp()}


@router.post(
    "/safe_name",
    operation_id="safe_name",
    summary="Sanitize string",
    description="Converts input string into a filesystem-safe name."
)
async def safe_name(p_body: TextRequest):
    """
    Returns:
        str: Sanitized string
    """
    return {"safe_name": helper.safe_name(p_body.text)}


@router.post(
    "/read_file",
    operation_id="read_text",
    summary="Read file",
    description="Reads text content from a given file path."
)
async def read_file(p_body: FilePathRequest):
    """
    Returns:
        dict: file content
    """
    content = helper.read_text(Path(p_body.path))
    return {"content": content}


@router.post(
    "/write_file",
    operation_id="write_text",
    summary="Write file",
    description="Writes text content to a specified file path."
)
async def write_file(p_body: WriteFileRequest):
    """
    Returns:
        dict: success message
    """
    helper.write_text(Path(p_body.path), p_body.text)
    return {"status": "success", "path": p_body.path}


@router.post(
    "/render_dot",
    operation_id="render_dot_to_pdf",
    summary="Render Graphviz DOT",
    description="Converts a DOT file into a PDF using Graphviz."
)
async def render_dot(p_body: FilePathRequest):
    """
    Returns:
        dict:
            - pdf_generated
            - pdf_path
            - warning
    """
    return helper.render_dot(Path(p_body.path))


# =========================
# PREPROCESSING ROUTES
# =========================


@router.post(
    "/split_stages",
    operation_id="split_into_stages",
    summary="Split into stages",
    description="Splits ETL pseudocode into logical stage blocks."
)
async def split_stages(p_body: TextRequest):
    """
    Returns:
        List[dict]: stage blocks
    """
    return {"blocks": helper.split_into_stages(p_body.text)}


@router.post(
    "/generate_chunks",
    operation_id="generate_chunks",
    summary="Generate chunks",
    description="Splits ETL pseudocode into validated chunks based on stages."
)
async def generate_chunks(p_body: ChunkRequest):
    """
    Returns:
        List[dict]: chunks
    """
    return {"chunks": helper.generate_chunks(p_body.text, p_body.max_chars)}


@router.post(
    "/build_preprocessed_context",
    operation_id="build_preprocessed_context",
    summary="Build preprocessing context",
    description="Generates structured preprocessing context including chunks, stage hints, and metadata."
)
async def build_preprocessed_context(p_body: PreprocessContextRequest):
    """
    Returns:
        dict: preprocessing context
    """
    return helper.build_preprocessed_context(
        p_body.text,
        p_body.max_chunk_chars
    )


# =========================
# PARSING ROUTES
# =========================


@router.post(
    "/parse_link_flow",
    operation_id="parse_link_flow_hints",
    summary="Parse link flow",
    description="Extracts link flow relationships from ETL pseudocode."
)
async def parse_link_flow(p_body: TextRequest):
    """
    Returns:
        List[dict]: link flow hints
    """
    return {"link_flow": helper.parse_link_flow_hints(p_body.text)}


@router.post(
    "/parse_execution_flow",
    operation_id="parse_execution_flow_hints",
    summary="Parse execution flow",
    description="Extracts execution flow sections and stage references."
)
async def parse_execution_flow(p_body: TextRequest):
    """
    Returns:
        dict: execution flow hints
    """
    return helper.parse_execution_flow_hints(p_body.text)


@router.post(
    "/job_name_hints",
    operation_id="job_name_hints",
    summary="Extract job names",
    description="Extracts job name hints from ETL pseudocode."
)
async def job_name_hints(p_body: TextRequest):
    """
    Returns:
        List[str]: job names
    """
    return {"job_names": helper.job_name_hints(p_body.text)}


@router.post(
    "/target_table_hints",
    operation_id="target_table_hints",
    summary="Extract target tables",
    description="Extracts target table names from ETL pseudocode."
)
async def target_table_hints(p_body: TextRequest):
    """
    Returns:
        List[str]: target tables
    """
    return {"target_tables": helper.target_table_hints(p_body.text)}


@router.post(
    "/annotation_hints",
    operation_id="annotation_hints",
    summary="Extract annotations",
    description="Extracts annotation hints from ETL pseudocode."
)
async def annotation_hints(p_body: TextRequest):
    """
    Returns:
        List[str]: annotations
    """
    return {"annotations": helper.annotation_hints(p_body.text)}
