from fastapi import FastAPI
from dotenv import load_dotenv

# Import routers
from lineage_mcp.routers.lineage_router import router as lineage_router
from lineage_mcp.routers.helper_router import router as helper_router
# from routers.catalog_router import router as catalog_router  # if needed

load_dotenv()

app = FastAPI(
    title="ETL Lineage Agent",
    description="API for ETL lineage extraction, preprocessing, and graph generation",
    version="1.0.0"
)


# =========================
# REGISTER ROUTERS
# =========================

app.include_router(
    lineage_router,
    prefix="/lineage",
    tags=["Lineage"]
)

app.include_router(
    helper_router,
    prefix="/helper",
    tags=["Helper"]
)

# OPTIONAL
# app.include_router(
#     catalog_router,
#     prefix="/catalog",
#     tags=["Catalog"]
# )


# =========================
# ROOT
# =========================

@app.get("/")
async def root():
    return {
        "message": "ETL Lineage Agent API is running",
        "modules": ["lineage", "helper", "catalog"]
    }
