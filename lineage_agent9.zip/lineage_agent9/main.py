import argparse
import json
from pathlib import Path

from dotenv import load_dotenv

from lineage_agent import run_pipeline


load_dotenv()

DEFAULT_INPUT_DIR = Path("input")
DEFAULT_OUTPUT_DIR = Path("output")


def main() -> None:
    parser = argparse.ArgumentParser(description="Run the layered DataStage lineage agent.")
    parser.add_argument("--input", required=True, help="Path to the pseudocode text file.")
    parser.add_argument("--output-dir", default=str(DEFAULT_OUTPUT_DIR), help="Directory for run outputs.")
    parser.add_argument("--model", default="", help="Optional Azure model override.")
    args = parser.parse_args()

    result = run_pipeline(args.input, args.output_dir, model_override=args.model)
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    DEFAULT_INPUT_DIR.mkdir(parents=True, exist_ok=True)
    DEFAULT_OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    main()
