# Profiler MCP Server

A FastAPI-based MCP (Model Context Protocol) server for database profiling and metadata extraction.

## Project Structure

```
mcp_server/
  profiler_mcp/
    __init__.py
    main.py                 # FastAPI application entry point
    methods.py              # Environment and utility functions
    data/
      feature/              # Stores profiling results (JSON files)
      upload/               # Directory for file uploads
    routers/
      __init__.py
      profiler.py           # API endpoints for profiling
    toolbox/
      __init__.py
      db_utils.py           # Database connection and metadata extraction
      profiling_utils.py    # Table profiling and file saving functions

.env                        # Environment variables (create from .env.example)
.env.example                # Template for environment configuration
requirements.txt            # Python dependencies
```

## Features

- **Database Metadata Extraction**: Extract complete metadata for all tables in a MySQL database
- **Table Profiling**: Analyze specific tables with row counts and null percentage calculations
- **Timestamped JSON Output**: All results saved with timestamps (e.g., `20251201_103210_chinook_metadata.json`)
- **RESTful API**: Clean FastAPI endpoints with OpenAPI documentation
- **CORS Enabled**: Cross-origin requests supported

## Installation

### 1. Install Dependencies

```bash
pip install -r requirements.txt
```

### 2. Configure Environment

Copy `.env.example` to `.env` and fill in your database credentials:

```bash
cp .env.example .env
```

Edit `.env` file:
```
DB_HOST=localhost
DB_PORT=3306
DB_USER=your_username
DB_PASSWORD=your_password
DB_NAME=your_database_name
```

## Usage

### Running the Server

From the project root directory:

```bash
cd mcp_server
python -m profiler_mcp.main
```

Or:

```bash
cd mcp_server
uvicorn profiler_mcp.main:app --reload --host 0.0.0.0 --port 8000
```

The server will start at: `http://localhost:8000`

### API Documentation

Once the server is running, access the interactive API documentation:

- **Swagger UI**: http://localhost:8000/docs
- **ReDoc**: http://localhost:8000/redoc

### API Endpoints

#### 1. Extract Database Metadata

```
GET /mcp/api/v1/profile/extract_metadata
```

Extracts metadata for all tables and saves to `profiler_mcp/data/feature/`.

**Response Example:**
```json
{
  "status": "success",
  "message": "Metadata extracted and saved successfully",
  "file_path": "profiler_mcp/data/feature/20251201_103210_chinook_metadata.json",
  "table_count": 13,
  "metadata": {
    "users": [...],
    "orders": [...]
  }
}
```

#### 2. Profile Specific Table

```
GET /mcp/api/v1/profile/profile_table?table_name=users
```

Profiles a specific table with row counts and null analysis.

**Response Example:**
```json
{
  "status": "success",
  "message": "Table 'users' profiled successfully",
  "file_path": "profiler_mcp/data/feature/20251201_103215_chinook_users_profile.json",
  "profile": {
    "table_name": "users",
    "row_count": 1500,
    "column_profiles": [
      {
        "column_name": "id",
        "data_type": "int",
        "null_count": 0,
        "null_percentage": 0.0,
        "non_null_count": 1500
      }
    ],
    "profiled_at": "2025-12-01T10:32:15.123456"
  }
}
```

#### 3. Health Check

```
GET /mcp/api/v1/profile/health
```

Simple health check endpoint.

## Module Documentation

### db_utils.py

- `get_db_connection()`: Establishes MySQL database connection
- `get_tables_metadata()`: Extracts complete metadata for all tables

### profiling_utils.py

- `save_metadata_to_file(metadata, filename)`: Saves data to timestamped JSON file
- `get_table_profile(table_name)`: Profiles table with row counts and null percentages

### methods.py

- `load_env()`: Loads environment variables from .env file
- `get_env(key, default)`: Retrieves specific environment variable
- `get_data_paths()`: Creates and returns data directory paths

### routers/profiler.py

API endpoints for:
- Metadata extraction
- Table profiling
- Health checks

### main.py

FastAPI application setup with:
- CORS middleware
- Router mounting
- OpenAPI documentation
- Startup/shutdown events

## Example Output Files

Files are saved in `profiler_mcp/data/feature/` with timestamped names:

```
20251201_103210_chinook_metadata.json
20251201_103215_chinook_users_profile.json
20251201_103220_chinook_orders_profile.json
```

## Development

The server runs in reload mode by default, automatically restarting when code changes are detected.

## Requirements

- Python 3.8+
- MySQL Database
- FastAPI
- Uvicorn
- mysql-connector-python
- python-dotenv

## Author

Designed by Avdhut

## License

MIT License
