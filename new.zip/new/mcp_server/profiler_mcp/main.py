"""
Profiler MCP Server - Main Application
=======================================
This is the main FastAPI application for the Profiler MCP (Model Context Protocol) server.
It provides RESTful API endpoints for database profiling and metadata extraction.

Features:
    - Database metadata extraction
    - Table profiling with statistics
    - JSON file output with timestamps
    - CORS enabled for cross-origin requests
    - OpenAPI documentation

Author: Avdhut
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
import uvicorn

from .methods import load_env, get_data_paths
from .routers import profiler


# Load environment variables from .env file
load_env()

# Initialize data directories
get_data_paths()

# Create FastAPI application instance
app = FastAPI(
    title="Profiler MCP Server",
    description="A FastAPI-based MCP server for database profiling and metadata extraction",
    version="1.0.0",
    docs_url="/docs",
    redoc_url="/redoc",
    openapi_url="/openapi.json"
)

# Configure CORS middleware
# This allows the API to be accessed from web browsers on different domains
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # Allow all origins (configure as needed for production)
    allow_credentials=True,
    allow_methods=["*"],  # Allow all HTTP methods (GET, POST, PUT, DELETE, etc.)
    allow_headers=["*"],  # Allow all headers
)


# Include the profiler router under /mcp prefix
app.include_router(profiler.router, prefix="/mcp")


@app.get("/")
async def root():
    """
    Root endpoint providing API information and available endpoints.
    
    Returns:
        JSONResponse: Welcome message and API details
        
    Example Response:
        {
            "message": "Welcome to Profiler MCP Server",
            "version": "1.0.0",
            "endpoints": {
                "docs": "/docs",
                "health": "/mcp/api/v1/profile/health",
                "extract_metadata": "/mcp/api/v1/profile/extract_metadata",
                "profile_table": "/mcp/api/v1/profile/profile_table?table_name=<table_name>"
            }
        }
    """
    return JSONResponse(content={
        "message": "Welcome to Profiler MCP Server",
        "version": "1.0.0",
        "description": "Database profiling and metadata extraction service",
        "endpoints": {
            "docs": "/docs",
            "redoc": "/redoc",
            "health": "/mcp/api/v1/profile/health",
            "extract_metadata": "/mcp/api/v1/profile/extract_metadata",
            "profile_table": "/mcp/api/v1/profile/profile_table?table_name=<table_name>"
        }
    })


@app.get("/health")
async def health():
    """
    Health check endpoint for monitoring service status.
    
    Returns:
        dict: Service health status
    """
    return {
        "status": "healthy",
        "service": "Profiler MCP Server"
    }


# Application startup event
@app.on_event("startup")
async def startup_event():
    """
    Executed when the application starts.
    Performs initialization tasks like verifying directories and connections.
    """
    print("=" * 60)
    print("Profiler MCP Server Starting...")
    print("=" * 60)
    print("✓ Environment variables loaded")
    print("✓ Data directories initialized")
    print("✓ Routers mounted")
    print("=" * 60)
    print("Server is ready to accept requests")
    print("API Documentation: http://localhost:8000/docs")
    print("=" * 60)


# Application shutdown event
@app.on_event("shutdown")
async def shutdown_event():
    """
    Executed when the application shuts down.
    Performs cleanup tasks.
    """
    print("=" * 60)
    print("Profiler MCP Server Shutting Down...")
    print("=" * 60)


# Main entry point for running the server
if __name__ == "__main__":
    """
    Run the server using Uvicorn ASGI server.
    
    Configuration:
        - Host: 0.0.0.0 (accessible from all network interfaces)
        - Port: 8000
        - Reload: True (auto-reload on code changes during development)
    
    Usage:
        python -m profiler_mcp.main
        
        Or from the mcp_server directory:
        python -m profiler_mcp.main
    """
    uvicorn.run(
        "profiler_mcp.main:app",
        host="0.0.0.0",
        port=8031,
        reload=True,
        log_level="info"
    )
