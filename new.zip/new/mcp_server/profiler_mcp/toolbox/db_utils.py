"""
Database Utilities Module
==========================
This module provides functions for connecting to MySQL and SQLite databases and extracting metadata.

Auto-Detection:
    - If a .db file exists in data/upload/, automatically uses SQLite
    - Otherwise, connects to MySQL using environment variables

Functions:
    - get_db_connection(): Establishes database connection (auto-detects SQLite or MySQL)
    - get_sqlite_connection(): Establishes SQLite connection
    - get_mysql_connection(): Establishes MySQL connection
    - get_tables_metadata(): Extracts complete metadata for all tables (works for both DB types)
    - get_database_type(): Returns 'sqlite' or 'mysql' based on active configuration
"""

import mysql.connector
import sqlite3
from mysql.connector import Error
from typing import Dict, List, Optional, Tuple
import os
import sys
from pathlib import Path

# Add parent directory to path to import methods
sys.path.append(str(Path(__file__).parent.parent))
from methods import get_active_database_path


def get_database_type() -> str:
    """
    Determines which database type to use based on file presence in upload folder.
    
    Returns:
        str: 'sqlite' if .db file exists in data/upload, otherwise 'mysql'
        
    Example:
        >>> db_type = get_database_type()
        >>> print(f"Active database type: {db_type}")
    """
    db_path = get_active_database_path()
    return 'sqlite' if db_path else 'mysql'


def get_sqlite_connection(db_path: Optional[Path] = None):
    """
    Establishes a connection to a SQLite database file.
    
    Args:
        db_path (Optional[Path]): Path to SQLite database file. If None, auto-detects from upload folder.
    
    Returns:
        sqlite3.Connection: Active SQLite database connection object
        
    Raises:
        Exception: If database file doesn't exist or connection fails
        
    Example:
        >>> conn = get_sqlite_connection()
        >>> cursor = conn.cursor()
        >>> cursor.execute("SELECT name FROM sqlite_master WHERE type='table'")
    """
    if db_path is None:
        db_path = get_active_database_path()
    
    if db_path is None or not db_path.exists():
        raise Exception("No SQLite database file found in data/upload folder")
    
    try:
        connection = sqlite3.connect(str(db_path))
        print(f"✓ Successfully connected to SQLite database: {db_path}")
        print(f"  Using SQLite database located at: {db_path}")
        return connection
    except Exception as e:
        print(f"Error connecting to SQLite database: {e}")
        raise


def get_mysql_connection():
    """
    Establishes a connection to the MySQL database using environment variables.
    
    Environment Variables Required:
        - DB_HOST: Database host address
        - DB_PORT: Database port number
        - DB_USER: Database username
        - DB_PASSWORD: Database password
        - DB_NAME: Database name
    
    Returns:
        mysql.connector.connection.MySQLConnection: Active database connection object
        
    Raises:
        Error: If connection fails or environment variables are missing
        
    Example:
        >>> conn = get_mysql_connection()
        >>> cursor = conn.cursor()
        >>> cursor.execute("SELECT * FROM users")
    """
    try:
        connection = mysql.connector.connect(
            host=os.getenv('DB_HOST', 'localhost'),
            port=int(os.getenv('DB_PORT', 3306)),
            user=os.getenv('DB_USER'),
            password=os.getenv('DB_PASSWORD'),
            database=os.getenv('DB_NAME')
        )
        
        if connection.is_connected():
            print(f"✓ Successfully connected to MySQL database: {os.getenv('DB_NAME')}")
            return connection
    except Error as e:
        print(f"Error connecting to MySQL database: {e}")
        raise


def get_db_connection():
    """
    Establishes a database connection with auto-detection of database type.
    
    Auto-Detection Logic:
        1. Checks if a .db file exists in profiler_mcp/data/upload/
        2. If found: Connects to SQLite database
        3. If not found: Connects to MySQL using environment variables
    
    Returns:
        Union[sqlite3.Connection, mysql.connector.connection.MySQLConnection]: 
            Active database connection object (SQLite or MySQL)
        
    Raises:
        Error: If connection fails
        
    Example:
        >>> conn = get_db_connection()
        >>> # Works with both SQLite and MySQL automatically
        
    Notes:
        - Prioritizes SQLite if .db file exists in upload folder
        - Falls back to MySQL if no .db file found
        - Prints connection type to logs for debugging
    """
    db_type = get_database_type()
    
    if db_type == 'sqlite':
        return get_sqlite_connection()
    else:
        return get_mysql_connection()
def get_tables_metadata() -> Dict[str, List[Dict]]:
    """
    Extracts metadata for all tables in the connected database.
    
    This function automatically detects whether to use SQLite or MySQL and
    retrieves comprehensive information about each table including:
        - Table name
        - Column names
        - Data types
        - Nullable status
        - Primary key constraints
        - Default values
        - Extra attributes (auto_increment for MySQL, etc.)
    
    Auto-Detection:
        - Uses SQLite if .db file exists in data/upload/
        - Uses MySQL if no .db file found (reads from .env)
    
    Returns:
        Dict[str, List[Dict]]: Dictionary with table names as keys and list of column 
        metadata dictionaries as values.
        
        Example return structure:
        {
            "users": [
                {
                    "column_name": "id",
                    "data_type": "int",
                    "is_nullable": "NO",
                    "column_key": "PRI",
                    "default": None,
                    "extra": "auto_increment"
                },
                {
                    "column_name": "name",
                    "data_type": "varchar(255)",
                    "is_nullable": "YES",
                    "column_key": "",
                    "default": None,
                    "extra": ""
                }
            ],
            "orders": [...]
        }
    
    Raises:
        Error: If database query fails
        
    Example:
        >>> metadata = get_tables_metadata()
        >>> print(f"Found {len(metadata)} tables")
        >>> for table_name, columns in metadata.items():
        >>>     print(f"Table: {table_name}, Columns: {len(columns)}")
        
    Notes:
        - Works seamlessly with both SQLite and MySQL
        - SQLite: Queries sqlite_master and pragma_table_info
        - MySQL: Queries INFORMATION_SCHEMA.COLUMNS
    """
    db_type = get_database_type()
    connection = None
    
    try:
        connection = get_db_connection()
        
        if db_type == 'sqlite':
            return _get_sqlite_tables_metadata(connection)
        else:
            return _get_mysql_tables_metadata(connection)
            
    except Exception as e:
        print(f"Error extracting table metadata: {e}")
        raise
    finally:
        if connection:
            connection.close()
            print("Database connection closed")


def _get_sqlite_tables_metadata(connection: sqlite3.Connection) -> Dict[str, List[Dict]]:
    """
    Extracts metadata from SQLite database.
    
    Args:
        connection: Active SQLite connection
        
    Returns:
        Dict[str, List[Dict]]: Table metadata dictionary
    """
    cursor = connection.cursor()
    metadata = {}
    
    # Get all table names
    cursor.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")
    tables = cursor.fetchall()
    
    for (table_name,) in tables:
        # Get column information using PRAGMA
        cursor.execute(f"PRAGMA table_info({table_name})")
        columns_info = cursor.fetchall()
        
        columns = []
        for col_info in columns_info:
            # col_info: (cid, name, type, notnull, dflt_value, pk)
            columns.append({
                "column_name": col_info[1],
                "data_type": col_info[2],
                "is_nullable": "NO" if col_info[3] else "YES",
                "column_key": "PRI" if col_info[5] else "",
                "default_value": col_info[4],
                "extra": "",
                "max_length": None,
                "numeric_precision": None,
                "numeric_scale": None
            })
        
        metadata[table_name] = columns
    
    print(f"Extracted metadata for {len(metadata)} tables from SQLite database")
    return metadata


def _get_mysql_tables_metadata(connection) -> Dict[str, List[Dict]]:
    """
    Extracts metadata from MySQL database.
    
    Args:
        connection: Active MySQL connection
        
    Returns:
        Dict[str, List[Dict]]: Table metadata dictionary
    """
    cursor = connection.cursor(dictionary=True)
    
    # Get all table names in the database
    cursor.execute("SHOW TABLES")
    tables = cursor.fetchall()
    
    metadata = {}
    db_name = os.getenv('DB_NAME')
    
    # Extract column information for each table
    for table in tables:
        table_name = table[f'Tables_in_{db_name}']
        
        # Query INFORMATION_SCHEMA for detailed column information
        query = """
            SELECT 
                COLUMN_NAME as column_name,
                DATA_TYPE as data_type,
                IS_NULLABLE as is_nullable,
                COLUMN_KEY as column_key,
                COLUMN_DEFAULT as default_value,
                EXTRA as extra,
                CHARACTER_MAXIMUM_LENGTH as max_length,
                NUMERIC_PRECISION as numeric_precision,
                NUMERIC_SCALE as numeric_scale
            FROM INFORMATION_SCHEMA.COLUMNS
            WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s
            ORDER BY ORDINAL_POSITION
        """
        
        cursor.execute(query, (db_name, table_name))
        columns = cursor.fetchall()
        
        metadata[table_name] = columns
    
    print(f"Extracted metadata for {len(metadata)} tables from MySQL database")
    return metadata


def execute_query(db_path: Optional[str], db_type: str, query: str) -> List[Dict]:
    """
    Execute a SQL query and return results.
    
    Args:
        db_path: Path to database file (for SQLite) or None (for MySQL)
        db_type: Type of database ('sqlite' or 'mysql')
        query: SQL query to execute
        
    Returns:
        List[Dict]: Query results as list of dictionaries
    """
    if db_type == 'sqlite':
        conn = get_sqlite_connection(db_path)
        cursor = conn.cursor()
        cursor.execute(query)
        
        # Get column names
        columns = [description[0] for description in cursor.description] if cursor.description else []
        
        # Fetch results
        rows = cursor.fetchall()
        conn.close()
        
        # Convert to list of dicts
        results = [dict(zip(columns, row)) for row in rows]
        return results
    
    else:  # mysql
        conn = get_mysql_connection()
        cursor = conn.cursor()
        cursor.execute(query)
        
        # Get column names
        columns = [description[0] for description in cursor.description] if cursor.description else []
        
        # Fetch results
        rows = cursor.fetchall()
        conn.close()
        
        # Convert to list of dicts
        results = [dict(zip(columns, row)) for row in rows]
        return results
