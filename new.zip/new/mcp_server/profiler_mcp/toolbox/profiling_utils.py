"""
Profiling Utilities Module
===========================
This module provides functions for profiling database tables and saving results.
Supports both SQLite and MySQL databases with automatic detection.

Functions:
    - save_metadata_to_file(): Saves metadata to JSON file with timestamp
    - get_table_profile(): Generates comprehensive profile for a specific table (SQLite & MySQL)
"""

import json
import os
from datetime import datetime
from typing import Dict, Any, Optional
from pathlib import Path
from .db_utils import get_db_connection, get_database_type
import sqlite3


def save_metadata_to_file(metadata: Dict[str, Any], filename: str) -> str:
    """
    Saves metadata to a JSON file in the data/feature directory with timestamp.
    
    This function creates a timestamped JSON file in the profiler_mcp/data/feature 
    directory. The timestamp format is YYYYMMDD_HHMMSS.
    
    Args:
        metadata (Dict[str, Any]): Dictionary containing metadata to save
        filename (str): Base filename (without extension). Will be prefixed with timestamp.
                       Example: "chinook.db_metadata"
    
    Returns:
        str: Full path to the created file
        
    Example:
        >>> metadata = {"users": [...], "orders": [...]}
        >>> filepath = save_metadata_to_file(metadata, "chinook.db_metadata")
        >>> print(filepath)
        profiler_mcp/data/feature/20251201_103210_chinook.db_metadata.json
        
    Notes:
        - Automatically creates the data/feature directory if it doesn't exist
        - Uses proper JSON formatting with 2-space indentation
        - Timestamp format: YYYYMMDD_HHMMSS
    """
    # Get the base directory (profiler_mcp)
    base_dir = Path(__file__).parent.parent
    feature_dir = base_dir / "data" / "feature"
    
    # Ensure directory exists
    feature_dir.mkdir(parents=True, exist_ok=True)
    
    # Generate timestamp
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    
    # Create full filename with timestamp
    full_filename = f"{timestamp}_{filename}.json"
    filepath = feature_dir / full_filename
    
    # Write JSON file
    with open(filepath, 'w', encoding='utf-8') as f:
        json.dump(metadata, f, indent=2, default=str)
    
    print(f"Metadata saved to: {filepath}")
    return str(filepath)


def get_table_profile(table_name: str) -> Dict[str, Any]:
    """
    Generates a comprehensive profile for a specific database table.
    
    This function automatically detects whether to use SQLite or MySQL and
    analyzes a table to return:
        - Total row count
        - Null percentage for each column
        - Data type information
        - Basic statistics
    
    Auto-Detection:
        - Uses SQLite if .db file exists in data/upload/
        - Uses MySQL if no .db file found (reads from .env)
    
    Args:
        table_name (str): Name of the table to profile
    
    Returns:
        Dict[str, Any]: Dictionary containing profile information with structure:
        {
            "table_name": str,
            "database_type": str ("sqlite" or "mysql"),
            "row_count": int,
            "column_profiles": [
                {
                    "column_name": str,
                    "data_type": str,
                    "null_count": int,
                    "null_percentage": float,
                    "non_null_count": int
                },
                ...
            ],
            "profiled_at": str (ISO format timestamp)
        }
    
    Raises:
        Exception: If database query fails or table doesn't exist
        
    Example:
        >>> profile = get_table_profile("users")
        >>> print(f"Table: {profile['table_name']}")
        >>> print(f"Total rows: {profile['row_count']}")
        >>> for col in profile['column_profiles']:
        >>>     print(f"Column: {col['column_name']}, Null%: {col['null_percentage']:.2f}%")
        
    Notes:
        - Analyzes all columns in the table
        - Calculates null percentages as (null_count / total_rows) * 100
        - Returns timestamp of when the profile was generated
        - Works seamlessly with both SQLite and MySQL
    """
    db_type = get_database_type()
    connection = None
    
    try:
        connection = get_db_connection()
        
        if db_type == 'sqlite':
            return _get_sqlite_table_profile(connection, table_name)
        else:
            return _get_mysql_table_profile(connection, table_name)
            
    except Exception as e:
        print(f"Error profiling table {table_name}: {e}")
        raise
    finally:
        if connection:
            connection.close()
            print("Database connection closed")


def _get_sqlite_table_profile(connection: sqlite3.Connection, table_name: str) -> Dict[str, Any]:
    """
    Generates profile for a SQLite table.
    
    Args:
        connection: Active SQLite connection
        table_name: Name of the table to profile
        
    Returns:
        Dict[str, Any]: Table profile dictionary
    """
    cursor = connection.cursor()
    
    # Get total row count
    cursor.execute(f"SELECT COUNT(*) FROM `{table_name}`")
    total_rows = cursor.fetchone()[0]
    
    # Get column information
    cursor.execute(f"PRAGMA table_info({table_name})")
    columns_info = cursor.fetchall()
    
    # Calculate null percentages for each column
    column_profiles = []
    for col_info in columns_info:
        column_name = col_info[1]
        data_type = col_info[2]
        
        # Count null values in this column
        null_query = f"SELECT COUNT(*) FROM `{table_name}` WHERE `{column_name}` IS NULL"
        cursor.execute(null_query)
        null_count = cursor.fetchone()[0]
        
        # Calculate null percentage
        null_percentage = (null_count / total_rows * 100) if total_rows > 0 else 0
        non_null_count = total_rows - null_count
        
        column_profiles.append({
            "column_name": column_name,
            "data_type": data_type,
            "null_count": null_count,
            "null_percentage": round(null_percentage, 2),
            "non_null_count": non_null_count
        })
    
    profile = {
        "table_name": table_name,
        "database_type": "sqlite",
        "row_count": total_rows,
        "column_profiles": column_profiles,
        "profiled_at": datetime.now().isoformat()
    }
    
    print(f"Generated profile for SQLite table: {table_name} ({total_rows} rows)")
    return profile


def _get_mysql_table_profile(connection, table_name: str) -> Dict[str, Any]:
    """
    Generates profile for a MySQL table.
    
    Args:
        connection: Active MySQL connection
        table_name: Name of the table to profile
        
    Returns:
        Dict[str, Any]: Table profile dictionary
    """
    cursor = connection.cursor(dictionary=True)
    
    # Get total row count
    cursor.execute(f"SELECT COUNT(*) as total_rows FROM `{table_name}`")
    row_count_result = cursor.fetchone()
    total_rows = row_count_result['total_rows']
    
    # Get column information
    db_name = os.getenv('DB_NAME')
    query = """
        SELECT 
            COLUMN_NAME as column_name,
            DATA_TYPE as data_type
        FROM INFORMATION_SCHEMA.COLUMNS
        WHERE TABLE_SCHEMA = %s AND TABLE_NAME = %s
        ORDER BY ORDINAL_POSITION
    """
    cursor.execute(query, (db_name, table_name))
    columns = cursor.fetchall()
    
    # Calculate null percentages for each column
    column_profiles = []
    for col in columns:
        column_name = col['column_name']
        
        # Count null values in this column
        null_query = f"SELECT COUNT(*) as null_count FROM `{table_name}` WHERE `{column_name}` IS NULL"
        cursor.execute(null_query)
        null_result = cursor.fetchone()
        null_count = null_result['null_count']
        
        # Calculate null percentage
        null_percentage = (null_count / total_rows * 100) if total_rows > 0 else 0
        non_null_count = total_rows - null_count
        
        column_profiles.append({
            "column_name": column_name,
            "data_type": col['data_type'],
            "null_count": null_count,
            "null_percentage": round(null_percentage, 2),
            "non_null_count": non_null_count
        })
    
    profile = {
        "table_name": table_name,
        "database_type": "mysql",
        "row_count": total_rows,
        "column_profiles": column_profiles,
        "profiled_at": datetime.now().isoformat()
    }
    
    print(f"Generated profile for MySQL table: {table_name} ({total_rows} rows)")
    return profile
