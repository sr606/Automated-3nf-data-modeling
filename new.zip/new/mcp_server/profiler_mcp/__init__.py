"""
Profiler MCP Server
===================
A FastAPI-based MCP (Model Context Protocol) server for database profiling.
This package provides tools for extracting database metadata and profiling tables.
"""

__version__ = "1.0.0"
__author__ = "Avdhut"
