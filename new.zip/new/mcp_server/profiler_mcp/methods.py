"""
Methods Module
==============
This module provides utility functions for environment management and directory setup.

Functions:
    - load_env(): Loads environment variables from .env file
    - get_env(): Retrieves specific environment variable value
    - get_data_paths(): Creates and returns data directory paths
    - get_active_database_path(): Returns path to SQLite database if exists in upload folder
"""

import os
from pathlib import Path
from dotenv import load_dotenv
from typing import Dict, Optional, List
from datetime import datetime


def load_env() -> bool:
    """
    Loads environment variables from the .env file.
    
    This function searches for a .env file in the parent directory of the project
    (outside mcp_server folder) and loads all variables into the environment.
    
    Returns:
        bool: True if .env file was found and loaded, False otherwise
        
    Example:
        >>> load_env()
        Environment variables loaded successfully from .env
        True
        
    Notes:
        - Searches for .env file in the parent directory of mcp_server
        - Does not override existing environment variables by default
        - Should be called before accessing any database connection
    """
    # Get the path to the .env file (outside mcp_server folder)
    current_dir = Path(__file__).parent.parent.parent
    env_path = current_dir / '.env'
    
    if env_path.exists():
        load_dotenv(dotenv_path=env_path)
        print(f"Environment variables loaded successfully from {env_path}")
        return True
    else:
        print(f"Warning: .env file not found at {env_path}")
        return False


def get_env(key: str, default: Optional[str] = None) -> Optional[str]:
    """
    Retrieves the value of an environment variable.
    
    This function provides a safe way to access environment variables with
    optional default values.
    
    Args:
        key (str): The name of the environment variable to retrieve
        default (Optional[str]): Default value if the variable is not found
    
    Returns:
        Optional[str]: Value of the environment variable or default value
        
    Example:
        >>> db_host = get_env('DB_HOST', 'localhost')
        >>> db_port = get_env('DB_PORT', '3306')
        >>> print(f"Connecting to {db_host}:{db_port}")
        
    Notes:
        - Returns None if variable not found and no default provided
        - Case-sensitive key names
    """
    value = os.getenv(key, default)
    if value is None:
        print(f"Warning: Environment variable '{key}' not found")
    return value


def get_data_paths() -> Dict[str, Path]:
    """
    Creates and returns paths to data directories.
    
    This function ensures that all required data directories exist and returns
    their paths. It automatically creates the directories if they don't exist.
    
    Directory Structure Created:
        profiler_mcp/
            data/
                feature/    (for storing profiling results)
                upload/     (for file uploads)
    
    Returns:
        Dict[str, Path]: Dictionary containing paths to data directories:
            {
                "data": Path to main data directory,
                "feature": Path to feature directory,
                "upload": Path to upload directory
            }
        
    Example:
        >>> paths = get_data_paths()
        >>> print(f"Feature directory: {paths['feature']}")
        >>> print(f"Upload directory: {paths['upload']}")
        profiler_mcp/data/feature/
        profiler_mcp/data/upload/
        
    Notes:
        - Automatically creates directories if they don't exist
        - Uses pathlib.Path for cross-platform compatibility
        - Called during application startup
    """
    # Get the base directory (profiler_mcp)
    base_dir = Path(__file__).parent
    
    # Define data directories
    data_dir = base_dir / "data"
    feature_dir = data_dir / "feature"
    upload_dir = data_dir / "upload"
    
    # Create directories if they don't exist
    feature_dir.mkdir(parents=True, exist_ok=True)
    upload_dir.mkdir(parents=True, exist_ok=True)
    
    print(f"Data directories initialized:")
    print(f"  - Feature: {feature_dir}")
    print(f"  - Upload: {upload_dir}")
    
    return {
        "data": data_dir,
        "feature": feature_dir,
        "upload": upload_dir
    }


def get_active_database_path() -> Optional[Path]:
    """
    Detects and returns the path to the most recent SQLite database file in data/upload.
    
    This function searches for .db files in the profiler_mcp/data/upload directory
    and returns the path to the most recently modified file. If no .db files are found,
    returns None (indicating MySQL should be used).
    
    Returns:
        Optional[Path]: Path to the SQLite database file, or None if no .db file exists
        
    Example:
        >>> db_path = get_active_database_path()
        >>> if db_path:
        >>>     print(f"Using SQLite: {db_path}")
        >>> else:
        >>>     print("Using MySQL from environment variables")
        
    Notes:
        - Only looks for files with .db extension
        - Returns the most recently modified .db file if multiple exist
        - Returns None if the upload directory is empty or has no .db files
        - This function determines whether SQLite or MySQL will be used
        
    Example Output:
        profiler_mcp/data/upload/chinook.db
    """
    # Get the base directory (profiler_mcp)
    base_dir = Path(__file__).parent
    upload_dir = base_dir / "data" / "upload"
    
    # Ensure upload directory exists
    upload_dir.mkdir(parents=True, exist_ok=True)
    
    # Find all .db files in the upload directory
    db_files: List[Path] = list(upload_dir.glob("*.db"))
    
    if not db_files:
        print("No SQLite database file found in data/upload. Will use MySQL.")
        return None
    
    # Sort by modification time (most recent first)
    db_files.sort(key=lambda x: x.stat().st_mtime, reverse=True)
    most_recent_db = db_files[0]
    
    print(f"SQLite database detected: {most_recent_db.name}")
    return most_recent_db
