"""
API routers for the Profiler MCP server.
"""
