"""
MCP Protocol Router
===================
This module implements the Model Context Protocol (MCP) SSE endpoint.
It exposes database profiling tools through the MCP protocol for use with LangChain.
"""

from fastapi import APIRouter, Request, Response
from mcp.server import Server
from mcp import types
import json
import os
import anyio

from ..toolbox.db_utils import get_tables_metadata, get_database_type, execute_query
from ..toolbox.profiling_utils import save_metadata_to_file, get_table_profile
from ..methods import get_active_database_path


# Create MCP server instance
mcp_server = Server("profiler-mcp")


@mcp_server.list_tools()
async def list_tools() -> list[types.Tool]:
    """List all available MCP tools."""
    return [
        types.Tool(
            name="extract_metadata",
            description=(
                "Extract metadata for all tables in the database and save to JSON file. "
                "Auto-detects SQLite or MySQL database and returns metadata including table names, "
                "columns, data types, and constraints."
            ),
            inputSchema={
                "type": "object",
                "properties": {},
                "required": []
            }
        ),
        types.Tool(
            name="profile_table",
            description=(
                "Profile a specific database table with detailed statistics. "
                "Generates completeness metrics, uniqueness analysis, and statistical summaries."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "table_name": {
                        "type": "string",
                        "description": "Name of the table to profile"
                    }
                },
                "required": ["table_name"]
            }
        ),
        types.Tool(
            name="execute_sql_query",
            description=(
                "Execute a SQL query against the connected database. "
                "Use this to run custom SQL queries for data analysis, profiling, or exploration."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "SQL query to execute"
                    }
                },
                "required": ["query"]
            }
        )
    ]


@mcp_server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[types.TextContent]:
    """Execute a tool by name with the given arguments."""
    
    if name == "extract_metadata":
        try:
            db_type = get_database_type()
            metadata = get_tables_metadata()
            
            # Generate filename
            if db_type == 'sqlite':
                db_path = get_active_database_path()
                db_name = db_path.stem if db_path else 'database'
            else:
                db_name = os.getenv('DB_NAME', 'database')
            
            filename = f"{db_name}_metadata"
            file_path = save_metadata_to_file(metadata, filename)
            
            result = {
                "status": "success",
                "database_type": db_type,
                "database_name": db_name,
                "metadata": metadata,
                "file_path": file_path,
                "table_count": len(metadata)
            }
            
            return [types.TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        except Exception as e:
            return [types.TextContent(
                type="text",
                text=json.dumps({"error": str(e)})
            )]
    
    elif name == "profile_table":
        try:
            table_name = arguments.get("table_name")
            if not table_name:
                raise ValueError("table_name is required")
            
            db_type = get_database_type()
            profile = get_table_profile(table_name)
            
            # Generate filename
            if db_type == 'sqlite':
                db_path = get_active_database_path()
                db_name = db_path.stem if db_path else 'database'
            else:
                db_name = os.getenv('DB_NAME', 'database')
            
            result = {
                "status": "success",
                "database_type": db_type,
                "database_name": db_name,
                "table_name": table_name,
                "profile": profile
            }
            
            return [types.TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        except Exception as e:
            return [types.TextContent(
                type="text",
                text=json.dumps({"error": str(e)})
            )]
    
    elif name == "execute_sql_query":
        try:
            query = arguments.get("query")
            if not query:
                raise ValueError("query is required")
            
            db_path = get_active_database_path()
            db_type = get_database_type()
            results = execute_query(str(db_path) if db_path else None, db_type, str(query))
            
            result = {
                "database_type": db_type,
                "query": query,
                "results": results
            }
            
            return [types.TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        except Exception as e:
            return [types.TextContent(
                type="text",
                text=json.dumps({"error": str(e)})
            )]
    
    else:
        return [types.TextContent(
            type="text",
            text=json.dumps({"error": f"Unknown tool: {name}"})
        )]


# Create router for MCP protocol
router = APIRouter(
    prefix="/api/v1/profile_data",
    tags=["mcp-protocol"]
)


async def mcp_endpoint(request: Request):
    """MCP SSE endpoint handler."""
    from mcp.server.streamable_http import streamablehttp_server
    
    # Handle the MCP request using streamable HTTP protocol
    async with streamablehttp_server(mcp_server) as (read_stream, write_stream):
        # Create a task group to handle reading and writing
        async with anyio.create_task_group() as tg:
            # Start the server handlers
            tg.start_soon(mcp_server._run, read_stream, write_stream)
            
            # Handle HTTP request/response
            body = await request.body()
            # Process the request and return response
            # This is a simplified version - you'll need proper SSE handling
            return Response(content=body, media_type="application/json")


# Add the MCP endpoint
router.post("/mcp")(mcp_endpoint)
router.get("/mcp")(mcp_endpoint)
