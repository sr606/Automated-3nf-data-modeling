"""
Profiler Router
===============
This module defines API endpoints for database profiling operations.
Supports both SQLite and MySQL databases with automatic detection.

Auto-Detection:
    - If a .db file exists in profiler_mcp/data/upload/, uses SQLite
    - Otherwise, connects to MySQL using environment variables from .env

Endpoints:
    - GET /api/v1/profile/extract_metadata: Extract and save database metadata
    - GET /api/v1/profile/profile_table: Profile a specific table
    - GET /api/v1/profile/health: Health check
"""

from fastapi import APIRouter, HTTPException, Query
from typing import Dict, Any
import os

from ..toolbox.db_utils import get_tables_metadata, get_database_type
from ..toolbox.profiling_utils import save_metadata_to_file, get_table_profile
from ..methods import get_active_database_path


# Create router instance
router = APIRouter(
    prefix="/api/v1/profile",
    tags=["profiling"],
    responses={404: {"description": "Not found"}},
)


@router.get("/extract_metadata")
async def extract_metadata() -> Dict[str, Any]:
    """
    Extract metadata for all tables in the database and save to JSON file.
    
    Auto-Detection:
        - If a .db file (e.g., chinook.db) exists in profiler_mcp/data/upload/,
          automatically connects to that SQLite database
        - Otherwise, connects to MySQL using credentials from .env file
    
    This endpoint:
        1. Detects database type (SQLite or MySQL)
        2. Connects to the appropriate database
        3. Extracts metadata for all tables (columns, types, constraints)
        4. Saves the metadata to a timestamped JSON file in data/feature/
        5. Returns the metadata and file path
    
    Usage:
        Simply place your SQLite .db file in profiler_mcp/data/upload/ folder,
        then call this endpoint. No configuration changes needed!
    
    Returns:
        Dict[str, Any]: Response containing:
            - status: Success/error status
            - message: Descriptive message
            - database_type: "sqlite" or "mysql"
            - database_name: Name of the database or file
            - file_path: Path where metadata was saved
            - metadata: Complete metadata dictionary
            - table_count: Number of tables found
    
    Raises:
        HTTPException: If database connection fails or metadata extraction fails
        
    Example Response (SQLite):
        {
            "status": "success",
            "message": "Metadata extracted and saved successfully",
            "database_type": "sqlite",
            "database_name": "chinook.db",
            "file_path": "profiler_mcp/data/feature/20251203_103210_chinook_metadata.json",
            "table_count": 13,
            "metadata": {
                "Album": [...],
                "Artist": [...],
                "Track": [...]
            }
        }
        
    Example Response (MySQL):
        {
            "status": "success",
            "message": "Metadata extracted and saved successfully",
            "database_type": "mysql",
            "database_name": "production_db",
            "file_path": "profiler_mcp/data/feature/20251203_103210_production_db_metadata.json",
            "table_count": 25,
            "metadata": {
                "users": [...],
                "orders": [...]
            }
        }
        
    Example Usage:
        GET http://localhost:8000/mcp/api/v1/profile/extract_metadata
        
    Notes:
        - For SQLite: Place your .db file in profiler_mcp/data/upload/
        - For MySQL: Ensure .env file has correct database credentials
        - Automatically uses the most recently modified .db file if multiple exist
    """
    try:
        # Detect database type
        db_type = get_database_type()
        
        # Extract metadata from all tables
        metadata = get_tables_metadata()
        
        # Generate filename and get database name
        if db_type == 'sqlite':
            db_path = get_active_database_path()
            db_name = db_path.stem if db_path else 'database'
        else:
            db_name = os.getenv('DB_NAME', 'database')
        
        filename = f"{db_name}_metadata"
        
        # Save metadata to file
        file_path = save_metadata_to_file(metadata, filename)
        
        return {
            "status": "success",
            "message": "Metadata extracted and saved successfully",
            "database_type": db_type,
            "database_name": db_name,
            "file_path": file_path,
            "table_count": len(metadata),
            "metadata": metadata
        }
    
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to extract metadata: {str(e)}"
        )


@router.get("/profile_table")
async def profile_table(
    table_name: str = Query(..., description="Name of the table to profile")
) -> Dict[str, Any]:
    """
    Profile a specific database table with row counts and null analysis.
    
    Auto-Detection:
        - If a .db file (e.g., chinook.db) exists in profiler_mcp/data/upload/,
          automatically profiles tables from that SQLite database
        - Otherwise, profiles tables from MySQL using credentials from .env file
    
    This endpoint:
        1. Detects database type (SQLite or MySQL)
        2. Validates the table exists
        3. Counts total rows
        4. Calculates null percentage for each column
        5. Saves the profile to a JSON file in data/feature/
    
    Args:
        table_name (str): Name of the table to profile (required query parameter)
    
    Returns:
        Dict[str, Any]: Response containing:
            - status: Success/error status
            - message: Descriptive message
            - database_type: "sqlite" or "mysql"
            - file_path: Path where profile was saved
            - profile: Complete table profile with statistics
    
    Raises:
        HTTPException: If table doesn't exist or profiling fails
        
    Example Response (SQLite):
        {
            "status": "success",
            "message": "Table 'Album' profiled successfully",
            "database_type": "sqlite",
            "file_path": "profiler_mcp/data/feature/20251203_103215_chinook_Album_profile.json",
            "profile": {
                "table_name": "Album",
                "database_type": "sqlite",
                "row_count": 347,
                "column_profiles": [
                    {
                        "column_name": "AlbumId",
                        "data_type": "INTEGER",
                        "null_count": 0,
                        "null_percentage": 0.0,
                        "non_null_count": 347
                    },
                    {
                        "column_name": "Title",
                        "data_type": "NVARCHAR(160)",
                        "null_count": 0,
                        "null_percentage": 0.0,
                        "non_null_count": 347
                    }
                ],
                "profiled_at": "2025-12-03T10:32:15.123456"
            }
        }
        
    Example Response (MySQL):
        {
            "status": "success",
            "message": "Table 'users' profiled successfully",
            "database_type": "mysql",
            "file_path": "profiler_mcp/data/feature/20251203_103215_production_users_profile.json",
            "profile": {
                "table_name": "users",
                "database_type": "mysql",
                "row_count": 1500,
                "column_profiles": [
                    {
                        "column_name": "id",
                        "data_type": "int",
                        "null_count": 0,
                        "null_percentage": 0.0,
                        "non_null_count": 1500
                    },
                    {
                        "column_name": "email",
                        "data_type": "varchar",
                        "null_count": 15,
                        "null_percentage": 1.0,
                        "non_null_count": 1485
                    }
                ],
                "profiled_at": "2025-12-03T10:32:15.123456"
            }
        }
        
    Example Usage:
        GET http://localhost:8000/mcp/api/v1/profile/profile_table?table_name=Album
        GET http://localhost:8000/mcp/api/v1/profile/profile_table?table_name=users
        
    Notes:
        - Works seamlessly with both SQLite and MySQL
        - For SQLite: Place your .db file in profiler_mcp/data/upload/
        - For MySQL: Ensure .env file has correct database credentials
        - Table names are case-sensitive in some databases
    """
    try:
        # Validate table name is not empty
        if not table_name or table_name.strip() == "":
            raise HTTPException(
                status_code=400,
                detail="Table name cannot be empty"
            )
        
        # Detect database type
        db_type = get_database_type()
        
        # Profile the table
        profile = get_table_profile(table_name)
        
        # Generate filename for saving profile
        if db_type == 'sqlite':
            db_path = get_active_database_path()
            db_name = db_path.stem if db_path else 'database'
        else:
            db_name = os.getenv('DB_NAME', 'database')
        
        filename = f"{db_name}_{table_name}_profile"
        file_path = save_metadata_to_file(profile, filename)
        
        return {
            "status": "success",
            "message": f"Table '{table_name}' profiled successfully",
            "database_type": db_type,
            "file_path": file_path,
            "profile": profile
        }
    
    except HTTPException:
        raise
    except Exception as e:
        raise HTTPException(
            status_code=500,
            detail=f"Failed to profile table '{table_name}': {str(e)}"
        )


@router.get("/health")
async def health_check() -> Dict[str, str]:
    """
    Simple health check endpoint to verify the profiler service is running.
    
    Returns:
        Dict[str, str]: Status message
        
    Example Response:
        {
            "status": "healthy",
            "service": "Profiler MCP"
        }
        
    Example Usage:
        GET http://localhost:8000/mcp/api/v1/profile/health
    """
    return {
        "status": "healthy",
        "service": "Profiler MCP"
    }
