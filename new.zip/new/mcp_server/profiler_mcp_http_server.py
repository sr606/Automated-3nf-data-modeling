#!/usr/bin/env python3
"""
MCP Streamable HTTP Server for Database Profiling
==================================================
This server implements the Model Context Protocol over HTTP
using Server-Sent Events (SSE) for streaming responses.

Run with: python profiler_mcp_http_server.py
Server will be available at: http://127.0.0.1:8032
"""

import asyncio
import json
import os
import sys
from pathlib import Path
from typing import Any

from fastapi import FastAPI, Request
from fastapi.responses import StreamingResponse
from fastapi.middleware.cors import CORSMiddleware
import uvicorn

# Add profiler_mcp to path
sys.path.insert(0, str(Path(__file__).parent))

from mcp.server import Server
from mcp import types

# Import profiler utilities
from profiler_mcp.toolbox.db_utils import get_tables_metadata, get_database_type, execute_query
from profiler_mcp.toolbox.profiling_utils import save_metadata_to_file, get_table_profile
from profiler_mcp.methods import get_active_database_path, load_env

# Load environment variables
load_env()

# Create FastAPI app
app = FastAPI(title="MCP Profiler HTTP Server")

# Add CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Create MCP server instance
mcp_server = Server("profiler-mcp")


async def _list_tools_internal() -> list[types.Tool]:
    """Internal function to list available tools."""
    return [
        types.Tool(
            name="extract_metadata",
            description=(
                "Extract metadata for all tables in the database and save to JSON file. "
                "Auto-detects SQLite or MySQL database and returns metadata including table names, "
                "columns, data types, and constraints."
            ),
            inputSchema={
                "type": "object",
                "properties": {},
                "required": []
            }
        ),
        types.Tool(
            name="profile_table",
            description=(
                "Profile a specific database table with detailed statistics. "
                "Generates completeness metrics, uniqueness analysis, and statistical summaries."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "table_name": {
                        "type": "string",
                        "description": "Name of the table to profile"
                    }
                },
                "required": ["table_name"]
            }
        ),
        types.Tool(
            name="execute_sql_query",
            description=(
                "Execute a SQL query against the connected database. "
                "Use this to run custom SQL queries for data analysis, profiling, or exploration."
            ),
            inputSchema={
                "type": "object",
                "properties": {
                    "query": {
                        "type": "string",
                        "description": "SQL query to execute"
                    }
                },
                "required": ["query"]
            }
        )
    ]


@mcp_server.list_tools()
async def list_tools() -> list[types.Tool]:
    """List all available MCP tools."""
    return await _list_tools_internal()


@mcp_server.call_tool()
async def call_tool(name: str, arguments: dict) -> list[types.TextContent]:
    """Execute a tool by name with the given arguments."""
    return await _call_tool_internal(name, arguments)


async def _call_tool_internal(name: str, arguments: dict) -> list[types.TextContent]:
    """Internal function to execute tools."""
    
    if name == "extract_metadata":
        try:
            db_type = get_database_type()
            metadata = get_tables_metadata()
            
            # Generate filename
            if db_type == 'sqlite':
                db_path = get_active_database_path()
                db_name = db_path.stem if db_path else 'database'
            else:
                db_name = os.getenv('DB_NAME', 'database')
            
            filename = f"{db_name}_metadata"
            file_path = save_metadata_to_file(metadata, filename)
            
            result = {
                "status": "success",
                "database_type": db_type,
                "database_name": db_name,
                "metadata": metadata,
                "file_path": file_path,
                "table_count": len(metadata)
            }
            
            return [types.TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        except Exception as e:
            return [types.TextContent(
                type="text",
                text=json.dumps({"error": str(e)})
            )]
    
    elif name == "profile_table":
        try:
            table_name = arguments.get("table_name")
            if not table_name:
                raise ValueError("table_name is required")
            
            db_type = get_database_type()
            profile = get_table_profile(table_name)
            
            # Generate filename
            if db_type == 'sqlite':
                db_path = get_active_database_path()
                db_name = db_path.stem if db_path else 'database'
            else:
                db_name = os.getenv('DB_NAME', 'database')
            
            result = {
                "status": "success",
                "database_type": db_type,
                "database_name": db_name,
                "table_name": table_name,
                "profile": profile
            }
            
            return [types.TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        except Exception as e:
            return [types.TextContent(
                type="text",
                text=json.dumps({"error": str(e)})
            )]
    
    elif name == "execute_sql_query":
        try:
            query = arguments.get("query")
            if not query:
                raise ValueError("query is required")
            
            db_path = get_active_database_path()
            db_type = get_database_type()
            results = execute_query(str(db_path) if db_path else None, db_type, str(query))
            
            result = {
                "database_type": db_type,
                "query": query,
                "results": results
            }
            
            return [types.TextContent(
                type="text",
                text=json.dumps(result, indent=2)
            )]
        except Exception as e:
            return [types.TextContent(
                type="text",
                text=json.dumps({"error": str(e)})
            )]
    
    else:
        return [types.TextContent(
            type="text",
            text=json.dumps({"error": f"Unknown tool: {name}"})
        )]


# Simple in-memory message handling for MCP protocol
@app.post("/")
@app.get("/")
async def mcp_endpoint(request: Request):
    """
    MCP protocol endpoint that handles requests via HTTP POST with JSON payloads.
    This is a simplified implementation that works with langchain_mcp_adapters.
    """
    if request.method == "POST":
        payload = None
        try:
            # Parse incoming MCP request
            payload = await request.json()
            
            # Handle different MCP methods
            method = payload.get("method")
            params = payload.get("params", {})
            request_id = payload.get("id")
            
            if method == "tools/list":
                # List available tools - call the internal function directly
                tools_raw = await _list_tools_internal()
                tools_dict = [
                    {
                        "name": tool.name,
                        "description": tool.description,
                        "inputSchema": tool.inputSchema
                    }
                    for tool in tools_raw
                ]
                
                response = {
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "result": {"tools": tools_dict}
                }
                
            elif method == "tools/call":
                # Call a specific tool - use internal function directly
                tool_name = params.get("name")
                arguments = params.get("arguments", {})
                
                result_list = await _call_tool_internal(tool_name, arguments)
                
                response = {
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "result": {
                        "content": [
                            {
                                "type": "text",
                                "text": result_list[0].text
                            }
                        ]
                    }
                }
                
            elif method == "initialize":
                # Handle initialization
                response = {
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "result": {
                        "protocolVersion": "2024-11-05",
                        "capabilities": {
                            "tools": {}
                        },
                        "serverInfo": {
                            "name": "profiler-mcp",
                            "version": "1.0.0"
                        }
                    }
                }
                
            else:
                response = {
                    "jsonrpc": "2.0",
                    "id": request_id,
                    "error": {
                        "code": -32601,
                        "message": f"Method not found: {method}"
                    }
                }
            
            return response
            
        except Exception as e:
            request_id = None
            if payload and isinstance(payload, dict):
                request_id = payload.get("id")
            return {
                "jsonrpc": "2.0",
                "id": request_id,
                "error": {
                    "code": -32603,
                    "message": f"Internal error: {str(e)}"
                }
            }
    else:
        # GET request - return server info
        return {
            "name": "profiler-mcp",
            "version": "1.0.0",
            "protocol": "mcp",
            "transport": "streamable_http"
        }


if __name__ == "__main__":
    print("=" * 60)
    print("MCP Profiler HTTP Server Starting...")
    print("=" * 60)
    print(f"Server URL: http://127.0.0.1:8032")
    print(f"Configure in notebook with:")
    print(f"  'Data_Profile': {{'url': 'http://127.0.0.1:8032', 'transport': 'streamable_http'}}")
    print("=" * 60)
    
    # Run server
    uvicorn.run(
        app,
        host="127.0.0.1",
        port=8032,
        log_level="info"
    )
